#def run(fileName):
def run(cmdF2LP,cmdDLV):
	import os
	#os.system('./f2lp-spatom ' + fileName)
	os.system(cmdF2LP)
	global outFile
	inFile = open('.solver_input.lp','r')
	if not inFile:
		print 'cannot open input file'
		return

	outFile = open('.f2lp_dlv_input.lp','w')
	if not outFile:
		print 'cannot open output file'
		return

	# create a hasn table and list for maintaining domain variables
	global domainHash
	global domainVarList
	domainHash = dict()
	domainVarList = []

	while 1:
		line = inFile.readline()
		if not line:
			break

		if line[0] == '%':
			continue

		if len(line) <= 1:
			continue

		line = line.replace('_new_pred_','new_pred_')
		line = line.replace('_NV_','NV_')

		safeAtomLine = ''
		safeAtomLine = getSafeAtoms(line)
		gringoToDlv(line,safeAtomLine)

	inFile.close()
	outFile.close()
	os.system(cmdDLV + ' .f2lp_dlv_input.lp')


def gringoToDlv(line,safeAtomLine):		
	# look for double negation
	if '{not ' in line:
		startIndex = str.find(line,'{not ')
		atom = ''
		while line[startIndex] != ' ':
			startIndex = startIndex + 1
		startIndex = startIndex + 1

		while line[startIndex] != '}':
			atom = atom + line[startIndex]
			startIndex = startIndex + 1

		endIndex = startIndex + 1

		barAtom = getBarAtom(atom)

		# call the function so that domain predicates are added
		if safeAtomLine:
			gringoToDlv(barAtom + ' :- ' + 'not ' + atom + ', ' + safeAtomLine + '.', safeAtomLine)
		else:
			gringoToDlv(barAtom + ' :- ' + 'not ' + atom + '.', safeAtomLine)
		
		gringoToDlv(':- ' + barAtom + ', ' + atom + '.', safeAtomLine)
		
		line = line.replace('{not ' + atom + '}0','not ' + barAtom)
		
		gringoToDlv(line,safeAtomLine)

	# look for domain variables
	elif '#domain ' in line:
		# store the domain atom and variable
		domainVar = getDomainVar(line)
		domainAtom = getDomainAtom(line)
		domainVarList.append(domainVar)
		domainHash[domainVar] = domainAtom	

	else:
		# insert domain predicates if required
		for var in domainVarList:
			if '('+var+',' in line or ','+var+',' in line or ','+var+')' in line or '('+var+')' in line:
				tempLine = ''
				index = 0
				while index != str.rfind(line,'.'):
					tempLine = tempLine + line[index]
					index = index + 1
				line = tempLine
				line = line + ', ' + domainHash[var] + '.'

		line = line + '\n'
		if not '#show' in line and not '#hide' in line:
			outFile.write(line)




def getDomainAtom(line):
	domainAtom = ''
	index = str.find(line,'#domain ')
	while line[index] != ' ':
		index = index + 1
	while line[index] == ' ':
		index = index + 1
	while line[index] != '.':
		domainAtom = domainAtom + line[index]
		index = index + 1

	return domainAtom


def getDomainVar(line):
	domainVar = ''
	index = str.find(line,'#domain ')
	while line[index] != '(':
		index = index + 1

	index = index + 1
	while line[index] != ')':
		domainVar = domainVar + line[index]
		index = index + 1

	return domainVar






def getSafeAtoms(line):
	safeAtomLine = ''
	index = str.find(line,':-')
	index = index + 2

	while line[index] != '.':
		if line[index] == ' ' or line[index] == ',':
			index = index + 1
			continue

		# check for double negation
		if line[index] == '{':
			while line[index] != '}':
				index = index + 1
			index = index + 2
			continue
	
		# check for #succ	
		#indexSucc = str.find(line,'#succ(',index,index+6)
		#if indexSucc != -1:
		#	indexSucc = str.find(line,'), ',index)
		#	if indexSucc != -1:
		#		index = indexSucc + 2
		#		continue
		#	else:
		#		index = str.find(line,')',index)
		#		index = index + 1
		#		continue
		
		# check for DL-atoms
		if line[index] == '&':
			if safeAtomLine != '':
				safeAtomLine = safeAtomLine + ', '

			while line[index] != ']':
				safeAtomLine = safeAtomLine + line[index]
				index = index + 1
			while line[index] != ')':
				safeAtomLine = safeAtomLine + line[index]
				index = index + 1

			safeAtomLine = safeAtomLine + line[index]
			index = index + 1
			continue

		# for comparisons, allow only when it is equality with constants
		# works only for simple comparisons, not for comparison between function terms
		compIndexLt = str.find(line,'<',index)
		compIndexGt = str.find(line,'>',index)
		compIndexEq = str.find(line,'=',index)
		compIndexNe = str.find(line,'!',index)
		commaIndex = str.find(line,',',index)
		dotIndex = str.find(line,'.',index)
		if compIndexEq != -1 and commaIndex != -1 and compIndexEq < commaIndex:
			if abs(compIndexLt - compIndexEq) != 1 and abs(compIndexGt - compIndexEq) != 1 and abs(compIndexNe - compIndexEq) != 1:
				#equality
				if line[index].isupper:
					indexBkup = compIndexEq
					while not line[indexBkup].isalnum():
						indexBkup = indexBkup + 1
					if line[indexBkup].isupper():
						index = commaIndex
						continue
			else:
				index = commaIndex
				continue


		elif commaIndex == -1 and compIndexEq != -1 and dotIndex != -1 and compIndexEq < dotIndex:
			if abs(compIndexLt - compIndexEq) != 1 and abs(compIndexGt - compIndexEq) != 1 and abs(compIndexNe - compIndexEq) != 1:
				#equality
				if line[index].isupper:
					indexBkup = compIndexEq
					while not line[indexBkup].isalnum():
						indexBkup = indexBkup + 1
					if line[indexBkup].isupper:
						index = dotIndex
						continue
			else:
				index = dotIndex
				continue

		else:
			if compIndexLt != -1 and commaIndex != -1 and compIndexLt < commaIndex:
				index = commaIndex
				continue
			if compIndexGt != -1 and commaIndex != -1 and compIndexGt < commaIndex:
				index = commaIndex
				continue
			if compIndexNe != -1 and commaIndex != -1 and compIndexNe < commaIndex:
				index = commaIndex
				continue

			if compIndexLt != -1 and dotIndex != -1 and compIndexLt < dotIndex:
				index = dotIndex
				continue
			if compIndexGt != -1 and dotIndex != -1 and compIndexGt < dotIndex:
				index = dotIndex
				continue
			if compIndexNe != -1 and dotIndex != -1 and compIndexNe < dotIndex:
				index = dotIndex
				continue


	
		# if not negated, copy
		indexNot = str.find(line,'not ',index,index+4)
		if indexNot == -1:
			if safeAtomLine != '':
				safeAtomLine = safeAtomLine + ', '
			paranCount = 0
			while line[index] != '(' and line[index] != ',' and line[index] != '.':
				safeAtomLine = safeAtomLine + line[index]
				index = index + 1

			if line[index] == '(':
				safeAtomLine = safeAtomLine + line[index]
				paranCount = 1
				index = index + 1
				while paranCount != 0:
					safeAtomLine = safeAtomLine + line[index]
					if line[index] == ')':
						paranCount = paranCount - 1
					if line[index] == '(':
						paranCount = paranCount + 1
					index = index + 1
				continue

		else:
			paranCount = 0
			while line[index] != '(' and line[index] != ',' and line[index] != '.':
				index = index + 1

			if line[index] == '(':
				paranCount = 1
				index = index + 1
				while paranCount != 0:
					if line[index] == ')':
						paranCount = paranCount - 1
					if line[index] == '(':
						paranCount = paranCount + 1
					index = index + 1
				continue

			
	return safeAtomLine
					


def getBarAtom(atom):
	index = 0
	barAtom = ''
	for char in atom:
		if char != '(':
			barAtom = barAtom + char
		else:
			barAtom = barAtom + '_bar' + char

	return barAtom	
