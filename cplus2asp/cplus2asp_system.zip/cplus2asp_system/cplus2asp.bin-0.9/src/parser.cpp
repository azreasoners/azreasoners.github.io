/* A Bison parser, made by GNU Bison 2.4.3.  */

/* Skeleton implementation for Bison's Yacc-like parsers in C
   
      Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006,
   2009, 2010 Free Software Foundation, Inc.
   
   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.
   
   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output.  */
#define YYBISON 1

/* Bison version.  */
#define YYBISON_VERSION "2.4.3"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Push parsers.  */
#define YYPUSH 0

/* Pull parsers.  */
#define YYPULL 1

/* Using locations.  */
#define YYLSP_NEEDED 1

/* Substitute the variable and function names.  */
#define yyparse         ltsyyparse
#define yylex           ltsyylex
#define yyerror         ltsyyerror
#define yylval          ltsyylval
#define yychar          ltsyychar
#define yydebug         ltsyydebug
#define yynerrs         ltsyynerrs
#define yylloc          ltsyylloc

/* Copy the first part of user declarations.  */


/* Line 189 of yacc.c  */
#line 80 "parser.cpp"

/* Enabling traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 0
#endif

/* Enabling the token table.  */
#ifndef YYTOKEN_TABLE
# define YYTOKEN_TABLE 1
#endif

/* "%code requires" blocks.  */

/* Line 209 of yacc.c  */
#line 8 "parser.y"

#include <iostream>
#include <list>
#include <sstream>
#include <string>
#include <utility>
#include <vector>

#include "Attribute.h"
#include "ASPCode.h"
#include "Comment.h"
#include "Constant.h"
#include "Object.h"
#include "NumberRange.h"
#include "Sort.h"
#include "Variable.h"
#include "Query.h"

#include "ElementCounter.h"
#include "SymbolTable.h"
#include "Translator.h"
#include "utilities.h"

#include "parser_types.h"



/* Line 209 of yacc.c  */
#line 132 "parser.cpp"

/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     END = 0,
     T_INTEGER = 258,
     T_IDENTIFIER = 259,
     T_STRING = 260,
     T_ASP = 261,
     T_COMMENT = 262,
     T_CONSTANTS = 263,
     T_INCLUDE = 264,
     T_MACROS = 265,
     T_OBJECTS = 266,
     T_QUERY = 267,
     T_SHOW = 268,
     T_SORTS = 269,
     T_VARIABLES = 270,
     T_ABACTION = 271,
     T_ACTION = 272,
     T_ADDITIVEACTION = 273,
     T_ADDITIVEFLUENT = 274,
     T_AFTER = 275,
     T_ALWAYS = 276,
     T_ATTRIBUTE = 277,
     T_BY = 278,
     T_CAUSED = 279,
     T_CAUSES = 280,
     T_CONSTRAINT = 281,
     T_DECREMENTS = 282,
     T_DEFAULT = 283,
     T_EXOGENOUS = 284,
     T_EXOGENOUSACTION = 285,
     T_IF = 286,
     T_INCREMENTS = 287,
     T_INERTIAL = 288,
     T_INERTIALFLUENT = 289,
     T_LABEL = 290,
     T_MAY_CAUSE = 291,
     T_MAXADDITIVE = 292,
     T_MAXSTEP = 293,
     T_NEVER = 294,
     T_NOCONCURRENCY = 295,
     T_NONEXECUTABLE = 296,
     T_OF = 297,
     T_POSSIBLY_CAUSED = 298,
     T_RIGID = 299,
     T_SDFLUENT = 300,
     T_SIMPLEFLUENT = 301,
     T_UNLESS = 302,
     T_WHERE = 303,
     T_FALSE = 304,
     T_NONE = 305,
     T_TRUE = 306,
     T_ABS = 307,
     T_AT = 308,
     T_BRACKET_L = 309,
     T_BRACKET_R = 310,
     T_COLON_DASH = 311,
     T_PAREN_L = 312,
     T_PAREN_R = 313,
     T_PERIOD = 314,
     T_PIPE = 315,
     T_SEMICOLON = 316,
     T_DBL_COLON = 317,
     T_ARROW_LDASH = 318,
     T_ARROW_REQ = 319,
     T_ARROW_LEQ = 320,
     T_ARROW_RDASH = 321,
     T_COLON = 322,
     T_COMMA = 323,
     T_EQUIV = 324,
     T_IMPL = 325,
     T_DBL_PLUS = 326,
     T_DBL_AMP = 327,
     T_AMP = 328,
     T_GTHAN_EQ = 329,
     T_EQ_LTHAN = 330,
     T_GTHAN = 331,
     T_LTHAN = 332,
     T_NOT_EQ = 333,
     T_DBL_EQ = 334,
     T_EQ = 335,
     T_NOT = 336,
     T_DBL_PERIOD = 337,
     T_PLUS = 338,
     T_DASH = 339,
     T_DBL_GTHAN = 340,
     T_MOD = 341,
     T_INT_DIV = 342,
     T_STAR = 343,
     T_BIG_CONJ = 344,
     T_BIG_DISJ = 345,
     T_POUND = 346,
     T_UMINUS = 347
   };
#endif



#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
{

/* Line 214 of yacc.c  */
#line 34 "parser.y"

	/* Types returned by the lexer. */
	int integer; ///< Basic integer.
	std::string* str; ///< String pointer.
	ASPCode* asp; ///< Raw ASP code.
	Comment* com; ///< Raw commented text.
	/* Classes directly used by the parser. */
	Attribute* attribute; ///< Pointer to an Attribute element instance.
	Constant* constant; ///< Pointer to a Constant element instance.
	NumberRange* numRange; ///< Pointer to a NumRange element instance.
	Object* object; ///< Pointer to an Object element instance.
	Sort* sort; ///< Pointer to a Sort element instance.
	Variable* variable; ///< Pointer to a Variable element instance.
	Constant::ConstantType constType; ///< A ConstantType enum describing the type of a related constant.
	/* Containers used by the parser. */
	std::list<Constant*>* l_constant; ///< Pointer to a list of Constant element pointers.
	std::list<Object*>* l_object; ///< Pointer to a list of Object element pointers.
	std::list<Sort*>* l_sort; ///< Pointer to a list of Sort element pointers.
	std::list<Variable*>* l_variable; ///< Pointer to a list of Variable element pointers.
	std::vector<ParseElement*>* v_parseElement; ///< Pointer to a list of ParseElement pointers.
	std::list<std::pair<enum BigQuantifiers::QuantifierType, ParseElement*>* >* l_quantPair; ///< List of pairs of QuantifierType enums and a associated ParseElement pointers.
	std::pair<enum BigQuantifiers::QuantifierType, ParseElement*>* p_quantPair; ///< Pair of a QuantifierType enum and an associated ParseElement pointer.
	/* Types specific to the parser. */
	PT_constant_binder_t* constant_binder_t; ///< An internal type for carrying information in a particular constant declaration grammar rule up the chain.
	ParseElement* parseElement; ///< A pointer to a class like Element, but with translation features added and more loose ties to actual declared elements.
	/* Used to denote a rule whose $$ we don't care about and never (de)allocate or assign to. */
	void* not_used; ///< Used for rules whose lvalues are not used or referenced by other grammar rules.



/* Line 214 of yacc.c  */
#line 273 "parser.cpp"
} YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
#endif

#if ! defined YYLTYPE && ! defined YYLTYPE_IS_DECLARED
typedef struct YYLTYPE
{
  int first_line;
  int first_column;
  int last_line;
  int last_column;
} YYLTYPE;
# define yyltype YYLTYPE /* obsolescent; will be withdrawn */
# define YYLTYPE_IS_DECLARED 1
# define YYLTYPE_IS_TRIVIAL 1
#endif

/* "%code provides" blocks.  */

/* Line 261 of yacc.c  */
#line 63 "parser.y"

/**
 * @file parser.h
 * @brief Contains parser for C+ programs, including definitions and helper functions.
 */

extern Translator mainTrans; ///< The main Translator instance, declared by the parser to create a close working relationship.
extern bool ltsyyendOfFile; ///< True if the parser has reached the end of the input stream.
extern int ltsyynerrs; ///< Output string stream used to store and output error messages from the parser and its helper modules.

/**
 * Invokes the parser, processing and translating input until either the end of input
 * or a fatal error are encountered.
 * @return 0 if parsing was successful (or if only non-fatal errors encountered), typically 1 if any fatal errors were encountered.
 */
int ltsyyparse();

/**
 * Wraps the given element in two new negation operators to create a "not not (...)." wrap.
 * @param elem - The element to wrap in a "not not (...)" wrapper.
 * @return A new SimpleUnaryOperator "not" object, wrapping another such object, wrapping the original element (or NULL if anything is invalid).
 */
SimpleUnaryOperator* createNotNot(ParseElement* elem);

/**
 * Creates an object-like element that mirrors the contents of elem.
 * Used when a constant needs to be treated directly as an object.
 * @param elem - The constant to mirror.
 * @return A new ObjectLikeElement object whose contents mirror those of elem.
 * @note The parameters of elem are shallow copied to the new element, be sure to safely clear the new element's parameters before deallocating it!
 */
ObjectLikeElement* createObjLikeFromConstLike(ConstantLikeElement* elem);

/**
 * Deallocates a "not not" wrapper such that the original ParseElement is not deallocated.
 * Removes any parentheses flags from the original ParseElement object.
 * @param uop - The outermost "not" operator of the two to destroy.
 * @return The ParseElement object that was formerly wrapped by the two "not" operators (or NULL if anything is invalid).
 */
ParseElement* deallocateNotNot(SimpleUnaryOperator* uop);

/**
 * NULLs elem's preOp and postOp before deallocating so the sub-ParseElement objects don't get caught in the deallocation.
 * @param elem - The temporary SimpleBinaryOperator element to destroy.
 */
void deallocateTempBinaryOp(SimpleBinaryOperator* &elem);

/**
 * NULLs elem's postOp before deallocating so the sub-ParseElement object doesn't get caught in the deallocation.
 * @param elem - The temporary SimpleUnaryOperator element to destroy.
 */
void deallocateTempUnaryOp(SimpleUnaryOperator* &elem);

/**
 * Adds a standard parsing caution header to ltsyyossErr to make caution
 * notifications easier to pinpoint.
 * @param cautionLoc - YYLTYPE struct where the caution was invoked.
 */
void ltsyystartCaution(YYLTYPE cautionLoc);
/**
 * Adds a standard (location-unaware) parsing caution header to ltsyyossErr
 * to try making caution notifications easier to locate.
 */
void ltsyystartCaution();
/**
 * Caution reporting function for the parser.
 * Never called by bison, called by parser actions when a non-fatal
 * situation is identified that might produce unexpected/undesired
 * translation results.
 * If ltsyyossErr is empty, outputs a generic caution notification,
 * otherwise uses the existing contents of ltsyyossErr. In either case,
 * outputs to the same place errors go, always appends a newline, and
 * resets the contents of ltsyyossErr after outputting the caution.
 */
void ltsyycaution();

/**
 * Adds a standard parsing warning header to ltsyyossErr to make warning
 * notifications easier to pinpoint.
 * @param warningLoc - YYLTYPE struct where the warning was invoked.
 */
void ltsyystartWarning(YYLTYPE warningLoc);
/**
 * Adds a standard (location-unaware) parsing warning header to ltsyyossErr
 * to try making warning notifications easier to locate.
 */
void ltsyystartWarning();
/**
 * Warning reporting function for the parser.
 * Never called by bison, called by parser actions when a non-fatal
 * situation is identified that will probably produce unexpected/undesired
 * translation results.
 * If ltsyyossErr is empty, outputs a generic warning notification,
 * otherwise uses the existing contents of ltsyyossErr. In either case,
 * outputs to the same place errors go, always appends a newline, and
 * resets the contents of ltsyyossErr after outputting the warning.
 */
void ltsyywarning();

/**
 * Adds a standard parse error header to ltsyyossErr to make it easier
 * to report errors in actions.
 * @param errLoc - YYLTYPE struct of the location of the error.
 */
void ltsyystartParseError(YYLTYPE errLoc);
/**
 * Adds a standard (location-unaware) parse error header to ltsyyossErr to
 * make it easier to report errors in actions.
 */
void ltsyystartParseError();
/**
 * Adds a standard syntax error header to ltsyyossErr to make it easier
 * to report errors in actions.
 * @param errLoc - YYLTYPE struct of the location of the error.
 */
void ltsyystartSyntaxError(YYLTYPE errLoc);
/**
 * Adds a standard (location-unaware) syntax error header to ltsyyossErr to
 * make it easier to report errors in actions.
 */
void ltsyystartSyntaxError();
/**
 * Error reporting function for the bison parser.
 * Since bison's default error message ("syntax error") is not useful,
 * ignores the passed message and looks at the contents of the ltsyyossErr
 * stream to decide what to output. If ltsyyossErr is empty, outputs
 * a general syntax error message, otherwise outputs the contents of
 * ltsyyossErr. In either case, automatically adds a newline to the end
 * of the message.
 * Automatically clears the contents and state of ltsyyossErr after printing
 * the applicable error message.
 * @param msg - The (ignored) error message provided by bison.
 */
void ltsyyerror(char const* msg);

/**
 * Wraps caution reporting for convenience and unification with convention for error reporting.
 */
void ltsyyreportCaution();
/**
 * Wraps warning reporting for convenience and unification with convention for error reporting.
 */
void ltsyyreportWarning();
/**
 * Wraps error reporting for ease and to ensure the number of errors gets incremented with each (action-generated) error report.
 */
void ltsyyreportError();




/* Line 261 of yacc.c  */
#line 449 "parser.cpp"

/* Copy the second part of user declarations.  */

/* Line 264 of yacc.c  */
#line 213 "parser.y"

#include "lexerTokenStream.h"

/* Line 264 of yacc.c  */
#line 217 "parser.y"

Translator mainTrans; // The main Translator instance, declared by the parser to create a close working relationship.
bool ltsyyendOfFile = false; // True if the parser has reached the end of the input stream.
std::ostringstream ltsyyossErr; // Output string stream used to store and output error messages from the parser and its helper modules.
/// Clears the contents and error flags of the output string stream used for error reporting.
#define LTSYYRESETOSS \
ltsyyossErr.str(""); \
ltsyyossErr.clear();
/// Placeholder value for parse rules whose lvals ($$) we don't end up needing.
#define PARSERULE_NOT_USED NULL
/// Clears out, deallocates, and nullifies a list/vector/etc. pointer.
#define deallocateList(lst) \
lst->clear(); \
delete lst; \
lst = NULL;
/// Deallocates and nullifies a non-container pointer.
#define deallocateItem(item) \
delete item; \
item = NULL;

// Helper functions for actions.
/**
 * Takes a sort identifier and a (possibly empty) list of subsorts and tries to
 * create, add, and translate a sort from the information.
 * @param sortIdent - A string of the new sort's original name.
 * @param subsorts - A (possibly empty) list of subsorts of the desired sort.
 * @return A pointer to the new sort object, or NULL on an error.
 */
Sort* processSort(std::string* sortIdent, std::list<Sort*>* subsorts);

/**
 * Tries to find an existing normal sort or declare a starred ("something*") sort.
 * Will not instantiate a normal sort (even as a child of a "something*" sort, will
 * report an error instead.
 * @param sortIdent - The name of the sort to check and find.
 * @return A pointer to the associated instantiated sort obect, or NULL if the sort wasn't found.
 */
Sort* checkDynamicSortDecl(std::string* sortIdent);

/**
 * Transforms declarative laws ("inertial p", "exogenous a(X)", "rigid q", etc.) to basic form and calls the translator for them.
 * @param head - The head of the law, in this case a bare constant-like expression.
 * @param ifBody - Optional conditional formula to govern when the law applies.
 * @param afterBody - Optional conditional formula specifying conditions from the prior time step.
 * @param whereBody - Another conditional formula to govern when the law applies.
 * @param opType - The kind of declaration this is (exogenous, inertial, etc.).
 * @return True if everything translates properly, false if anything goes wrong.
 */
bool handleDeclarativeLaw(ParseElement* head, ParseElement* ifBody, ParseElement* afterBody, ParseElement* whereBody, SimpleUnaryOperator::UnaryOperatorType opType);

/**
 * Transforms a causal law of the form "always F [where G]." to basic form, then calls the translator for it.
 * @param constraint - The condition that must be true.
 * @param whereBody - A conditional formula to govern when the law applies.
 * @return True if everything translates properly, false if anything goes wrong.
 */
bool handleAlwaysLaw(ParseElement* constraint, ParseElement* whereBody);

/**
 * Transforms a causal law of the form "constraint F [after H] [where J]." to basic form, then calls the translator for it.
 * @param constraint - The condition that must be true.
 * @param afterBody - Optional conditional formula specifying restrictions from the prior time step.
 * @param unlessBody - Optional formula that acts as an abnormality condition.
 * @param whereBody - Another conditional formula to govern when the law applies.
 * @return True if everything translates properly, false if anything goes wrong.
 */
bool handleConstraintLaw(ParseElement* constraint, ParseElement* afterBody, ParseElement* unlessBody, ParseElement* whereBody);

/**
 * Transforms a causal law of the form "default F [if G] [after H] [where J]." to basic form, then calls the translator on it.
 * @param head - The head of the law.
 * @param ifBody - Optional conditional formula to govern when the law applies.
 * @param afterBody - Optional conditional formula specifying conditions from the prior time step.
 * @param whereBody - Another conditional formula to govern when the law applies.
 * @return True if everything translates properly, false if anything goes wrong.
 */
bool handleDefaultLaw(ParseElement* head, ParseElement* ifBody, ParseElement* afterBody, ParseElement* whereBody);

/**
 * Transforms a causal law of the form "nonexecutable F [if G] [where H]." to basic form, then calls the translator for it.
 * @param nonEx - The formula that should not be executed.
 * @param ifBody - Optional conditional formula to govern when the law applies.
 * @param whereBody - Another conditional formula to govern when the law applies.
 * @return True if everything translates properly, false if anything goes wrong.
 */
bool handleNonexecutableLaw(ParseElement* nonEx, ParseElement* ifBody, ParseElement* whereBody);

/**
 * Transforms a causal law of the form "possibly caused F [if G] [after H] [where J]." to basic form, then calls the translator on it.
 * @param head - The head of the law.
 * @param ifBody - Optional conditional formula to govern when the law applies.
 * @param afterBody - Optional conditional formula specifying conditions from the prior time step.
 * @param whereBody - Another conditional formula to govern when the law applies.
 * @return True if everything translates properly, false if anything goes wrong.
 */
bool handlePossiblyCausedLaw(ParseElement* head, ParseElement* ifBody, ParseElement* afterBody, ParseElement* whereBody);

/**
 * Transforms a causal law of the form "G may cause F [if H] [where J]." to basic form, then calls the translator on it.
 * @param causer - The causing action formula.
 * @param causee - The formula being caused.
 * @param ifBody - Optional conditional formula to govern when the law applies.
 * @param whereBody - Another conditional formula to govern when the law applies.
 * @return True if everything translates properly, false if anything goes wrong.
 */
bool handleMayCauseLaw(ParseElement* causer, ParseElement* causee, ParseElement* ifBody, ParseElement* whereBody);

/**
 * Transforms a causal law of the form "G causes F [if H] [where J]." to basic form, then calls the translator on it.
 * @param causer - The causing action formula.
 * @param causee - The formula being caused.
 * @param ifBody - Optional conditional formula to govern when the law applies.
 * @param whereBody - Another conditional formula to govern when the law applies.
 * @return True if everything translates properly, false if anything goes wrong.
 */
bool handleCausesLaw(ParseElement* causer, ParseElement* causee, ParseElement* ifBody, ParseElement* whereBody);

/**
 * Transforms a causal law of the form "A increments B by N [if H] [where J]." to basic form, then calls the translator on it.
 * @param causer - The causing action.
 * @param causee - The additive constant being incremented.
 * @param increment - The increment expression
 * @param ifBody - Optional conditional formula to govern when the law applies.
 * @param whereBody - Another conditional formula to govern when the law applies.
 * @param isIncrement - True if the law is increment, false if it is decrement.
 * @return True if everything translates properly, false if anything goes wrong.
 */
bool handleIncrementLaw(ParseElement* causer, ParseElement* causee, ParseElement* increment, ParseElement* ifBody, ParseElement* whereBody, bool isIncrement);



/* Line 264 of yacc.c  */
#line 592 "parser.cpp"

#ifdef short
# undef short
#endif

#ifdef YYTYPE_UINT8
typedef YYTYPE_UINT8 yytype_uint8;
#else
typedef unsigned char yytype_uint8;
#endif

#ifdef YYTYPE_INT8
typedef YYTYPE_INT8 yytype_int8;
#elif (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
typedef signed char yytype_int8;
#else
typedef short int yytype_int8;
#endif

#ifdef YYTYPE_UINT16
typedef YYTYPE_UINT16 yytype_uint16;
#else
typedef unsigned short int yytype_uint16;
#endif

#ifdef YYTYPE_INT16
typedef YYTYPE_INT16 yytype_int16;
#else
typedef short int yytype_int16;
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif ! defined YYSIZE_T && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned int
# endif
#endif

#define YYSIZE_MAXIMUM ((YYSIZE_T) -1)

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(msgid) dgettext ("bison-runtime", msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(msgid) msgid
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YYUSE(e) ((void) (e))
#else
# define YYUSE(e) /* empty */
#endif

/* Identity function, used to suppress warnings about constant conditions.  */
#ifndef lint
# define YYID(n) (n)
#else
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static int
YYID (int yyi)
#else
static int
YYID (yyi)
    int yyi;
#endif
{
  return yyi;
}
#endif

#if ! defined yyoverflow || YYERROR_VERBOSE

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#     ifndef _STDLIB_H
#      define _STDLIB_H 1
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's `empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (YYID (0))
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined _STDLIB_H \
       && ! ((defined YYMALLOC || defined malloc) \
	     && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef _STDLIB_H
#    define _STDLIB_H 1
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* ! defined yyoverflow || YYERROR_VERBOSE */


#if (! defined yyoverflow \
     && (! defined __cplusplus \
	 || (defined YYLTYPE_IS_TRIVIAL && YYLTYPE_IS_TRIVIAL \
	     && defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yytype_int16 yyss_alloc;
  YYSTYPE yyvs_alloc;
  YYLTYPE yyls_alloc;
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (sizeof (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (sizeof (yytype_int16) + sizeof (YYSTYPE) + sizeof (YYLTYPE)) \
      + 2 * YYSTACK_GAP_MAXIMUM)

/* Copy COUNT objects from FROM to TO.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(To, From, Count) \
      __builtin_memcpy (To, From, (Count) * sizeof (*(From)))
#  else
#   define YYCOPY(To, From, Count)		\
      do					\
	{					\
	  YYSIZE_T yyi;				\
	  for (yyi = 0; yyi < (Count); yyi++)	\
	    (To)[yyi] = (From)[yyi];		\
	}					\
      while (YYID (0))
#  endif
# endif

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack_alloc, Stack)				\
    do									\
      {									\
	YYSIZE_T yynewbytes;						\
	YYCOPY (&yyptr->Stack_alloc, Stack, yysize);			\
	Stack = &yyptr->Stack_alloc;					\
	yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAXIMUM; \
	yyptr += yynewbytes / sizeof (*yyptr);				\
      }									\
    while (YYID (0))

#endif

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  102
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   1097

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  93
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  101
/* YYNRULES -- Number of rules.  */
#define YYNRULES  301
/* YYNRULES -- Number of states.  */
#define YYNSTATES  544

/* YYTRANSLATE(YYLEX) -- Bison symbol number corresponding to YYLEX.  */
#define YYUNDEFTOK  2
#define YYMAXUTOK   347

#define YYTRANSLATE(YYX)						\
  ((unsigned int) (YYX) <= YYMAXUTOK ? yytranslate[YYX] : YYUNDEFTOK)

/* YYTRANSLATE[YYLEX] -- Bison symbol number corresponding to YYLEX.  */
static const yytype_uint8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
      75,    76,    77,    78,    79,    80,    81,    82,    83,    84,
      85,    86,    87,    88,    89,    90,    91,    92
};

#if YYDEBUG
/* YYPRHS[YYN] -- Index of the first RHS symbol of rule number YYN in
   YYRHS.  */
static const yytype_uint16 yyprhs[] =
{
       0,     0,     3,     4,     6,     8,    11,    13,    15,    17,
      19,    21,    23,    25,    27,    30,    35,    37,    41,    43,
      47,    49,    53,    57,    59,    63,    65,    69,    71,    75,
      77,    82,    84,    89,    91,    95,    97,   102,   106,   113,
     115,   121,   126,   128,   132,   134,   138,   140,   144,   148,
     150,   154,   156,   160,   162,   166,   168,   173,   175,   177,
     182,   187,   189,   193,   195,   199,   201,   205,   207,   211,
     213,   216,   220,   222,   224,   226,   228,   230,   232,   234,
     236,   238,   240,   242,   247,   249,   253,   255,   259,   261,
     265,   269,   271,   275,   277,   281,   283,   285,   288,   291,
     293,   295,   297,   299,   301,   303,   305,   307,   309,   311,
     313,   315,   320,   323,   332,   339,   346,   351,   358,   363,
     368,   371,   380,   387,   394,   399,   406,   411,   416,   419,
     428,   435,   442,   447,   454,   459,   464,   467,   474,   479,
     484,   487,   494,   499,   504,   507,   512,   515,   524,   531,
     538,   543,   550,   555,   560,   563,   571,   577,   583,   587,
     595,   601,   607,   611,   613,   623,   631,   639,   645,   655,
     663,   671,   677,   688,   697,   706,   713,   722,   729,   736,
     741,   750,   757,   764,   769,   776,   781,   786,   789,   791,
     793,   795,   797,   801,   803,   806,   810,   814,   818,   822,
     824,   828,   830,   834,   838,   842,   844,   846,   848,   852,
     854,   858,   860,   863,   867,   873,   875,   877,   880,   883,
     886,   889,   894,   896,   900,   904,   908,   914,   916,   918,
     922,   926,   928,   931,   935,   939,   943,   947,   949,   953,
     955,   959,   963,   967,   969,   975,   977,   982,   984,   988,
     990,   992,   996,   998,  1000,  1002,  1004,  1006,  1010,  1012,
    1016,  1020,  1024,  1028,  1032,  1035,  1040,  1042,  1044,  1048,
    1050,  1052,  1054,  1057,  1059,  1063,  1065,  1069,  1073,  1077,
    1081,  1085,  1087,  1089,  1091,  1093,  1095,  1097,  1099,  1101,
    1104,  1107,  1109,  1111,  1113,  1115,  1117,  1119,  1121,  1123,
    1126,  1128
};

/* YYRHS -- A `-1'-separated list of the rules' RHS.  */
static const yytype_int16 yyrhs[] =
{
      94,     0,    -1,    -1,    95,    -1,    96,    -1,    95,    96,
      -1,    97,    -1,   109,    -1,   110,    -1,   164,    -1,   119,
      -1,   120,    -1,   128,    -1,   136,    -1,     1,    59,    -1,
      56,     8,    98,    59,    -1,    99,    -1,    57,    99,    58,
      -1,   100,    -1,    98,    61,   100,    -1,   101,    -1,    57,
     101,    58,    -1,   102,    62,   107,    -1,   103,    -1,    57,
     103,    58,    -1,   104,    -1,   102,    68,   104,    -1,   105,
      -1,    57,   105,    58,    -1,     4,    -1,     4,    57,   175,
      58,    -1,     4,    -1,     4,    57,   175,    58,    -1,   108,
      -1,    57,   108,    58,    -1,   125,    -1,   127,    57,   125,
      58,    -1,    22,    42,   106,    -1,    22,    57,   125,    58,
      42,   106,    -1,   180,    -1,    56,    37,    62,   182,    59,
      -1,    56,    11,   111,    59,    -1,   112,    -1,    57,   112,
      58,    -1,   113,    -1,   111,    61,   111,    -1,   114,    -1,
      57,   114,    58,    -1,   115,    62,   124,    -1,   116,    -1,
      57,   116,    58,    -1,   117,    -1,   115,    68,   117,    -1,
     118,    -1,    57,   118,    58,    -1,     4,    -1,     4,    57,
     175,    58,    -1,   182,    -1,   180,    -1,    56,    13,     1,
      59,    -1,    56,    14,   121,    59,    -1,   122,    -1,    57,
     122,    58,    -1,   123,    -1,   121,    61,   121,    -1,   125,
      -1,   125,    85,   121,    -1,   125,    -1,    57,   125,    58,
      -1,   126,    -1,   126,    88,    -1,   126,    83,    50,    -1,
       4,    -1,   127,    -1,    16,    -1,    17,    -1,    18,    -1,
      19,    -1,    30,    -1,    34,    -1,    44,    -1,    45,    -1,
      46,    -1,    56,    15,   129,    59,    -1,   130,    -1,    57,
     130,    58,    -1,   131,    -1,   131,    61,   129,    -1,   132,
      -1,    57,   132,    58,    -1,   133,    62,   135,    -1,   134,
      -1,    57,   134,    58,    -1,     4,    -1,   134,    68,     4,
      -1,   124,    -1,   180,    -1,   137,    59,    -1,   150,    59,
      -1,   138,    -1,   139,    -1,   140,    -1,   141,    -1,   142,
      -1,   143,    -1,   144,    -1,   145,    -1,   146,    -1,   147,
      -1,   148,    -1,   149,    -1,    21,   152,    48,   156,    -1,
      21,   152,    -1,    26,   152,    20,   152,    47,   172,    48,
     156,    -1,    26,   152,    20,   152,    48,   156,    -1,    26,
     152,    20,   152,    47,   172,    -1,    26,   152,    20,   152,
      -1,    26,   152,    47,   172,    48,   156,    -1,    26,   152,
      48,   156,    -1,    26,   152,    47,   172,    -1,    26,   152,
      -1,    28,   151,    31,   152,    20,   152,    48,   156,    -1,
      28,   151,    31,   152,    20,   152,    -1,    28,   151,    31,
     152,    48,   156,    -1,    28,   151,    31,   152,    -1,    28,
     151,    20,   152,    48,   156,    -1,    28,   151,    20,   152,
      -1,    28,   151,    48,   156,    -1,    28,   151,    -1,    29,
     172,    31,   152,    20,   152,    48,   156,    -1,    29,   172,
      31,   152,    20,   152,    -1,    29,   172,    20,   152,    48,
     156,    -1,    29,   172,    20,   152,    -1,    29,   172,    31,
     152,    48,   156,    -1,    29,   172,    31,   152,    -1,    29,
     172,    48,   156,    -1,    29,   172,    -1,    33,   172,    31,
     152,    48,   156,    -1,    33,   172,    31,   152,    -1,    33,
     172,    48,   156,    -1,    33,   172,    -1,    41,   152,    31,
     152,    48,   156,    -1,    41,   152,    31,   152,    -1,    41,
     152,    48,   156,    -1,    41,   152,    -1,    44,   172,    48,
     156,    -1,    44,   172,    -1,    43,   151,    31,   152,    20,
     152,    48,   156,    -1,    43,   151,    31,   152,    20,   152,
      -1,    43,   151,    31,   152,    48,   156,    -1,    43,   151,
      31,   152,    -1,    43,   151,    20,   152,    48,   156,    -1,
      43,   151,    20,   152,    -1,    43,   151,    48,   156,    -1,
      43,   151,    -1,   152,    36,   151,    31,   152,    48,   156,
      -1,   152,    36,   151,    31,   152,    -1,   152,    36,   151,
      48,   156,    -1,   152,    36,   151,    -1,   152,    25,   151,
      31,   152,    48,   156,    -1,   152,    25,   151,    31,   152,
      -1,   152,    25,   151,    48,   156,    -1,   152,    25,   151,
      -1,    40,    -1,   152,    32,   151,    23,   177,    31,   152,
      48,   156,    -1,   152,    32,   151,    23,   177,    31,   152,
      -1,   152,    32,   151,    23,   177,    48,   156,    -1,   152,
      32,   151,    23,   177,    -1,   152,    27,   151,    23,   177,
      31,   152,    48,   156,    -1,   152,    27,   151,    23,   177,
      31,   152,    -1,   152,    27,   151,    23,   177,    48,   156,
      -1,   152,    27,   151,    23,   177,    -1,    24,   151,    31,
     152,    20,   152,    47,   172,    48,   156,    -1,    24,   151,
      31,   152,    20,   152,    47,   172,    -1,    24,   151,    31,
     152,    20,   152,    48,   156,    -1,    24,   151,    31,   152,
      20,   152,    -1,    24,   151,    31,   152,    47,   172,    48,
     156,    -1,    24,   151,    31,   152,    47,   172,    -1,    24,
     151,    31,   152,    48,   156,    -1,    24,   151,    31,   152,
      -1,    24,   151,    20,   152,    47,   172,    48,   156,    -1,
      24,   151,    20,   152,    47,   172,    -1,    24,   151,    20,
     152,    48,   156,    -1,    24,   151,    20,   152,    -1,    24,
     151,    47,   172,    48,   156,    -1,    24,   151,    47,   172,
      -1,    24,   151,    48,   156,    -1,    24,   151,    -1,   157,
      -1,    51,    -1,    49,    -1,   153,    -1,    57,   153,    58,
      -1,   154,    -1,   186,   152,    -1,   152,   184,   152,    -1,
     152,   185,   152,    -1,   152,    69,   152,    -1,   152,    70,
     152,    -1,   155,    -1,    57,   155,    58,    -1,   176,    -1,
     176,   187,   176,    -1,   176,   188,   176,    -1,   176,   189,
     176,    -1,   160,    -1,   152,    -1,   158,    -1,    57,   158,
      58,    -1,   159,    -1,   157,   184,   157,    -1,   172,    -1,
     186,   172,    -1,   172,    80,   176,    -1,    54,   161,    60,
     152,    55,    -1,   162,    -1,   163,    -1,   161,   162,    -1,
     161,   163,    -1,    89,     4,    -1,    90,     4,    -1,    56,
      12,   165,    59,    -1,   166,    -1,   165,    61,   165,    -1,
      35,    62,     3,    -1,    38,    62,     3,    -1,    38,    62,
       3,    82,     3,    -1,   167,    -1,   168,    -1,    57,   167,
      58,    -1,   178,    67,   167,    -1,   169,    -1,   186,   167,
      -1,   167,   184,   167,    -1,   167,   185,   167,    -1,   167,
      69,   167,    -1,   167,    70,   167,    -1,   170,    -1,    57,
     170,    58,    -1,   176,    -1,   176,   187,   176,    -1,   176,
     188,   176,    -1,   176,   189,   176,    -1,   171,    -1,    54,
     161,    60,   167,    55,    -1,     4,    -1,     4,    57,   173,
      58,    -1,   174,    -1,   173,    68,   174,    -1,   177,    -1,
     125,    -1,   175,    68,   125,    -1,    51,    -1,    49,    -1,
      50,    -1,   177,    -1,   178,    -1,    57,   178,    58,    -1,
     179,    -1,   177,    83,   177,    -1,   177,    84,   177,    -1,
     177,    88,   177,    -1,   177,    87,   177,    -1,   177,    86,
     177,    -1,    52,   177,    -1,    52,    57,   177,    58,    -1,
     181,    -1,   172,    -1,   182,    82,   182,    -1,     3,    -1,
      37,    -1,    38,    -1,    84,   181,    -1,   183,    -1,    57,
     183,    58,    -1,   181,    -1,   182,    83,   182,    -1,   182,
      84,   182,    -1,   182,    88,   182,    -1,   182,    87,   182,
      -1,   182,    86,   182,    -1,    73,    -1,    72,    -1,    68,
      -1,    71,    -1,    84,    -1,    81,    -1,    80,    -1,    78,
      -1,    53,    77,    -1,    53,    76,    -1,    79,    -1,   190,
      -1,   191,    -1,   192,    -1,   193,    -1,    77,    -1,    76,
      -1,    75,    -1,    53,    75,    -1,    74,    -1,    53,    74,
      -1
};

/* YYRLINE[YYN] -- source line where rule number YYN was defined.  */
static const yytype_uint16 yyrline[] =
{
       0,   509,   509,   510,   513,   514,   517,   518,   519,   520,
     521,   522,   523,   524,   525,   539,   542,   543,   546,   547,
     550,   551,   554,   645,   649,   655,   664,   688,   692,   698,
     704,   725,   731,   745,   749,   755,   825,   882,   900,   929,
     973,   990,   993,   994,   997,   998,  1001,  1002,  1005,  1066,
    1070,  1076,  1086,  1110,  1114,  1120,  1126,  1143,  1149,  1158,
    1168,  1179,  1183,  1189,  1194,  1227,  1239,  1252,  1256,  1262,
    1266,  1272,  1281,  1285,  1291,  1297,  1303,  1309,  1315,  1321,
    1327,  1333,  1339,  1349,  1352,  1353,  1356,  1357,  1360,  1361,
    1364,  1384,  1388,  1394,  1430,  1470,  1484,  1518,  1519,  1522,
    1523,  1524,  1525,  1526,  1527,  1528,  1529,  1530,  1531,  1532,
    1533,  1537,  1548,  1560,  1573,  1585,  1597,  1608,  1620,  1631,
    1642,  1654,  1667,  1679,  1691,  1702,  1714,  1725,  1736,  1748,
    1761,  1773,  1785,  1796,  1808,  1819,  1830,  1842,  1854,  1865,
    1876,  1888,  1900,  1911,  1922,  1934,  1945,  1957,  1970,  1982,
    1994,  2005,  2017,  2028,  2039,  2051,  2064,  2076,  2088,  2101,
    2114,  2126,  2138,  2151,  2159,  2174,  2188,  2202,  2215,  2230,
    2244,  2258,  2273,  2283,  2292,  2301,  2309,  2318,  2326,  2334,
    2341,  2350,  2358,  2366,  2373,  2381,  2388,  2395,  2403,  2407,
    2414,  2423,  2427,  2438,  2442,  2449,  2457,  2465,  2473,  2483,
    2487,  2498,  2517,  2525,  2533,  2561,  2567,  2573,  2577,  2588,
    2592,  2602,  2606,  2613,  2654,  2668,  2677,  2686,  2718,  2752,
    2777,  2804,  2833,  2837,  2843,  2858,  2873,  2891,  2909,  2913,
    2922,  2945,  2949,  2956,  2964,  2972,  2980,  2990,  2994,  3005,
    3024,  3032,  3040,  3068,  3074,  3090,  3123,  3156,  3165,  3176,
    3182,  3203,  3230,  3237,  3244,  3251,  3257,  3261,  3273,  3277,
    3285,  3293,  3301,  3309,  3317,  3324,  3335,  3343,  3349,  3364,
    3369,  3374,  3379,  3388,  3392,  3402,  3406,  3415,  3424,  3433,
    3442,  3454,  3458,  3462,  3468,  3474,  3478,  3484,  3490,  3494,
    3499,  3506,  3510,  3514,  3518,  3522,  3528,  3534,  3540,  3544,
    3551,  3555
};
#endif

#if YYDEBUG || YYERROR_VERBOSE || YYTOKEN_TABLE
/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "\"end of file\"", "error", "$undefined", "T_INTEGER", "T_IDENTIFIER",
  "T_STRING", "T_ASP", "T_COMMENT", "T_CONSTANTS", "T_INCLUDE", "T_MACROS",
  "T_OBJECTS", "T_QUERY", "T_SHOW", "T_SORTS", "T_VARIABLES", "T_ABACTION",
  "T_ACTION", "T_ADDITIVEACTION", "T_ADDITIVEFLUENT", "T_AFTER",
  "T_ALWAYS", "T_ATTRIBUTE", "T_BY", "T_CAUSED", "T_CAUSES",
  "T_CONSTRAINT", "T_DECREMENTS", "T_DEFAULT", "T_EXOGENOUS",
  "T_EXOGENOUSACTION", "T_IF", "T_INCREMENTS", "T_INERTIAL",
  "T_INERTIALFLUENT", "T_LABEL", "T_MAY_CAUSE", "T_MAXADDITIVE",
  "T_MAXSTEP", "T_NEVER", "T_NOCONCURRENCY", "T_NONEXECUTABLE", "T_OF",
  "T_POSSIBLY_CAUSED", "T_RIGID", "T_SDFLUENT", "T_SIMPLEFLUENT",
  "T_UNLESS", "T_WHERE", "T_FALSE", "T_NONE", "T_TRUE", "T_ABS", "T_AT",
  "T_BRACKET_L", "T_BRACKET_R", "T_COLON_DASH", "T_PAREN_L", "T_PAREN_R",
  "T_PERIOD", "T_PIPE", "T_SEMICOLON", "T_DBL_COLON", "T_ARROW_LDASH",
  "T_ARROW_REQ", "T_ARROW_LEQ", "T_ARROW_RDASH", "T_COLON", "T_COMMA",
  "T_EQUIV", "T_IMPL", "T_DBL_PLUS", "T_DBL_AMP", "T_AMP", "T_GTHAN_EQ",
  "T_EQ_LTHAN", "T_GTHAN", "T_LTHAN", "T_NOT_EQ", "T_DBL_EQ", "T_EQ",
  "T_NOT", "T_DBL_PERIOD", "T_PLUS", "T_DASH", "T_DBL_GTHAN", "T_MOD",
  "T_INT_DIV", "T_STAR", "T_BIG_CONJ", "T_BIG_DISJ", "T_POUND", "T_UMINUS",
  "$accept", "program", "statement_sequence", "statement",
  "constant_statement", "constant_spec_outer_tuple", "constant_spec_tuple",
  "constant_outer_spec", "constant_spec", "constant_schema_outer_list",
  "constant_schema_list", "constant_outer_schema", "constant_schema",
  "constant_schema_nodecl", "constant_outer_binder", "constant_binder",
  "maxadditive_statement", "object_statement", "object_spec_outer_tuple",
  "object_spec_tuple", "object_outer_spec", "object_spec",
  "object_outer_schema_list", "object_schema_list", "object_outer_schema",
  "object_schema", "show_statement", "sort_statement",
  "sort_spec_outer_tuple", "sort_spec_tuple", "sort_spec",
  "sort_outer_identifier", "sort_identifier", "sort_identifier_name",
  "sort_constant_name", "variable_statement", "variable_spec_outer_tuple",
  "variable_spec_tuple", "variable_outer_spec", "variable_spec",
  "variable_outer_list", "variable_list", "variable_binding", "causal_law",
  "causal_law_shortcut_forms", "cl_always_forms", "cl_constraint_forms",
  "cl_default_forms", "cl_exogenous_forms", "cl_inertial_forms",
  "cl_nonexecutable_forms", "cl_rigid_forms", "cl_possibly_caused_forms",
  "cl_may_cause_forms", "cl_causes_forms", "cl_noconcurrency_forms",
  "cl_increment_forms", "causal_law_basic_forms", "cl_head_formula",
  "cl_body_formula", "cl_body_formula_inner", "cl_body_term",
  "cl_body_term_inner", "cl_where_expr", "literal_assign_conj",
  "literal_assign_conj_inner", "literal_assign_expr",
  "expr_big_expression", "expr_big_quantifiers", "expr_big_conj",
  "expr_big_disj", "query_statement", "query_expression_tuple",
  "query_expression", "query_body_formula", "query_body_formula_inner",
  "query_body_term", "query_body_term_inner", "expr_big_query_expression",
  "constant_expr", "parameter_list", "parameter_general",
  "sort_identifier_list", "extended_value_expression",
  "extended_math_expression", "extended_math_expr_inner",
  "extended_math_term", "num_range", "extended_integer",
  "extended_integer_outer_expression", "extended_integer_expression",
  "AND", "OR", "NOT", "EQUALS", "NOT_EQUALS", "COMPARISON", "LESS_THAN",
  "GREATER_THAN", "LESS_THAN_EQ", "GREATER_THAN_EQ", 0
};
#endif

# ifdef YYPRINT
/* YYTOKNUM[YYLEX-NUM] -- Internal token number corresponding to
   token YYLEX-NUM.  */
static const yytype_uint16 yytoknum[] =
{
       0,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,   283,   284,
     285,   286,   287,   288,   289,   290,   291,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,   302,   303,   304,
     305,   306,   307,   308,   309,   310,   311,   312,   313,   314,
     315,   316,   317,   318,   319,   320,   321,   322,   323,   324,
     325,   326,   327,   328,   329,   330,   331,   332,   333,   334,
     335,   336,   337,   338,   339,   340,   341,   342,   343,   344,
     345,   346,   347
};
# endif

/* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const yytype_uint8 yyr1[] =
{
       0,    93,    94,    94,    95,    95,    96,    96,    96,    96,
      96,    96,    96,    96,    96,    97,    98,    98,    99,    99,
     100,   100,   101,   102,   102,   103,   103,   104,   104,   105,
     105,   106,   106,   107,   107,   108,   108,   108,   108,   108,
     109,   110,   111,   111,   112,   112,   113,   113,   114,   115,
     115,   116,   116,   117,   117,   118,   118,   118,   118,   119,
     120,   121,   121,   122,   122,   123,   123,   124,   124,   125,
     125,   125,   126,   126,   127,   127,   127,   127,   127,   127,
     127,   127,   127,   128,   129,   129,   130,   130,   131,   131,
     132,   133,   133,   134,   134,   135,   135,   136,   136,   137,
     137,   137,   137,   137,   137,   137,   137,   137,   137,   137,
     137,   138,   138,   139,   139,   139,   139,   139,   139,   139,
     139,   140,   140,   140,   140,   140,   140,   140,   140,   141,
     141,   141,   141,   141,   141,   141,   141,   142,   142,   142,
     142,   143,   143,   143,   143,   144,   144,   145,   145,   145,
     145,   145,   145,   145,   145,   146,   146,   146,   146,   147,
     147,   147,   147,   148,   149,   149,   149,   149,   149,   149,
     149,   149,   150,   150,   150,   150,   150,   150,   150,   150,
     150,   150,   150,   150,   150,   150,   150,   150,   151,   151,
     151,   152,   152,   153,   153,   153,   153,   153,   153,   154,
     154,   155,   155,   155,   155,   155,   156,   157,   157,   158,
     158,   159,   159,   159,   160,   161,   161,   161,   161,   162,
     163,   164,   165,   165,   166,   166,   166,   166,   167,   167,
     167,   168,   168,   168,   168,   168,   168,   169,   169,   170,
     170,   170,   170,   170,   171,   172,   172,   173,   173,   174,
     175,   175,   176,   176,   176,   176,   177,   177,   178,   178,
     178,   178,   178,   178,   178,   178,   179,   179,   180,   181,
     181,   181,   181,   182,   182,   183,   183,   183,   183,   183,
     183,   184,   184,   184,   185,   186,   186,   187,   188,   188,
     188,   189,   189,   189,   189,   189,   190,   191,   192,   192,
     193,   193
};

/* YYR2[YYN] -- Number of symbols composing right hand side of rule YYN.  */
static const yytype_uint8 yyr2[] =
{
       0,     2,     0,     1,     1,     2,     1,     1,     1,     1,
       1,     1,     1,     1,     2,     4,     1,     3,     1,     3,
       1,     3,     3,     1,     3,     1,     3,     1,     3,     1,
       4,     1,     4,     1,     3,     1,     4,     3,     6,     1,
       5,     4,     1,     3,     1,     3,     1,     3,     3,     1,
       3,     1,     3,     1,     3,     1,     4,     1,     1,     4,
       4,     1,     3,     1,     3,     1,     3,     1,     3,     1,
       2,     3,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     4,     1,     3,     1,     3,     1,     3,
       3,     1,     3,     1,     3,     1,     1,     2,     2,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     4,     2,     8,     6,     6,     4,     6,     4,     4,
       2,     8,     6,     6,     4,     6,     4,     4,     2,     8,
       6,     6,     4,     6,     4,     4,     2,     6,     4,     4,
       2,     6,     4,     4,     2,     4,     2,     8,     6,     6,
       4,     6,     4,     4,     2,     7,     5,     5,     3,     7,
       5,     5,     3,     1,     9,     7,     7,     5,     9,     7,
       7,     5,    10,     8,     8,     6,     8,     6,     6,     4,
       8,     6,     6,     4,     6,     4,     4,     2,     1,     1,
       1,     1,     3,     1,     2,     3,     3,     3,     3,     1,
       3,     1,     3,     3,     3,     1,     1,     1,     3,     1,
       3,     1,     2,     3,     5,     1,     1,     2,     2,     2,
       2,     4,     1,     3,     3,     3,     5,     1,     1,     3,
       3,     1,     2,     3,     3,     3,     3,     1,     3,     1,
       3,     3,     3,     1,     5,     1,     4,     1,     3,     1,
       1,     3,     1,     1,     1,     1,     1,     3,     1,     3,
       3,     3,     3,     3,     2,     4,     1,     1,     3,     1,
       1,     1,     2,     1,     3,     1,     3,     3,     3,     3,
       3,     1,     1,     1,     1,     1,     1,     1,     1,     2,
       2,     1,     1,     1,     1,     1,     1,     1,     1,     2,
       1,     2
};

/* YYDEFACT[STATE-NAME] -- Default rule to reduce with in state
   STATE-NUM when YYTABLE doesn't specify something else to do.  Zero
   means the default is an error.  */
static const yytype_uint16 yydefact[] =
{
       0,     0,   269,   245,     0,     0,     0,     0,     0,     0,
     270,   271,   163,     0,     0,     0,   253,   254,   252,     0,
       0,     0,     0,   286,   285,     0,     0,     4,     6,     7,
       8,    10,    11,    12,    13,     0,    99,   100,   101,   102,
     103,   104,   105,   106,   107,   108,   109,   110,     0,     0,
     191,   193,   199,   205,     9,   267,   201,   255,   256,   258,
     266,     0,    14,     0,   112,   190,   189,     0,   285,   187,
     188,   207,   209,   211,     0,   120,   128,   136,   140,   144,
     154,   146,     0,     0,   264,     0,     0,     0,   215,   216,
       0,     0,     0,     0,     0,     0,     0,     0,   191,   199,
     256,   272,     1,     5,    97,    98,     0,     0,     0,     0,
     283,     0,     0,   284,   282,   281,     0,     0,     0,   300,
     298,   297,   296,   288,   291,   287,     0,     0,     0,   292,
     293,   294,   295,     0,     0,     0,     0,     0,   194,     0,
       0,   247,   249,     0,     0,   207,     0,     0,     0,     0,
       0,     0,   212,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   219,   220,     0,   217,   218,    29,     0,     0,    16,
      18,    20,     0,    23,    25,    27,    55,     0,     0,    42,
      44,    46,     0,    49,    51,    53,    58,   275,    57,   273,
       0,   271,     0,     0,     0,   222,   227,   228,   231,   237,
     243,   239,   256,     0,     0,    72,    74,    75,    76,    77,
      78,    79,    80,    81,    82,     0,     0,    61,    63,    65,
      69,    73,    93,     0,     0,    84,    86,    88,     0,    91,
       0,   192,   200,   257,   162,     0,     0,   158,   197,   198,
     195,   196,   301,   299,   290,   289,   202,   203,   204,   259,
     260,   263,   262,   261,     0,   246,     0,   206,   111,   208,
     183,   179,   185,   186,   210,   213,   116,   119,   118,   126,
     124,   127,   132,   134,   135,   138,   139,   142,   143,   152,
     150,   153,   145,   265,     0,     0,     0,    16,    20,    23,
      27,    15,     0,     0,     0,     0,     0,    42,    46,    49,
      53,   273,    41,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   237,   256,   221,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   232,    59,
       0,    61,    60,     0,     0,     0,    70,     0,     0,    88,
      91,    83,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   248,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   214,   250,     0,    17,    21,    24,
      28,     0,    19,     0,     0,    22,    33,    35,    73,    39,
       0,     0,    26,     0,    43,    47,    50,    54,   274,    45,
       0,    48,    67,     0,    52,   268,   276,   277,   280,   279,
     278,   224,   225,     0,   229,   238,   223,   235,   236,   233,
     234,   240,   241,   242,   230,    62,    64,    66,    71,     0,
       0,    85,    89,    92,    87,     0,    95,    90,    96,    94,
       0,    40,   160,   161,   171,   167,   156,   157,   181,   182,
     175,   177,   178,   184,   115,   114,   117,   125,   122,   123,
     131,   130,   133,   137,   141,   151,   148,   149,    30,     0,
       0,     0,     0,     0,     0,     0,     0,    56,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   251,     0,    31,
      37,     0,    34,     0,    68,   226,   244,   159,   169,   170,
     165,   166,   155,   180,   173,   174,   176,   113,   121,   129,
     147,     0,     0,    36,     0,     0,     0,     0,     0,   168,
     164,   172,    32,    38
};

/* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int16 yydefgoto[] =
{
      -1,    25,    26,    27,    28,   178,   179,   180,   181,   182,
     299,   184,   185,   510,   395,   396,    29,    30,   188,   189,
     190,   191,   192,   193,   194,   195,    31,    32,   226,   227,
     228,   411,   229,   230,   231,    33,   234,   235,   236,   237,
     238,   239,   447,    34,    35,    36,    37,    38,    39,    40,
      41,    42,    43,    44,    45,    46,    47,    48,    69,   267,
      50,    51,    52,   268,    70,    71,    72,    53,    87,    88,
      89,    54,   204,   205,   206,   207,   208,   209,   210,    55,
     140,   141,   386,    56,    57,    58,    59,   196,    60,   198,
     199,   116,   117,    61,   126,   127,   128,   129,   130,   131,
     132
};

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
#define YYPACT_NINF -289
static const yytype_int16 yypact[] =
{
     540,   -27,  -289,    -5,   451,   207,   451,   207,    37,    37,
    -289,  -289,  -289,   451,   207,    37,  -289,  -289,  -289,   289,
      50,   191,   451,  -289,    85,    80,   599,  -289,  -289,  -289,
    -289,  -289,  -289,  -289,  -289,    59,  -289,  -289,  -289,  -289,
    -289,  -289,  -289,  -289,  -289,  -289,  -289,  -289,    66,   836,
    -289,  -289,  -289,  -289,  -289,  -289,   817,   547,  -289,  -289,
    -289,   451,  -289,   291,   877,  -289,  -289,    98,  -289,   214,
     248,  -289,  -289,     2,    37,   395,   237,   258,     7,   816,
     259,    58,   291,    70,   547,   105,   159,    53,  -289,  -289,
      29,   355,   691,   157,   760,    32,   118,  1012,   142,   160,
     238,  -289,  -289,  -289,  -289,  -289,   207,   207,   207,   207,
    -289,   451,   451,  -289,  -289,  -289,   451,   451,   447,  -289,
    -289,  -289,  -289,  -289,  -289,  -289,   663,   663,   663,  -289,
    -289,  -289,  -289,   291,   291,   291,   291,   291,  -289,   291,
     123,  -289,   547,   451,   248,   260,   451,   451,    37,   451,
      98,   663,  -289,   451,    37,   451,   451,   451,   451,   451,
     451,   451,   451,   451,   451,   451,   451,   451,   451,   451,
     321,  -289,  -289,   451,  -289,  -289,   226,    29,   136,  -289,
    -289,  -289,   130,  -289,  -289,  -289,   268,   355,   204,  -289,
    -289,  -289,   246,  -289,  -289,  -289,  -289,  -289,   524,  -289,
     270,   272,    50,   701,   225,  -289,  1018,  -289,  -289,  -289,
    -289,   817,   269,   701,   271,  -289,  -289,  -289,  -289,  -289,
    -289,  -289,  -289,  -289,  -289,   760,   263,  -289,  -289,   250,
      49,  -289,  -289,    33,   285,  -289,   284,  -289,   287,   279,
      21,  -289,  -289,  -289,     9,   329,   333,    23,   690,   651,
    1012,  1012,  -289,  -289,  -289,  -289,  -289,  -289,  -289,    10,
      10,  -289,  -289,  -289,   547,  -289,   291,  1012,  -289,  -289,
     851,   761,   312,  -289,   248,  -289,   863,   319,  -289,   895,
     545,  -289,   903,   771,  -289,   909,  -289,   921,  -289,   935,
     787,  -289,  -289,  -289,   999,   832,   309,   314,   318,   322,
     325,  -289,    38,   453,    43,   832,   324,   328,   330,   331,
     353,   358,  -289,   355,   780,   525,    21,    21,    21,    21,
      21,    21,   388,   410,    55,   446,   360,   -28,  -289,   691,
     701,   701,   701,   701,   663,   663,   663,   701,  -289,  -289,
     375,   361,  -289,   760,   760,   387,  -289,    44,   382,   383,
     128,  -289,    32,    47,   440,    21,   394,   451,   451,   291,
     291,   451,   451,  -289,    37,   451,   451,    37,   451,   451,
      37,   451,   451,   451,   451,   451,   451,   451,   451,   451,
     451,   451,   451,   451,  -289,  -289,   154,  -289,  -289,  -289,
    -289,    95,  -289,   -11,   641,  -289,  -289,  -289,   389,  -289,
     524,   441,  -289,   165,  -289,  -289,  -289,  -289,  -289,   324,
     832,  -289,  -289,   729,  -289,   586,   308,   308,  -289,  -289,
    -289,  -289,   376,   701,  -289,  -289,   398,   810,   664,  1018,
    1018,  -289,  -289,  -289,  1018,  -289,   375,  -289,  -289,   456,
     383,  -289,  -289,  -289,  -289,   673,  -289,  -289,  -289,  -289,
     586,  -289,   947,  -289,   183,   267,   953,  -289,   426,  -289,
     869,   428,  -289,  -289,   431,  -289,  -289,  -289,   961,  -289,
    -289,   979,  -289,  -289,  -289,  -289,   987,  -289,  -289,   832,
      95,   318,   481,   832,   435,   832,   325,  -289,   437,   353,
     503,  1024,   128,   451,   451,   451,   451,   451,   451,   451,
      37,   451,   451,   451,   451,   451,   451,  -289,   444,   452,
    -289,   468,  -289,   469,  -289,  -289,  -289,  -289,   993,  -289,
    1005,  -289,  -289,  -289,   482,  -289,  -289,  -289,  -289,  -289,
    -289,   832,   489,  -289,   451,   451,   451,   174,   481,  -289,
    -289,  -289,  -289,  -289
};

/* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
    -289,  -289,  -289,   507,  -289,   357,   359,   236,  -166,    62,
     -76,   235,  -161,     8,  -289,   158,  -289,  -289,  -175,   373,
    -289,   380,  -289,   384,   233,  -184,  -289,  -289,  -210,   345,
    -289,   219,    28,  -289,  -280,  -289,   222,   342,  -289,  -212,
    -289,  -223,  -289,  -289,  -289,  -289,  -289,  -289,  -289,  -289,
    -289,  -289,  -289,  -289,  -289,  -289,  -289,  -289,    42,     0,
     557,  -289,   563,    52,   -47,   528,  -289,  -289,   396,   -80,
     -69,  -289,   275,  -289,  -143,  -289,  -289,   402,  -289,    20,
    -289,   335,  -288,   -83,   102,   -20,  -289,  -284,   -16,   131,
    -186,   -65,  -153,    69,   408,   411,   415,  -289,  -289,  -289,
    -289
};

/* YYTABLE[YYPACT[STATE-NUM]].  What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule which
   number is the opposite.  If zero, do what YYDEFACT says.
   If YYTABLE_NINF, syntax error.  */
#define YYTABLE_NINF -4
static const yytype_int16 yytable[] =
{
      49,   311,   100,   310,    64,   150,    75,   174,   101,   211,
     350,   298,   306,    79,   183,   340,   300,   403,   175,   399,
     144,   349,    97,   398,     2,    73,    49,    73,    77,    78,
     243,   482,    62,   176,    73,    81,   232,   232,   162,   337,
     357,     3,   176,   256,   257,   258,   483,   176,   232,    76,
       2,   215,    63,   333,   361,   163,    80,   358,    10,    11,
     325,   138,   100,   216,   217,   218,   219,   101,   275,   448,
     338,   362,   212,     2,    74,   197,    74,   220,   355,   150,
     102,   221,   151,    74,    10,    11,   177,    73,     2,   233,
     347,   222,   223,   224,   152,   391,   135,   136,   137,   176,
     401,   439,     3,   274,   445,    83,   169,    10,    11,   171,
     399,   248,   249,   173,   398,   423,   250,   251,   104,   100,
     211,    84,    10,    11,   350,   105,    73,    73,    73,    73,
     211,    83,   345,   436,   437,   440,    74,   346,   409,    85,
      86,   332,    85,    86,    85,    86,   270,   271,   244,   245,
     246,   247,   480,   276,    83,    67,   279,   280,   214,   282,
     283,   213,   285,   172,   287,   142,   289,   290,   272,   311,
      73,   197,   333,   294,   277,    74,    74,    74,    74,    23,
     240,   265,    68,   327,   170,   333,   443,   427,   428,   429,
     430,   266,   303,   212,   434,   301,   354,   302,   304,    90,
     241,   273,    91,    92,    93,    94,    95,   278,   311,   150,
     281,     3,   478,   284,   494,   286,   492,   288,   242,    74,
     291,   292,   479,   487,   197,   481,   183,   311,    96,   489,
     300,   495,   542,   479,   146,   259,   260,   261,   262,   263,
     486,   264,   479,   537,   174,   147,   211,   211,   211,   211,
     211,   431,   432,   433,   211,   175,    65,   156,    66,   311,
     332,   148,   149,   312,    67,   313,   133,   134,   157,   135,
     136,   137,   213,   332,   333,   333,   333,   333,   159,   166,
     491,   333,   213,   295,   328,   158,   329,   197,    23,   160,
     167,    68,     2,     3,     2,     3,   243,   197,   496,   197,
     197,   197,   197,   197,   197,   197,   161,   168,   314,   212,
     212,   212,   212,   212,   315,   497,   110,   212,   269,   300,
     114,   115,   342,   385,   343,   305,    10,    11,    10,    11,
     339,   397,   322,   385,   323,   344,   337,   197,   333,   197,
     211,    19,   412,    19,   351,   352,    82,   354,   139,   353,
     133,   134,   359,   135,   136,   137,   360,   452,     2,   186,
     369,   456,   332,   332,   332,   332,   460,   372,   142,   332,
     302,   356,   387,    83,   468,    83,   388,   471,   197,   293,
     389,   412,   476,   390,   458,   313,   404,   461,   405,   406,
     464,   421,    10,    11,   319,   320,   321,   197,   213,   213,
     213,   213,   213,   212,   133,   134,   213,   135,   136,   137,
     453,   407,   187,   422,   457,   153,   408,   459,   425,   435,
     462,   463,   397,   465,   466,   467,   332,   469,   470,   197,
     472,   473,   474,   475,   400,   477,   343,   438,   488,    83,
     441,   442,   154,   155,   449,   176,   485,   415,   416,   417,
     418,   419,   420,   451,     2,     3,     2,   215,   490,   329,
     232,   454,   455,   110,   111,   112,   113,   114,   115,   216,
     217,   218,   219,   488,   499,   393,   502,   317,   318,   503,
     319,   320,   321,   220,   400,   509,   450,   221,    10,    11,
      10,    11,   213,   512,   518,   514,   520,   222,   223,   224,
      16,    17,    18,    19,   424,    20,   515,   507,    22,   531,
     394,   511,   304,   513,   110,   330,   331,   113,   114,   115,
     524,   252,   253,   254,   255,   400,   532,   533,     2,   186,
     536,   538,    23,   103,   296,    24,   297,    83,   392,   402,
      -2,     1,   508,     2,     3,   517,   543,   519,   414,   521,
     522,   523,   484,   525,   526,   527,   528,   529,   530,   385,
     307,     4,    10,    11,     5,   374,     6,   308,     7,     8,
     341,   309,   446,     9,   444,   348,   450,    10,    11,    98,
      12,    13,   413,    14,    15,    99,   539,   540,   541,    16,
      17,    18,    19,   375,    20,   145,    21,    22,   324,    -3,
       1,   363,     2,     3,   426,   326,   316,   317,   318,    83,
     319,   320,   321,   110,   111,   112,   113,   114,   115,   334,
       4,    23,   335,     5,    24,     6,   336,     7,     8,     0,
     133,   134,     9,   135,   136,   137,    10,    11,     0,    12,
      13,     0,    14,    15,     2,   215,     0,     0,    16,    17,
      18,    19,     0,    20,     0,    21,    22,   216,   217,   218,
     219,     0,     0,   393,     0,     0,     2,     3,     0,   317,
     318,   220,   319,   320,   321,   221,     2,   215,    10,    11,
      23,     0,     0,    24,     0,   222,   223,   224,     0,   216,
     217,   218,   219,     0,     2,     3,     0,     0,   355,     0,
      10,    11,     0,   220,     2,     3,     0,   221,     0,     0,
      10,    11,    16,    17,    18,    19,     0,   222,   223,   224,
     139,   112,   113,   114,   115,    83,   200,     0,    10,   201,
     355,     0,     2,   186,   331,   113,   114,   115,    10,    11,
      16,    17,    18,    19,     0,   202,     0,    83,   203,     0,
      16,    17,    18,    19,     0,   202,     0,    83,   203,   111,
     112,   113,   114,   115,   215,     0,    10,    11,     0,     0,
       0,     0,    23,     0,     0,    24,   216,   217,   218,   219,
       0,   366,    23,     0,   215,    24,   355,     0,     0,     0,
     220,   377,     0,     0,   221,     0,   216,   217,   218,   219,
       0,     0,     0,     0,   222,   223,   224,   382,   367,   368,
     220,     0,     0,    83,   221,     0,     0,   225,     0,   378,
       0,     0,     0,     0,   222,   223,   224,     0,     0,   110,
     111,   112,   113,   114,   115,   383,   215,   410,     0,   110,
     111,   112,   113,   114,   115,     0,     0,   164,   216,   217,
     218,   219,     0,     0,     0,   110,   111,   112,   113,   114,
     115,   106,   220,   107,   165,     0,   221,     0,   108,     0,
     118,     0,   109,     0,     0,     0,   222,   223,   224,   330,
     331,   113,   114,   115,   110,   111,   112,   113,   114,   115,
       0,   119,   120,   121,   122,   123,   124,   125,   364,   365,
       0,     0,     0,     0,   110,   111,   112,   113,   114,   115,
     370,   371,     0,     0,     0,     0,   500,   501,     0,   110,
     111,   112,   113,   114,   115,   143,     0,     0,     0,     0,
       0,   110,   111,   112,   113,   114,   115,   110,   111,   112,
     113,   114,   115,   373,     0,   110,   111,   112,   113,   114,
     115,   376,     0,     0,     0,     0,     0,   379,     0,     0,
       0,     0,     0,   110,   111,   112,   113,   114,   115,   380,
       0,   110,   111,   112,   113,   114,   115,   110,   111,   112,
     113,   114,   115,   381,     0,     0,     0,     0,     0,   110,
     111,   112,   113,   114,   115,   493,     0,     0,     0,     0,
       0,   498,     0,   110,   111,   112,   113,   114,   115,   504,
       0,     0,     0,     0,     0,   110,   111,   112,   113,   114,
     115,   110,   111,   112,   113,   114,   115,   505,     0,   110,
     111,   112,   113,   114,   115,   506,     0,     0,     0,     0,
       0,   534,     0,     0,     0,     0,     0,   110,   111,   112,
     113,   114,   115,   535,   384,   110,   111,   112,   113,   114,
     115,   110,   111,   112,   113,   114,   115,   110,   111,   112,
     113,   114,   115,   110,   111,   112,   113,   114,   115,   516,
     110,   111,   112,   113,   114,   115,   110,   330,   331,   113,
     114,   115,   110,   330,   331,   113,   114,   115
};

static const yytype_int16 yycheck[] =
{
       0,   187,    22,   187,     4,    70,     6,    87,    24,    92,
     233,   177,   187,    13,    90,   225,   177,   305,    87,   303,
      67,   233,    22,   303,     3,     5,    26,     7,     8,     9,
      58,    42,    59,     4,    14,    15,     4,     4,    31,    67,
      31,     4,     4,   126,   127,   128,    57,     4,     4,     7,
       3,     4,    57,   206,    31,    48,    14,    48,    37,    38,
     203,    61,    82,    16,    17,    18,    19,    83,   151,   353,
     213,    48,    92,     3,     5,    91,     7,    30,    57,   144,
       0,    34,    80,    14,    37,    38,    57,    67,     3,    57,
      57,    44,    45,    46,    74,    57,    86,    87,    88,     4,
      57,    57,     4,   150,    57,    84,    48,    37,    38,     4,
     394,   111,   112,    60,   394,    60,   116,   117,    59,   139,
     203,    19,    37,    38,   347,    59,   106,   107,   108,   109,
     213,    84,    83,   343,   344,   347,    67,    88,   313,    89,
      90,   206,    89,    90,    89,    90,   146,   147,   106,   107,
     108,   109,    57,   153,    84,    57,   156,   157,     1,   159,
     160,    92,   162,     4,   164,    63,   166,   167,   148,   355,
     150,   187,   325,   173,   154,   106,   107,   108,   109,    81,
      62,    58,    84,   203,    82,   338,    58,   330,   331,   332,
     333,    68,    62,   213,   337,    59,    68,    61,    68,     8,
      58,   149,    11,    12,    13,    14,    15,   155,   394,   274,
     158,     4,    58,   161,    31,   163,   439,   165,    58,   150,
     168,   169,    68,    58,   240,   391,   302,   413,    37,   413,
     391,    48,    58,    68,    20,   133,   134,   135,   136,   137,
     401,   139,    68,   531,   324,    31,   329,   330,   331,   332,
     333,   334,   335,   336,   337,   324,    49,    20,    51,   445,
     325,    47,    48,    59,    57,    61,    83,    84,    31,    86,
      87,    88,   203,   338,   427,   428,   429,   430,    20,    20,
     423,   434,   213,    57,    59,    48,    61,   303,    81,    31,
      31,    84,     3,     4,     3,     4,    58,   313,    31,   315,
     316,   317,   318,   319,   320,   321,    48,    48,    62,   329,
     330,   331,   332,   333,    68,    48,    68,   337,    58,   480,
      72,    73,    59,   295,    61,    57,    37,    38,    37,    38,
      59,   303,    62,   305,    62,    85,    67,   353,   491,   355,
     423,    52,   314,    52,    59,    61,    57,    68,    57,    62,
      83,    84,    23,    86,    87,    88,    23,   357,     3,     4,
      48,   361,   427,   428,   429,   430,   366,    48,   266,   434,
      61,   240,    58,    84,   374,    84,    58,   377,   394,    58,
      58,   353,   382,    58,   364,    61,    58,   367,    58,    58,
     370,     3,    37,    38,    86,    87,    88,   413,   329,   330,
     331,   332,   333,   423,    83,    84,   337,    86,    87,    88,
     358,    58,    57,     3,   362,    20,    58,   365,    58,    58,
     368,   369,   394,   371,   372,   373,   491,   375,   376,   445,
     378,   379,   380,   381,   303,   383,    61,    50,   410,    84,
      58,    58,    47,    48,     4,     4,    57,   316,   317,   318,
     319,   320,   321,    59,     3,     4,     3,     4,    82,    61,
       4,   359,   360,    68,    69,    70,    71,    72,    73,    16,
      17,    18,    19,   445,    48,    22,    48,    83,    84,    48,
      86,    87,    88,    30,   353,     4,   355,    34,    37,    38,
      37,    38,   423,    58,   494,    58,   496,    44,    45,    46,
      49,    50,    51,    52,    58,    54,     3,   479,    57,    57,
      57,   483,    68,   485,    68,    69,    70,    71,    72,    73,
     500,    74,    75,    76,    77,   394,    58,    58,     3,     4,
      48,    42,    81,    26,   177,    84,   177,    84,   302,   304,
       0,     1,   480,     3,     4,   493,   538,   495,   315,   497,
     498,   499,   394,   501,   502,   503,   504,   505,   506,   531,
     187,    21,    37,    38,    24,    20,    26,   187,    28,    29,
     225,   187,   353,    33,   352,   233,   445,    37,    38,    22,
      40,    41,    57,    43,    44,    22,   534,   535,   536,    49,
      50,    51,    52,    48,    54,    67,    56,    57,   202,     0,
       1,   266,     3,     4,   329,   203,    82,    83,    84,    84,
      86,    87,    88,    68,    69,    70,    71,    72,    73,   211,
      21,    81,   211,    24,    84,    26,   211,    28,    29,    -1,
      83,    84,    33,    86,    87,    88,    37,    38,    -1,    40,
      41,    -1,    43,    44,     3,     4,    -1,    -1,    49,    50,
      51,    52,    -1,    54,    -1,    56,    57,    16,    17,    18,
      19,    -1,    -1,    22,    -1,    -1,     3,     4,    -1,    83,
      84,    30,    86,    87,    88,    34,     3,     4,    37,    38,
      81,    -1,    -1,    84,    -1,    44,    45,    46,    -1,    16,
      17,    18,    19,    -1,     3,     4,    -1,    -1,    57,    -1,
      37,    38,    -1,    30,     3,     4,    -1,    34,    -1,    -1,
      37,    38,    49,    50,    51,    52,    -1,    44,    45,    46,
      57,    70,    71,    72,    73,    84,    35,    -1,    37,    38,
      57,    -1,     3,     4,    70,    71,    72,    73,    37,    38,
      49,    50,    51,    52,    -1,    54,    -1,    84,    57,    -1,
      49,    50,    51,    52,    -1,    54,    -1,    84,    57,    69,
      70,    71,    72,    73,     4,    -1,    37,    38,    -1,    -1,
      -1,    -1,    81,    -1,    -1,    84,    16,    17,    18,    19,
      -1,    20,    81,    -1,     4,    84,    57,    -1,    -1,    -1,
      30,    20,    -1,    -1,    34,    -1,    16,    17,    18,    19,
      -1,    -1,    -1,    -1,    44,    45,    46,    20,    47,    48,
      30,    -1,    -1,    84,    34,    -1,    -1,    57,    -1,    48,
      -1,    -1,    -1,    -1,    44,    45,    46,    -1,    -1,    68,
      69,    70,    71,    72,    73,    48,     4,    57,    -1,    68,
      69,    70,    71,    72,    73,    -1,    -1,    31,    16,    17,
      18,    19,    -1,    -1,    -1,    68,    69,    70,    71,    72,
      73,    25,    30,    27,    48,    -1,    34,    -1,    32,    -1,
      53,    -1,    36,    -1,    -1,    -1,    44,    45,    46,    69,
      70,    71,    72,    73,    68,    69,    70,    71,    72,    73,
      -1,    74,    75,    76,    77,    78,    79,    80,    47,    48,
      -1,    -1,    -1,    -1,    68,    69,    70,    71,    72,    73,
      47,    48,    -1,    -1,    -1,    -1,    47,    48,    -1,    68,
      69,    70,    71,    72,    73,    48,    -1,    -1,    -1,    -1,
      -1,    68,    69,    70,    71,    72,    73,    68,    69,    70,
      71,    72,    73,    48,    -1,    68,    69,    70,    71,    72,
      73,    48,    -1,    -1,    -1,    -1,    -1,    48,    -1,    -1,
      -1,    -1,    -1,    68,    69,    70,    71,    72,    73,    48,
      -1,    68,    69,    70,    71,    72,    73,    68,    69,    70,
      71,    72,    73,    48,    -1,    -1,    -1,    -1,    -1,    68,
      69,    70,    71,    72,    73,    48,    -1,    -1,    -1,    -1,
      -1,    48,    -1,    68,    69,    70,    71,    72,    73,    48,
      -1,    -1,    -1,    -1,    -1,    68,    69,    70,    71,    72,
      73,    68,    69,    70,    71,    72,    73,    48,    -1,    68,
      69,    70,    71,    72,    73,    48,    -1,    -1,    -1,    -1,
      -1,    48,    -1,    -1,    -1,    -1,    -1,    68,    69,    70,
      71,    72,    73,    48,    55,    68,    69,    70,    71,    72,
      73,    68,    69,    70,    71,    72,    73,    68,    69,    70,
      71,    72,    73,    68,    69,    70,    71,    72,    73,    55,
      68,    69,    70,    71,    72,    73,    68,    69,    70,    71,
      72,    73,    68,    69,    70,    71,    72,    73
};

/* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
   symbol of state STATE-NUM.  */
static const yytype_uint8 yystos[] =
{
       0,     1,     3,     4,    21,    24,    26,    28,    29,    33,
      37,    38,    40,    41,    43,    44,    49,    50,    51,    52,
      54,    56,    57,    81,    84,    94,    95,    96,    97,   109,
     110,   119,   120,   128,   136,   137,   138,   139,   140,   141,
     142,   143,   144,   145,   146,   147,   148,   149,   150,   152,
     153,   154,   155,   160,   164,   172,   176,   177,   178,   179,
     181,   186,    59,    57,   152,    49,    51,    57,    84,   151,
     157,   158,   159,   172,   186,   152,   151,   172,   172,   152,
     151,   172,    57,    84,   177,    89,    90,   161,   162,   163,
       8,    11,    12,    13,    14,    15,    37,   152,   153,   155,
     178,   181,     0,    96,    59,    59,    25,    27,    32,    36,
      68,    69,    70,    71,    72,    73,   184,   185,    53,    74,
      75,    76,    77,    78,    79,    80,   187,   188,   189,   190,
     191,   192,   193,    83,    84,    86,    87,    88,   152,    57,
     173,   174,   177,    48,   157,   158,    20,    31,    47,    48,
     184,    80,   172,    20,    47,    48,    20,    31,    48,    20,
      31,    48,    31,    48,    31,    48,    20,    31,    48,    48,
     177,     4,     4,    60,   162,   163,     4,    57,    98,    99,
     100,   101,   102,   103,   104,   105,     4,    57,   111,   112,
     113,   114,   115,   116,   117,   118,   180,   181,   182,   183,
      35,    38,    54,    57,   165,   166,   167,   168,   169,   170,
     171,   176,   178,   186,     1,     4,    16,    17,    18,    19,
      30,    34,    44,    45,    46,    57,   121,   122,   123,   125,
     126,   127,     4,    57,   129,   130,   131,   132,   133,   134,
      62,    58,    58,    58,   151,   151,   151,   151,   152,   152,
     152,   152,    74,    75,    76,    77,   176,   176,   176,   177,
     177,   177,   177,   177,   177,    58,    68,   152,   156,    58,
     152,   152,   172,   156,   157,   176,   152,   172,   156,   152,
     152,   156,   152,   152,   156,   152,   156,   152,   156,   152,
     152,   156,   156,    58,   152,    57,    98,    99,   101,   103,
     105,    59,    61,    62,    68,    57,   111,   112,   114,   116,
     118,   183,    59,    61,    62,    68,    82,    83,    84,    86,
      87,    88,    62,    62,   161,   167,   170,   178,    59,    61,
      69,    70,   184,   185,   187,   188,   189,    67,   167,    59,
     121,   122,    59,    61,    85,    83,    88,    57,   130,   132,
     134,    59,    61,    62,    68,    57,   182,    31,    48,    23,
      23,    31,    48,   174,    47,    48,    20,    47,    48,    48,
      47,    48,    48,    48,    20,    48,    48,    20,    48,    48,
      48,    48,    20,    48,    55,   125,   175,    58,    58,    58,
      58,    57,   100,    22,    57,   107,   108,   125,   127,   180,
     182,    57,   104,   175,    58,    58,    58,    58,    58,   111,
      57,   124,   125,    57,   117,   182,   182,   182,   182,   182,
     182,     3,     3,    60,    58,    58,   165,   167,   167,   167,
     167,   176,   176,   176,   167,    58,   121,   121,    50,    57,
     132,    58,    58,    58,   129,    57,   124,   135,   180,     4,
     182,    59,   152,   156,   177,   177,   152,   156,   172,   156,
     152,   172,   156,   156,   172,   156,   156,   156,   152,   156,
     156,   152,   156,   156,   156,   156,   152,   156,    58,    68,
      57,   101,    42,    57,   108,    57,   105,    58,   125,   118,
      82,   167,   134,    48,    31,    48,    31,    48,    48,    48,
      47,    48,    48,    48,    48,    48,    48,   125,   102,     4,
     106,   125,    58,   125,    58,     3,    55,   156,   152,   156,
     152,   156,   156,   156,   172,   156,   156,   156,   156,   156,
     156,    57,    58,    58,    48,    48,    48,   175,    42,   156,
     156,   156,    58,   106
};

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		(-2)
#define YYEOF		0

#define YYACCEPT	goto yyacceptlab
#define YYABORT		goto yyabortlab
#define YYERROR		goto yyerrorlab


/* Like YYERROR except do call yyerror.  This remains here temporarily
   to ease the transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  However,
   YYFAIL appears to be in use.  Nevertheless, it is formally deprecated
   in Bison 2.4.2's NEWS entry, where a plan to phase it out is
   discussed.  */

#define YYFAIL		goto yyerrlab
#if defined YYFAIL
  /* This is here to suppress warnings from the GCC cpp's
     -Wunused-macros.  Normally we don't worry about that warning, but
     some users do, and we want to make it easy for users to remove
     YYFAIL uses, which will produce warnings from Bison 2.5.  */
#endif

#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)					\
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    {								\
      yychar = (Token);						\
      yylval = (Value);						\
      yytoken = YYTRANSLATE (yychar);				\
      YYPOPSTACK (1);						\
      goto yybackup;						\
    }								\
  else								\
    {								\
      yyerror (YY_("syntax error: cannot back up")); \
      YYERROR;							\
    }								\
while (YYID (0))


#define YYTERROR	1
#define YYERRCODE	256


/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */

#define YYRHSLOC(Rhs, K) ((Rhs)[K])
#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)				\
    do									\
      if (YYID (N))                                                    \
	{								\
	  (Current).first_line   = YYRHSLOC (Rhs, 1).first_line;	\
	  (Current).first_column = YYRHSLOC (Rhs, 1).first_column;	\
	  (Current).last_line    = YYRHSLOC (Rhs, N).last_line;		\
	  (Current).last_column  = YYRHSLOC (Rhs, N).last_column;	\
	}								\
      else								\
	{								\
	  (Current).first_line   = (Current).last_line   =		\
	    YYRHSLOC (Rhs, 0).last_line;				\
	  (Current).first_column = (Current).last_column =		\
	    YYRHSLOC (Rhs, 0).last_column;				\
	}								\
    while (YYID (0))
#endif


/* YY_LOCATION_PRINT -- Print the location on the stream.
   This macro was not mandated originally: define only if we know
   we won't break user code: when these are the locations we know.  */

#ifndef YY_LOCATION_PRINT
# if defined YYLTYPE_IS_TRIVIAL && YYLTYPE_IS_TRIVIAL
#  define YY_LOCATION_PRINT(File, Loc)			\
     fprintf (File, "%d.%d-%d.%d",			\
	      (Loc).first_line, (Loc).first_column,	\
	      (Loc).last_line,  (Loc).last_column)
# else
#  define YY_LOCATION_PRINT(File, Loc) ((void) 0)
# endif
#endif


/* YYLEX -- calling `yylex' with the right arguments.  */

#ifdef YYLEX_PARAM
# define YYLEX yylex (YYLEX_PARAM)
#else
# define YYLEX yylex ()
#endif

/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)			\
do {						\
  if (yydebug)					\
    YYFPRINTF Args;				\
} while (YYID (0))

# define YY_SYMBOL_PRINT(Title, Type, Value, Location)			  \
do {									  \
  if (yydebug)								  \
    {									  \
      YYFPRINTF (stderr, "%s ", Title);					  \
      yy_symbol_print (stderr,						  \
		  Type, Value, Location); \
      YYFPRINTF (stderr, "\n");						  \
    }									  \
} while (YYID (0))


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

/*ARGSUSED*/
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_symbol_value_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep, YYLTYPE const * const yylocationp)
#else
static void
yy_symbol_value_print (yyoutput, yytype, yyvaluep, yylocationp)
    FILE *yyoutput;
    int yytype;
    YYSTYPE const * const yyvaluep;
    YYLTYPE const * const yylocationp;
#endif
{
  if (!yyvaluep)
    return;
  YYUSE (yylocationp);
# ifdef YYPRINT
  if (yytype < YYNTOKENS)
    YYPRINT (yyoutput, yytoknum[yytype], *yyvaluep);
# else
  YYUSE (yyoutput);
# endif
  switch (yytype)
    {
      default:
	break;
    }
}


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_symbol_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep, YYLTYPE const * const yylocationp)
#else
static void
yy_symbol_print (yyoutput, yytype, yyvaluep, yylocationp)
    FILE *yyoutput;
    int yytype;
    YYSTYPE const * const yyvaluep;
    YYLTYPE const * const yylocationp;
#endif
{
  if (yytype < YYNTOKENS)
    YYFPRINTF (yyoutput, "token %s (", yytname[yytype]);
  else
    YYFPRINTF (yyoutput, "nterm %s (", yytname[yytype]);

  YY_LOCATION_PRINT (yyoutput, *yylocationp);
  YYFPRINTF (yyoutput, ": ");
  yy_symbol_value_print (yyoutput, yytype, yyvaluep, yylocationp);
  YYFPRINTF (yyoutput, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_stack_print (yytype_int16 *yybottom, yytype_int16 *yytop)
#else
static void
yy_stack_print (yybottom, yytop)
    yytype_int16 *yybottom;
    yytype_int16 *yytop;
#endif
{
  YYFPRINTF (stderr, "Stack now");
  for (; yybottom <= yytop; yybottom++)
    {
      int yybot = *yybottom;
      YYFPRINTF (stderr, " %d", yybot);
    }
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)				\
do {								\
  if (yydebug)							\
    yy_stack_print ((Bottom), (Top));				\
} while (YYID (0))


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_reduce_print (YYSTYPE *yyvsp, YYLTYPE *yylsp, int yyrule)
#else
static void
yy_reduce_print (yyvsp, yylsp, yyrule)
    YYSTYPE *yyvsp;
    YYLTYPE *yylsp;
    int yyrule;
#endif
{
  int yynrhs = yyr2[yyrule];
  int yyi;
  unsigned long int yylno = yyrline[yyrule];
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %lu):\n",
	     yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      YYFPRINTF (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr, yyrhs[yyprhs[yyrule] + yyi],
		       &(yyvsp[(yyi + 1) - (yynrhs)])
		       , &(yylsp[(yyi + 1) - (yynrhs)])		       );
      YYFPRINTF (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)		\
do {					\
  if (yydebug)				\
    yy_reduce_print (yyvsp, yylsp, Rule); \
} while (YYID (0))

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
# define YY_SYMBOL_PRINT(Title, Type, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef	YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif



#if YYERROR_VERBOSE

# ifndef yystrlen
#  if defined __GLIBC__ && defined _STRING_H
#   define yystrlen strlen
#  else
/* Return the length of YYSTR.  */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static YYSIZE_T
yystrlen (const char *yystr)
#else
static YYSIZE_T
yystrlen (yystr)
    const char *yystr;
#endif
{
  YYSIZE_T yylen;
  for (yylen = 0; yystr[yylen]; yylen++)
    continue;
  return yylen;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined __GLIBC__ && defined _STRING_H && defined _GNU_SOURCE
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static char *
yystpcpy (char *yydest, const char *yysrc)
#else
static char *
yystpcpy (yydest, yysrc)
    char *yydest;
    const char *yysrc;
#endif
{
  char *yyd = yydest;
  const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

# ifndef yytnamerr
/* Copy to YYRES the contents of YYSTR after stripping away unnecessary
   quotes and backslashes, so that it's suitable for yyerror.  The
   heuristic is that double-quoting is unnecessary unless the string
   contains an apostrophe, a comma, or backslash (other than
   backslash-backslash).  YYSTR is taken from yytname.  If YYRES is
   null, do not copy; instead, return the length of what the result
   would have been.  */
static YYSIZE_T
yytnamerr (char *yyres, const char *yystr)
{
  if (*yystr == '"')
    {
      YYSIZE_T yyn = 0;
      char const *yyp = yystr;

      for (;;)
	switch (*++yyp)
	  {
	  case '\'':
	  case ',':
	    goto do_not_strip_quotes;

	  case '\\':
	    if (*++yyp != '\\')
	      goto do_not_strip_quotes;
	    /* Fall through.  */
	  default:
	    if (yyres)
	      yyres[yyn] = *yyp;
	    yyn++;
	    break;

	  case '"':
	    if (yyres)
	      yyres[yyn] = '\0';
	    return yyn;
	  }
    do_not_strip_quotes: ;
    }

  if (! yyres)
    return yystrlen (yystr);

  return yystpcpy (yyres, yystr) - yyres;
}
# endif

/* Copy into YYRESULT an error message about the unexpected token
   YYCHAR while in state YYSTATE.  Return the number of bytes copied,
   including the terminating null byte.  If YYRESULT is null, do not
   copy anything; just return the number of bytes that would be
   copied.  As a special case, return 0 if an ordinary "syntax error"
   message will do.  Return YYSIZE_MAXIMUM if overflow occurs during
   size calculation.  */
static YYSIZE_T
yysyntax_error (char *yyresult, int yystate, int yychar)
{
  int yyn = yypact[yystate];

  if (! (YYPACT_NINF < yyn && yyn <= YYLAST))
    return 0;
  else
    {
      int yytype = YYTRANSLATE (yychar);
      YYSIZE_T yysize0 = yytnamerr (0, yytname[yytype]);
      YYSIZE_T yysize = yysize0;
      YYSIZE_T yysize1;
      int yysize_overflow = 0;
      enum { YYERROR_VERBOSE_ARGS_MAXIMUM = 5 };
      char const *yyarg[YYERROR_VERBOSE_ARGS_MAXIMUM];
      int yyx;

# if 0
      /* This is so xgettext sees the translatable formats that are
	 constructed on the fly.  */
      YY_("syntax error, unexpected %s");
      YY_("syntax error, unexpected %s, expecting %s");
      YY_("syntax error, unexpected %s, expecting %s or %s");
      YY_("syntax error, unexpected %s, expecting %s or %s or %s");
      YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s");
# endif
      char *yyfmt;
      char const *yyf;
      static char const yyunexpected[] = "syntax error, unexpected %s";
      static char const yyexpecting[] = ", expecting %s";
      static char const yyor[] = " or %s";
      char yyformat[sizeof yyunexpected
		    + sizeof yyexpecting - 1
		    + ((YYERROR_VERBOSE_ARGS_MAXIMUM - 2)
		       * (sizeof yyor - 1))];
      char const *yyprefix = yyexpecting;

      /* Start YYX at -YYN if negative to avoid negative indexes in
	 YYCHECK.  */
      int yyxbegin = yyn < 0 ? -yyn : 0;

      /* Stay within bounds of both yycheck and yytname.  */
      int yychecklim = YYLAST - yyn + 1;
      int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
      int yycount = 1;

      yyarg[0] = yytname[yytype];
      yyfmt = yystpcpy (yyformat, yyunexpected);

      for (yyx = yyxbegin; yyx < yyxend; ++yyx)
	if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR)
	  {
	    if (yycount == YYERROR_VERBOSE_ARGS_MAXIMUM)
	      {
		yycount = 1;
		yysize = yysize0;
		yyformat[sizeof yyunexpected - 1] = '\0';
		break;
	      }
	    yyarg[yycount++] = yytname[yyx];
	    yysize1 = yysize + yytnamerr (0, yytname[yyx]);
	    yysize_overflow |= (yysize1 < yysize);
	    yysize = yysize1;
	    yyfmt = yystpcpy (yyfmt, yyprefix);
	    yyprefix = yyor;
	  }

      yyf = YY_(yyformat);
      yysize1 = yysize + yystrlen (yyf);
      yysize_overflow |= (yysize1 < yysize);
      yysize = yysize1;

      if (yysize_overflow)
	return YYSIZE_MAXIMUM;

      if (yyresult)
	{
	  /* Avoid sprintf, as that infringes on the user's name space.
	     Don't have undefined behavior even if the translation
	     produced a string with the wrong number of "%s"s.  */
	  char *yyp = yyresult;
	  int yyi = 0;
	  while ((*yyp = *yyf) != '\0')
	    {
	      if (*yyp == '%' && yyf[1] == 's' && yyi < yycount)
		{
		  yyp += yytnamerr (yyp, yyarg[yyi++]);
		  yyf += 2;
		}
	      else
		{
		  yyp++;
		  yyf++;
		}
	    }
	}
      return yysize;
    }
}
#endif /* YYERROR_VERBOSE */


/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

/*ARGSUSED*/
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yydestruct (const char *yymsg, int yytype, YYSTYPE *yyvaluep, YYLTYPE *yylocationp)
#else
static void
yydestruct (yymsg, yytype, yyvaluep, yylocationp)
    const char *yymsg;
    int yytype;
    YYSTYPE *yyvaluep;
    YYLTYPE *yylocationp;
#endif
{
  YYUSE (yyvaluep);
  YYUSE (yylocationp);

  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yytype, yyvaluep, yylocationp);

  switch (yytype)
    {
      case 4: /* "T_IDENTIFIER" */

/* Line 1009 of yacc.c  */
#line 493 "parser.y"
	{ delete (yyvaluep->str); };

/* Line 1009 of yacc.c  */
#line 2192 "parser.cpp"
	break;
      case 5: /* "T_STRING" */

/* Line 1009 of yacc.c  */
#line 493 "parser.y"
	{ delete (yyvaluep->str); };

/* Line 1009 of yacc.c  */
#line 2201 "parser.cpp"
	break;
      case 102: /* "constant_schema_outer_list" */

/* Line 1009 of yacc.c  */
#line 501 "parser.y"
	{ if((yyvaluep->l_constant) != NULL) { deallocateList((yyvaluep->l_constant)); } };

/* Line 1009 of yacc.c  */
#line 2210 "parser.cpp"
	break;
      case 103: /* "constant_schema_list" */

/* Line 1009 of yacc.c  */
#line 501 "parser.y"
	{ if((yyvaluep->l_constant) != NULL) { deallocateList((yyvaluep->l_constant)); } };

/* Line 1009 of yacc.c  */
#line 2219 "parser.cpp"
	break;
      case 104: /* "constant_outer_schema" */

/* Line 1009 of yacc.c  */
#line 495 "parser.y"
	{ delete (yyvaluep->constant); };

/* Line 1009 of yacc.c  */
#line 2228 "parser.cpp"
	break;
      case 105: /* "constant_schema" */

/* Line 1009 of yacc.c  */
#line 495 "parser.y"
	{ delete (yyvaluep->constant); };

/* Line 1009 of yacc.c  */
#line 2237 "parser.cpp"
	break;
      case 106: /* "constant_schema_nodecl" */

/* Line 1009 of yacc.c  */
#line 495 "parser.y"
	{ delete (yyvaluep->constant); };

/* Line 1009 of yacc.c  */
#line 2246 "parser.cpp"
	break;
      case 107: /* "constant_outer_binder" */

/* Line 1009 of yacc.c  */
#line 505 "parser.y"
	{ if((yyvaluep->constant_binder_t) != NULL) { deallocateItem((yyvaluep->constant_binder_t)); } };

/* Line 1009 of yacc.c  */
#line 2255 "parser.cpp"
	break;
      case 108: /* "constant_binder" */

/* Line 1009 of yacc.c  */
#line 505 "parser.y"
	{ if((yyvaluep->constant_binder_t) != NULL) { deallocateItem((yyvaluep->constant_binder_t)); } };

/* Line 1009 of yacc.c  */
#line 2264 "parser.cpp"
	break;
      case 115: /* "object_outer_schema_list" */

/* Line 1009 of yacc.c  */
#line 502 "parser.y"
	{ if((yyvaluep->l_object) != NULL) { deallocateList((yyvaluep->l_object)); } };

/* Line 1009 of yacc.c  */
#line 2273 "parser.cpp"
	break;
      case 116: /* "object_schema_list" */

/* Line 1009 of yacc.c  */
#line 502 "parser.y"
	{ if((yyvaluep->l_object) != NULL) { deallocateList((yyvaluep->l_object)); } };

/* Line 1009 of yacc.c  */
#line 2282 "parser.cpp"
	break;
      case 117: /* "object_outer_schema" */

/* Line 1009 of yacc.c  */
#line 497 "parser.y"
	{ delete (yyvaluep->object); };

/* Line 1009 of yacc.c  */
#line 2291 "parser.cpp"
	break;
      case 118: /* "object_schema" */

/* Line 1009 of yacc.c  */
#line 497 "parser.y"
	{ delete (yyvaluep->object); };

/* Line 1009 of yacc.c  */
#line 2300 "parser.cpp"
	break;
      case 121: /* "sort_spec_outer_tuple" */

/* Line 1009 of yacc.c  */
#line 503 "parser.y"
	{ if((yyvaluep->l_sort) != NULL) { deallocateList((yyvaluep->l_sort)); } };

/* Line 1009 of yacc.c  */
#line 2309 "parser.cpp"
	break;
      case 122: /* "sort_spec_tuple" */

/* Line 1009 of yacc.c  */
#line 503 "parser.y"
	{ if((yyvaluep->l_sort) != NULL) { deallocateList((yyvaluep->l_sort)); } };

/* Line 1009 of yacc.c  */
#line 2318 "parser.cpp"
	break;
      case 123: /* "sort_spec" */

/* Line 1009 of yacc.c  */
#line 499 "parser.y"
	{ delete (yyvaluep->sort); };

/* Line 1009 of yacc.c  */
#line 2327 "parser.cpp"
	break;
      case 124: /* "sort_outer_identifier" */

/* Line 1009 of yacc.c  */
#line 493 "parser.y"
	{ delete (yyvaluep->str); };

/* Line 1009 of yacc.c  */
#line 2336 "parser.cpp"
	break;
      case 125: /* "sort_identifier" */

/* Line 1009 of yacc.c  */
#line 493 "parser.y"
	{ delete (yyvaluep->str); };

/* Line 1009 of yacc.c  */
#line 2345 "parser.cpp"
	break;
      case 126: /* "sort_identifier_name" */

/* Line 1009 of yacc.c  */
#line 493 "parser.y"
	{ delete (yyvaluep->str); };

/* Line 1009 of yacc.c  */
#line 2354 "parser.cpp"
	break;
      case 127: /* "sort_constant_name" */

/* Line 1009 of yacc.c  */
#line 493 "parser.y"
	{ delete (yyvaluep->str); };

/* Line 1009 of yacc.c  */
#line 2363 "parser.cpp"
	break;
      case 133: /* "variable_outer_list" */

/* Line 1009 of yacc.c  */
#line 504 "parser.y"
	{ if((yyvaluep->l_variable) != NULL) { deallocateList((yyvaluep->l_variable)); } };

/* Line 1009 of yacc.c  */
#line 2372 "parser.cpp"
	break;
      case 134: /* "variable_list" */

/* Line 1009 of yacc.c  */
#line 504 "parser.y"
	{ if((yyvaluep->l_variable) != NULL) { deallocateList((yyvaluep->l_variable)); } };

/* Line 1009 of yacc.c  */
#line 2381 "parser.cpp"
	break;
      case 135: /* "variable_binding" */

/* Line 1009 of yacc.c  */
#line 499 "parser.y"
	{ delete (yyvaluep->sort); };

/* Line 1009 of yacc.c  */
#line 2390 "parser.cpp"
	break;
      case 175: /* "sort_identifier_list" */

/* Line 1009 of yacc.c  */
#line 503 "parser.y"
	{ if((yyvaluep->l_sort) != NULL) { deallocateList((yyvaluep->l_sort)); } };

/* Line 1009 of yacc.c  */
#line 2399 "parser.cpp"
	break;
      case 180: /* "num_range" */

/* Line 1009 of yacc.c  */
#line 496 "parser.y"
	{ delete (yyvaluep->numRange); };

/* Line 1009 of yacc.c  */
#line 2408 "parser.cpp"
	break;
      case 181: /* "extended_integer" */

/* Line 1009 of yacc.c  */
#line 493 "parser.y"
	{ delete (yyvaluep->str); };

/* Line 1009 of yacc.c  */
#line 2417 "parser.cpp"
	break;
      case 182: /* "extended_integer_outer_expression" */

/* Line 1009 of yacc.c  */
#line 493 "parser.y"
	{ delete (yyvaluep->str); };

/* Line 1009 of yacc.c  */
#line 2426 "parser.cpp"
	break;
      case 183: /* "extended_integer_expression" */

/* Line 1009 of yacc.c  */
#line 493 "parser.y"
	{ delete (yyvaluep->str); };

/* Line 1009 of yacc.c  */
#line 2435 "parser.cpp"
	break;

      default:
	break;
    }
}

/* Prevent warnings from -Wmissing-prototypes.  */
#ifdef YYPARSE_PARAM
#if defined __STDC__ || defined __cplusplus
int yyparse (void *YYPARSE_PARAM);
#else
int yyparse ();
#endif
#else /* ! YYPARSE_PARAM */
#if defined __STDC__ || defined __cplusplus
int yyparse (void);
#else
int yyparse ();
#endif
#endif /* ! YYPARSE_PARAM */


/* The lookahead symbol.  */
int yychar;

/* The semantic value of the lookahead symbol.  */
YYSTYPE yylval;

/* Location data for the lookahead symbol.  */
YYLTYPE yylloc;

/* Number of syntax errors so far.  */
int yynerrs;



/*-------------------------.
| yyparse or yypush_parse.  |
`-------------------------*/

#ifdef YYPARSE_PARAM
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
int
yyparse (void *YYPARSE_PARAM)
#else
int
yyparse (YYPARSE_PARAM)
    void *YYPARSE_PARAM;
#endif
#else /* ! YYPARSE_PARAM */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
int
yyparse (void)
#else
int
yyparse ()

#endif
#endif
{


    int yystate;
    /* Number of tokens to shift before error messages enabled.  */
    int yyerrstatus;

    /* The stacks and their tools:
       `yyss': related to states.
       `yyvs': related to semantic values.
       `yyls': related to locations.

       Refer to the stacks thru separate pointers, to allow yyoverflow
       to reallocate them elsewhere.  */

    /* The state stack.  */
    yytype_int16 yyssa[YYINITDEPTH];
    yytype_int16 *yyss;
    yytype_int16 *yyssp;

    /* The semantic value stack.  */
    YYSTYPE yyvsa[YYINITDEPTH];
    YYSTYPE *yyvs;
    YYSTYPE *yyvsp;

    /* The location stack.  */
    YYLTYPE yylsa[YYINITDEPTH];
    YYLTYPE *yyls;
    YYLTYPE *yylsp;

    /* The locations where the error started and ended.  */
    YYLTYPE yyerror_range[3];

    YYSIZE_T yystacksize;

  int yyn;
  int yyresult;
  /* Lookahead token as an internal (translated) token number.  */
  int yytoken;
  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;
  YYLTYPE yyloc;

#if YYERROR_VERBOSE
  /* Buffer for error messages, and its allocated size.  */
  char yymsgbuf[128];
  char *yymsg = yymsgbuf;
  YYSIZE_T yymsg_alloc = sizeof yymsgbuf;
#endif

#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N), yylsp -= (N))

  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  yytoken = 0;
  yyss = yyssa;
  yyvs = yyvsa;
  yyls = yylsa;
  yystacksize = YYINITDEPTH;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY; /* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */
  yyssp = yyss;
  yyvsp = yyvs;
  yylsp = yyls;

#if defined YYLTYPE_IS_TRIVIAL && YYLTYPE_IS_TRIVIAL
  /* Initialize the default location before parsing starts.  */
  yylloc.first_line   = yylloc.last_line   = 1;
  yylloc.first_column = yylloc.last_column = 1;
#endif

  goto yysetstate;

/*------------------------------------------------------------.
| yynewstate -- Push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
 yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;

 yysetstate:
  *yyssp = yystate;

  if (yyss + yystacksize - 1 <= yyssp)
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYSIZE_T yysize = yyssp - yyss + 1;

#ifdef yyoverflow
      {
	/* Give user a chance to reallocate the stack.  Use copies of
	   these so that the &'s don't force the real ones into
	   memory.  */
	YYSTYPE *yyvs1 = yyvs;
	yytype_int16 *yyss1 = yyss;
	YYLTYPE *yyls1 = yyls;

	/* Each stack pointer address is followed by the size of the
	   data in use in that stack, in bytes.  This used to be a
	   conditional around just the two extra args, but that might
	   be undefined if yyoverflow is a macro.  */
	yyoverflow (YY_("memory exhausted"),
		    &yyss1, yysize * sizeof (*yyssp),
		    &yyvs1, yysize * sizeof (*yyvsp),
		    &yyls1, yysize * sizeof (*yylsp),
		    &yystacksize);

	yyls = yyls1;
	yyss = yyss1;
	yyvs = yyvs1;
      }
#else /* no yyoverflow */
# ifndef YYSTACK_RELOCATE
      goto yyexhaustedlab;
# else
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
	goto yyexhaustedlab;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
	yystacksize = YYMAXDEPTH;

      {
	yytype_int16 *yyss1 = yyss;
	union yyalloc *yyptr =
	  (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
	if (! yyptr)
	  goto yyexhaustedlab;
	YYSTACK_RELOCATE (yyss_alloc, yyss);
	YYSTACK_RELOCATE (yyvs_alloc, yyvs);
	YYSTACK_RELOCATE (yyls_alloc, yyls);
#  undef YYSTACK_RELOCATE
	if (yyss1 != yyssa)
	  YYSTACK_FREE (yyss1);
      }
# endif
#endif /* no yyoverflow */

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;
      yylsp = yyls + yysize - 1;

      YYDPRINTF ((stderr, "Stack size increased to %lu\n",
		  (unsigned long int) yystacksize));

      if (yyss + yystacksize - 1 <= yyssp)
	YYABORT;
    }

  YYDPRINTF ((stderr, "Entering state %d\n", yystate));

  if (yystate == YYFINAL)
    YYACCEPT;

  goto yybackup;

/*-----------.
| yybackup.  |
`-----------*/
yybackup:

  /* Do appropriate processing given the current state.  Read a
     lookahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to lookahead token.  */
  yyn = yypact[yystate];
  if (yyn == YYPACT_NINF)
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either YYEMPTY or YYEOF or a valid lookahead symbol.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = YYLEX;
    }

  if (yychar <= YYEOF)
    {
      yychar = yytoken = YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yyn == 0 || yyn == YYTABLE_NINF)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the lookahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);

  /* Discard the shifted token.  */
  yychar = YYEMPTY;

  yystate = yyn;
  *++yyvsp = yylval;
  *++yylsp = yylloc;
  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- Do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     `$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];

  /* Default location.  */
  YYLLOC_DEFAULT (yyloc, (yylsp - yylen), yylen);
  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
        case 2:

/* Line 1464 of yacc.c  */
#line 509 "parser.y"
    { (yyval.not_used) = PARSERULE_NOT_USED; ;}
    break;

  case 3:

/* Line 1464 of yacc.c  */
#line 510 "parser.y"
    { (yyval.not_used) = PARSERULE_NOT_USED; ;}
    break;

  case 4:

/* Line 1464 of yacc.c  */
#line 513 "parser.y"
    { (yyval.not_used) = PARSERULE_NOT_USED; ;}
    break;

  case 5:

/* Line 1464 of yacc.c  */
#line 514 "parser.y"
    { (yyval.not_used) = PARSERULE_NOT_USED; ;}
    break;

  case 6:

/* Line 1464 of yacc.c  */
#line 517 "parser.y"
    { (yyval.not_used) = PARSERULE_NOT_USED; ;}
    break;

  case 7:

/* Line 1464 of yacc.c  */
#line 518 "parser.y"
    { (yyval.not_used) = PARSERULE_NOT_USED; ;}
    break;

  case 8:

/* Line 1464 of yacc.c  */
#line 519 "parser.y"
    { (yyval.not_used) = PARSERULE_NOT_USED; ;}
    break;

  case 9:

/* Line 1464 of yacc.c  */
#line 520 "parser.y"
    { (yyval.not_used) = PARSERULE_NOT_USED; ;}
    break;

  case 10:

/* Line 1464 of yacc.c  */
#line 521 "parser.y"
    { (yyval.not_used) = PARSERULE_NOT_USED; ;}
    break;

  case 11:

/* Line 1464 of yacc.c  */
#line 522 "parser.y"
    { (yyval.not_used) = PARSERULE_NOT_USED; ;}
    break;

  case 12:

/* Line 1464 of yacc.c  */
#line 523 "parser.y"
    { (yyval.not_used) = PARSERULE_NOT_USED; ;}
    break;

  case 13:

/* Line 1464 of yacc.c  */
#line 524 "parser.y"
    { (yyval.not_used) = PARSERULE_NOT_USED; ;}
    break;

  case 14:

/* Line 1464 of yacc.c  */
#line 526 "parser.y"
    { 
	(yyval.not_used) = PARSERULE_NOT_USED;
	/* On an error, go to the end of the bad statement and try to continue.
       Set the error handler to not wait to report syntax errors if more show up. */
	yyerrok;
;}
    break;

  case 15:

/* Line 1464 of yacc.c  */
#line 539 "parser.y"
    { (yyval.not_used) = PARSERULE_NOT_USED; ;}
    break;

  case 16:

/* Line 1464 of yacc.c  */
#line 542 "parser.y"
    { (yyval.not_used) = PARSERULE_NOT_USED; ;}
    break;

  case 17:

/* Line 1464 of yacc.c  */
#line 543 "parser.y"
    { (yyval.not_used) = PARSERULE_NOT_USED; ;}
    break;

  case 18:

/* Line 1464 of yacc.c  */
#line 546 "parser.y"
    { (yyval.not_used) = PARSERULE_NOT_USED; ;}
    break;

  case 19:

/* Line 1464 of yacc.c  */
#line 547 "parser.y"
    { (yyval.not_used) = PARSERULE_NOT_USED; ;}
    break;

  case 20:

/* Line 1464 of yacc.c  */
#line 550 "parser.y"
    { (yyval.not_used) = PARSERULE_NOT_USED; ;}
    break;

  case 21:

/* Line 1464 of yacc.c  */
#line 551 "parser.y"
    { (yyval.not_used) = PARSERULE_NOT_USED; ;}
    break;

  case 22:

/* Line 1464 of yacc.c  */
#line 555 "parser.y"
    {
	// Fill in each Constant's type and domain and translate each of them.
	bool constantError = false; // Set to true if any of the constants have trouble getting added to the symbol table.
	Sort* tempSort = NULL;
	if((yyvsp[(1) - (3)].l_constant) != NULL && (yyvsp[(3) - (3)].constant_binder_t) != NULL)
	{
		tempSort = (yyvsp[(3) - (3)].constant_binder_t)->domain;
		if(tempSort != NULL)
		{
			std::list<Constant*>::iterator lIter;
			// If the binding type is "attribute", turn the Constant objects into Attribute objects before adding them.
			if((yyvsp[(3) - (3)].constant_binder_t)->constType == Constant::CONST_ATTRIBUTE)
			{
				Attribute* tempAttribute = NULL;
				for(lIter = (yyvsp[(1) - (3)].l_constant)->begin(); lIter != (yyvsp[(1) - (3)].l_constant)->end(); ++lIter)
				{
					tempAttribute = new Attribute((*lIter)->name, (*lIter)->transName);
					tempAttribute->domain = (*lIter)->domain; // Should be NULL = NULL, but just in case.
					for(std::vector<Sort*>::iterator vIter = (*lIter)->params.begin(); vIter != (*lIter)->params.end(); ++vIter)
					{
						if((*vIter) != NULL)
						{
							tempAttribute->params.push_back(*vIter);
						}
					}
					deallocateItem(*lIter);
					(*lIter) = tempAttribute;
				}
			}
			
			for(lIter = (yyvsp[(1) - (3)].l_constant)->begin(); lIter != (yyvsp[(1) - (3)].l_constant)->end(); ++lIter)
			{	// Try to add each constant to the symbol table before hooking it up and translating it.
				int addSymResult = mainTrans.addConstant(*lIter);
				if(addSymResult != SymbolTable::ADDSYM_OK)
				{	// Something went wrong adding this constant, skip connecting & translating it.
					if(addSymResult == SymbolTable::ADDSYM_DUP)
					{	// Duplicate constant declarations are errors, but give a separate error message for clarity.
						ltsyystartParseError(ltsyylloc);
						ltsyyossErr << "Duplicate constant declaration: \"" << (*lIter)->fullName() << "\".";
						ltsyyreportError();
						deallocateItem(*lIter);
						constantError = true;
					}
					else
					{	// Other constant adding errors can get grouped together.
						ltsyystartParseError(ltsyylloc);
						ltsyyossErr << "Bad constant declaration: \"" << (*lIter)->fullName() << "\".";
						ltsyyreportError();
						deallocateItem(*lIter);
						constantError = true;
					}
				}
				else
				{	// Successfully added constant, hook it up and translate it.
					(*lIter)->constType = (yyvsp[(3) - (3)].constant_binder_t)->constType;
					(*lIter)->domain = tempSort;
					if((*lIter)->constType == Constant::CONST_ATTRIBUTE && (yyvsp[(3) - (3)].constant_binder_t)->attributeOf != NULL)
					{
						((Attribute*)(*lIter))->attributeOf = (yyvsp[(3) - (3)].constant_binder_t)->attributeOf;
					}
					// Translate each constant once its information is complete.
					mainTrans.translateConstantDecl(*lIter);
				}
			}
		}
		else
		{
			// Deallocate all of the constants in the errant list, they're never going to get used by anything.
			for(std::list<Constant*>::iterator lIter = (yyvsp[(1) - (3)].l_constant)->begin(); lIter != (yyvsp[(1) - (3)].l_constant)->end(); ++lIter)
			{
				deallocateItem(*lIter);
			}
		}
	}
	if((yyvsp[(3) - (3)].constant_binder_t) != NULL)
	{
		deallocateItem((yyvsp[(3) - (3)].constant_binder_t));
	}
	if((yyvsp[(1) - (3)].l_constant) != NULL)
	{
		deallocateList((yyvsp[(1) - (3)].l_constant));
	}
	(yyval.not_used) = PARSERULE_NOT_USED;
	if(tempSort == NULL || constantError == true)
	{
		YYERROR;
	}
;}
    break;

  case 23:

/* Line 1464 of yacc.c  */
#line 646 "parser.y"
    {
	(yyval.l_constant) = (yyvsp[(1) - (1)].l_constant);
;}
    break;

  case 24:

/* Line 1464 of yacc.c  */
#line 650 "parser.y"
    {
	(yyval.l_constant) = (yyvsp[(2) - (3)].l_constant);
;}
    break;

  case 25:

/* Line 1464 of yacc.c  */
#line 656 "parser.y"
    {
	// Create a new constant list, add the schema as the first element.
	(yyval.l_constant) = new std::list<Constant*>;
	if((yyvsp[(1) - (1)].constant) != NULL)
	{
		(yyval.l_constant)->push_back((yyvsp[(1) - (1)].constant));
	}
;}
    break;

  case 26:

/* Line 1464 of yacc.c  */
#line 665 "parser.y"
    {
	// Merge a schema into an existing list.
	(yyval.l_constant) = NULL;
	if((yyvsp[(1) - (3)].l_constant) != NULL && (yyvsp[(3) - (3)].constant) != NULL)
	{
		(yyval.l_constant) = (yyvsp[(1) - (3)].l_constant);
		(yyval.l_constant)->push_back((yyvsp[(3) - (3)].constant));
	}
	if((yyvsp[(1) - (3)].l_constant) == NULL)
	{
		deallocateItem((yyvsp[(3) - (3)].constant));
	}
	if((yyvsp[(3) - (3)].constant) == NULL)
	{
		for(std::list<Constant*>::iterator lIter = (yyvsp[(1) - (3)].l_constant)->begin(); lIter != (yyvsp[(1) - (3)].l_constant)->end(); ++lIter)
		{
			deallocateItem(*lIter);
		}
		deallocateItem((yyvsp[(3) - (3)].constant));
	}
;}
    break;

  case 27:

/* Line 1464 of yacc.c  */
#line 689 "parser.y"
    {
	(yyval.constant) = (yyvsp[(1) - (1)].constant);
;}
    break;

  case 28:

/* Line 1464 of yacc.c  */
#line 693 "parser.y"
    {
	(yyval.constant) = (yyvsp[(2) - (3)].constant);
;}
    break;

  case 29:

/* Line 1464 of yacc.c  */
#line 699 "parser.y"
    {
	// Create a new Constant from a bare identifier.
	(yyval.constant) = new Constant(*(yyvsp[(1) - (1)].str), Translator::sanitizeConstantName(*(yyvsp[(1) - (1)].str)));
	deallocateItem((yyvsp[(1) - (1)].str));
;}
    break;

  case 30:

/* Line 1464 of yacc.c  */
#line 705 "parser.y"
    {
	// Create a new Constant from a parameterized identifier.
	(yyval.constant) = NULL;
	if((yyvsp[(3) - (4)].l_sort) != NULL)
	{
		(yyval.constant) = new Constant(*(yyvsp[(1) - (4)].str), Translator::sanitizeConstantName(*(yyvsp[(1) - (4)].str)));
		for(std::list<Sort*>::iterator lIter = (yyvsp[(3) - (4)].l_sort)->begin(); lIter != (yyvsp[(3) - (4)].l_sort)->end(); ++lIter)
		{
			if((*lIter) != NULL)
			{
				(yyval.constant)->params.push_back(*lIter);
			}
		}
		deallocateList((yyvsp[(3) - (4)].l_sort));
	}
	deallocateItem((yyvsp[(1) - (4)].str));
;}
    break;

  case 31:

/* Line 1464 of yacc.c  */
#line 726 "parser.y"
    {
	std::vector<std::string> dummyParams;
	(yyval.constant) = mainTrans.getConstant(*(yyvsp[(1) - (1)].str), dummyParams);
	deallocateItem((yyvsp[(1) - (1)].str));
;}
    break;

  case 32:

/* Line 1464 of yacc.c  */
#line 732 "parser.y"
    {
	(yyval.constant) = NULL;
	if((yyvsp[(3) - (4)].l_sort) != NULL)
	{
		std::vector<Sort*> constVecParams = utils::elementListToElementVector(*(yyvsp[(3) - (4)].l_sort));
		std::vector<std::string> constParamNames = utils::elementVectorToFullNameVector(constVecParams);
		(yyval.constant) = mainTrans.getConstant(*(yyvsp[(1) - (4)].str), constParamNames);
		deallocateList((yyvsp[(3) - (4)].l_sort));
	}
	deallocateItem((yyvsp[(1) - (4)].str));
;}
    break;

  case 33:

/* Line 1464 of yacc.c  */
#line 746 "parser.y"
    {
	(yyval.constant_binder_t) = (yyvsp[(1) - (1)].constant_binder_t);
;}
    break;

  case 34:

/* Line 1464 of yacc.c  */
#line 750 "parser.y"
    {
	(yyval.constant_binder_t) = (yyvsp[(2) - (3)].constant_binder_t);
;}
    break;

  case 35:

/* Line 1464 of yacc.c  */
#line 756 "parser.y"
    {
	// Two possibilities, check for each:
	// 1) The identifier is a plain constant type (e.g. "exogenousAction").
	// 2) The identifier is something else, which is a shortcut for "rigid(identifier)".
	Constant::ConstantType constType = Constant::CONST_UNKNOWN;
	std::string tempIdent = (*(yyvsp[(1) - (1)].str));
	deallocateItem((yyvsp[(1) - (1)].str));
	// Check for a real constant type.
	if(tempIdent == "abAction")
	{
		constType = Constant::CONST_ABACTION;
	}
	else if(tempIdent == "action")
	{
		constType = Constant::CONST_ACTION;
	}
	else if(tempIdent == "additiveAction")
	{
		constType = Constant::CONST_ADDITIVEACTION;
	}
	else if(tempIdent == "additiveFluent")
	{
		constType = Constant::CONST_ADDITIVEFLUENT;
	}
	else if(tempIdent == "exogenousAction")
	{
		constType = Constant::CONST_EXOGENOUSACTION;
	}
	else if(tempIdent == "inertialFluent")
	{
		constType = Constant::CONST_INERTIALFLUENT;
	}
	else if(tempIdent == "rigid")
	{
		constType = Constant::CONST_RIGID;
	}
	else if(tempIdent == "sdFluent")
	{
		constType = Constant::CONST_SDFLUENT;
	}
	else if(tempIdent == "simpleFluent")
	{
		constType = Constant::CONST_SIMPLEFLUENT;
	}
	
	(yyval.constant_binder_t) = new PT_constant_binder_t;
	if(constType != Constant::CONST_UNKNOWN)
	{	// Basic constant binder with Boolean domain.
		(yyval.constant_binder_t)->constType = constType;
		std::string domainName = std::string("boolean");
		(yyval.constant_binder_t)->domain = checkDynamicSortDecl(&domainName);
	}
	else
	{	// If it wasn't a real constant type, it's just a shortcut for "rigid(identifier)".
		(yyval.constant_binder_t)->constType = Constant::CONST_RIGID;
		(yyval.constant_binder_t)->domain = checkDynamicSortDecl(&tempIdent);
		if((yyval.constant_binder_t)->domain == NULL)
		{
			ltsyystartParseError(ltsyylloc);
			ltsyyossErr << "Sort \"" << tempIdent << "\" not declared, can't use as the domain of a constant declaration.";
			ltsyyreportError();
		}
		if((yyval.constant_binder_t)->domain == NULL)
		{	// If $$'s domain attribute is NULL, an error happened.
			deallocateItem((yyval.constant_binder_t));
			YYERROR;
		}
	}
;}
    break;

  case 36:

/* Line 1464 of yacc.c  */
#line 826 "parser.y"
    {
	// Basic constant binder with given domain.
	Constant::ConstantType constType = Constant::CONST_UNKNOWN;
	std::string tempIdent = (*(yyvsp[(1) - (4)].str));
	deallocateItem((yyvsp[(1) - (4)].str));
	// Figure out which constant type was given.
	if(tempIdent == "abAction")
	{
		constType = Constant::CONST_ABACTION;
	}
	else if(tempIdent == "action")
	{
		constType = Constant::CONST_ACTION;
	}
	else if(tempIdent == "additiveAction")
	{
		constType = Constant::CONST_ADDITIVEACTION;
	}
	else if(tempIdent == "additiveFluent")
	{
		constType = Constant::CONST_ADDITIVEFLUENT;
	}
	else if(tempIdent == "exogenousAction")
	{
		constType = Constant::CONST_EXOGENOUSACTION;
	}
	else if(tempIdent == "inertialFluent")
	{
		constType = Constant::CONST_INERTIALFLUENT;
	}
	else if(tempIdent == "rigid")
	{
		constType = Constant::CONST_RIGID;
	}
	else if(tempIdent == "sdFluent")
	{
		constType = Constant::CONST_SDFLUENT;
	}
	else if(tempIdent == "simpleFluent")
	{
		constType = Constant::CONST_SIMPLEFLUENT;
	}
	
	(yyval.constant_binder_t) = new PT_constant_binder_t;
	(yyval.constant_binder_t)->constType = constType;
	if((yyvsp[(3) - (4)].str) != NULL)
	{
		(yyval.constant_binder_t)->domain = checkDynamicSortDecl((yyvsp[(3) - (4)].str));
		deallocateItem((yyvsp[(3) - (4)].str));
	}
	if((yyval.constant_binder_t)->domain == NULL)
	{	// Start error mode if anything went wrong.
		deallocateItem((yyval.constant_binder_t));
		YYERROR;
	}
;}
    break;

  case 37:

/* Line 1464 of yacc.c  */
#line 883 "parser.y"
    {
	// Attribute binder with Boolean(*) domain.
	(yyval.constant_binder_t) = new PT_constant_binder_t;
	(yyval.constant_binder_t)->constType = Constant::CONST_ATTRIBUTE;
	std::string* domainName = new std::string("boolean*");
	(yyval.constant_binder_t)->domain = checkDynamicSortDecl(domainName);
	deallocateItem(domainName);
	if((yyvsp[(3) - (3)].constant) != NULL)
	{
		(yyval.constant_binder_t)->attributeOf = (yyvsp[(3) - (3)].constant);
	}
	else
	{	// Something's wrong, start error mode.
		deallocateItem((yyval.constant_binder_t));
		YYERROR;
	}
;}
    break;

  case 38:

/* Line 1464 of yacc.c  */
#line 901 "parser.y"
    {
	// Attribute binder with given(*) domain.
	(yyval.constant_binder_t) = new PT_constant_binder_t;
	(yyval.constant_binder_t)->constType = Constant::CONST_ATTRIBUTE;
	if((yyvsp[(3) - (6)].str) != NULL)
	{
		std::string* domainName = new std::string(*(yyvsp[(3) - (6)].str));
		(*domainName) += "*";
		(yyval.constant_binder_t)->domain = checkDynamicSortDecl(domainName);
		deallocateItem(domainName);
		if((yyval.constant_binder_t)->domain == NULL)
		{
			ltsyystartParseError(ltsyylloc);
			ltsyyossErr << "Sort \"" << *(yyvsp[(3) - (6)].str) << "\" not declared, can't use as the domain of a constant declaration.";
			ltsyyreportError();
		}
		deallocateItem((yyvsp[(3) - (6)].str));
	}
	if((yyvsp[(6) - (6)].constant) != NULL)
	{
		(yyval.constant_binder_t)->attributeOf = (yyvsp[(6) - (6)].constant);
	}
	if((yyval.constant_binder_t)->domain == NULL || (yyval.constant_binder_t)->attributeOf == NULL)
	{	// If $$'s attributes are NULL, an error happened.
		deallocateItem((yyval.constant_binder_t));
		YYERROR;
	}
;}
    break;

  case 39:

/* Line 1464 of yacc.c  */
#line 930 "parser.y"
    {
	// A (dirty) shortcut for rigid(num_range), dynamically instantiating a sort for the num range.
	(yyval.constant_binder_t) = new PT_constant_binder_t;
	(yyval.constant_binder_t)->constType = Constant::CONST_RIGID;
	// Turn the number range into a sort (if that hasn't happened already).
	if((yyvsp[(1) - (1)].numRange) != NULL)
	{
		std::string numRangeSortName = Translator::numRangeToSortName((yyvsp[(1) - (1)].numRange)->min, (yyvsp[(1) - (1)].numRange)->max);
		Sort* tempSort = mainTrans.getSort(numRangeSortName);
		if(tempSort == NULL)
		{
			// Have a helper function handle making and translating the sort.
			std::list<Sort*>* dummyList = new std::list<Sort*>; // No subsorts.
			tempSort = processSort(&numRangeSortName, dummyList);
			deallocateList(dummyList);
			// Also add the number range as an object for this new sort.
			int addResult = mainTrans.addObject((yyvsp[(1) - (1)].numRange));
			if(addResult == SymbolTable::ADDSYM_OK)
			{
				tempSort->domainObjs.push_back((yyvsp[(1) - (1)].numRange));
				// Output the translation of the object declaration.
				mainTrans.translateObjectDecl((yyvsp[(1) - (1)].numRange), tempSort);
			}
		}
		if((yyval.constant_binder_t) != NULL && tempSort != NULL)
		{
			(yyval.constant_binder_t)->domain = tempSort;
		}
		if(tempSort == NULL)
		{
			deallocateItem((yyvsp[(1) - (1)].numRange));
		}
	}
	if((yyval.constant_binder_t)->domain == NULL)
	{	// If $$'s domain is NULL, an error happened.
		deallocateItem((yyval.constant_binder_t));
		YYERROR;
	}
;}
    break;

  case 40:

/* Line 1464 of yacc.c  */
#line 974 "parser.y"
    {
	// The new style of maxAdditive declaration. Insert a hint comment with the given maxAdditive value.
	if((yyvsp[(4) - (5)].str) != NULL)
	{
		std::string maxAdditiveHint = "% [MaxAdditive:";
		maxAdditiveHint += *((yyvsp[(4) - (5)].str));
		maxAdditiveHint += "]";
		mainTrans.output(maxAdditiveHint, true);
		(yyval.not_used) = PARSERULE_NOT_USED;
		deallocateItem((yyvsp[(4) - (5)].str));
	}
;}
    break;

  case 41:

/* Line 1464 of yacc.c  */
#line 990 "parser.y"
    { (yyval.not_used) = PARSERULE_NOT_USED; ;}
    break;

  case 42:

/* Line 1464 of yacc.c  */
#line 993 "parser.y"
    { (yyval.not_used) = PARSERULE_NOT_USED; ;}
    break;

  case 43:

/* Line 1464 of yacc.c  */
#line 994 "parser.y"
    { (yyval.not_used) = PARSERULE_NOT_USED; ;}
    break;

  case 44:

/* Line 1464 of yacc.c  */
#line 997 "parser.y"
    { (yyval.not_used) = PARSERULE_NOT_USED; ;}
    break;

  case 45:

/* Line 1464 of yacc.c  */
#line 998 "parser.y"
    { (yyval.not_used) = PARSERULE_NOT_USED; ;}
    break;

  case 46:

/* Line 1464 of yacc.c  */
#line 1001 "parser.y"
    { (yyval.not_used) = PARSERULE_NOT_USED; ;}
    break;

  case 47:

/* Line 1464 of yacc.c  */
#line 1002 "parser.y"
    { (yyval.not_used) = PARSERULE_NOT_USED; ;}
    break;

  case 48:

/* Line 1464 of yacc.c  */
#line 1006 "parser.y"
    {
	// Connect each Object in the list to its sort, (try to) add them to the symbol table, and translate each object.
	Sort* tempSort = NULL;
	bool objectError = false; // Set to true if a serious error happens during object adding.
	if((yyvsp[(1) - (3)].l_object) != NULL && (yyvsp[(3) - (3)].str) != NULL)
	{
		tempSort = mainTrans.getSort(*(yyvsp[(3) - (3)].str));
		if(tempSort != NULL)
		{
			for(std::list<Object*>::iterator lIter = (yyvsp[(1) - (3)].l_object)->begin(); lIter != (yyvsp[(1) - (3)].l_object)->end(); ++lIter)
			{	// Try to add the object to the symbol table (mostly to check for dupes).
				int addSymResult = mainTrans.addObject(*lIter);
				if(addSymResult != SymbolTable::ADDSYM_OK)
				{	// Something went wrong adding the object, skip connecting & translating it.
					if(addSymResult == SymbolTable::ADDSYM_DUP)
					{	// Warn about duplicate object declarations (not an error), then move on.
						ltsyystartCaution(ltsyylloc);
						ltsyyossErr << "Duplicate object declaration: \"" << (*lIter)->fullName() << "\".";
						ltsyyreportCaution();
						deallocateItem(*lIter);
					}
					else
					{	// A real object error.
						ltsyystartParseError(ltsyylloc);
						ltsyyossErr << "Bad object declaration: \"" << (*lIter)->fullName() << "\".";
						ltsyyreportError();
						deallocateItem(*lIter);
						objectError = true;
					}
				}
				else
				{	// Object add went okay, connect the sort to the object and translate them.
					tempSort->domainObjs.push_back(*lIter);
					// Translate each object as we add it to the sort's domain.
					mainTrans.translateObjectDecl(*lIter, tempSort);
				}
			}
		}
		else
		{
			ltsyystartParseError(ltsyylloc);
			ltsyyossErr << "Sort \"" << *(yyvsp[(3) - (3)].str) << "\" not declared, can't use as the target of an object declaration.";
			ltsyyreportError();
			// Deallocate all of the objects in the errant list, they're never going to get used by anything.
			for(std::list<Object*>::iterator lIter = (yyvsp[(1) - (3)].l_object)->begin(); lIter != (yyvsp[(1) - (3)].l_object)->end(); ++lIter)
			{
				deallocateItem(*lIter);
			}
		}
		deallocateList((yyvsp[(1) - (3)].l_object));
		deallocateItem((yyvsp[(3) - (3)].str));
	}
	(yyval.not_used) = PARSERULE_NOT_USED;
	if(tempSort == NULL || objectError == true)
	{	// If the binding sort never got a match or an object had a problem getting added, an error occurred.
		YYERROR;
	}
;}
    break;

  case 49:

/* Line 1464 of yacc.c  */
#line 1067 "parser.y"
    {
	(yyval.l_object) = (yyvsp[(1) - (1)].l_object);
;}
    break;

  case 50:

/* Line 1464 of yacc.c  */
#line 1071 "parser.y"
    {
	(yyval.l_object) = (yyvsp[(2) - (3)].l_object);
;}
    break;

  case 51:

/* Line 1464 of yacc.c  */
#line 1077 "parser.y"
    {
	// Create a new list and make the new object the first element.
	(yyval.l_object) = NULL;
	if((yyvsp[(1) - (1)].object) != NULL)
	{
		(yyval.l_object) = new std::list<Object*>;
		(yyval.l_object)->push_back((yyvsp[(1) - (1)].object));
	}
;}
    break;

  case 52:

/* Line 1464 of yacc.c  */
#line 1087 "parser.y"
    {
	// Merge a new object with an exisiting list.
	(yyval.l_object) = NULL;
	if((yyvsp[(1) - (3)].l_object) != NULL && (yyvsp[(3) - (3)].object) != NULL)
	{
		(yyval.l_object) = (yyvsp[(1) - (3)].l_object);
		(yyval.l_object)->push_back((yyvsp[(3) - (3)].object));
	}
	if((yyvsp[(1) - (3)].l_object) == NULL)
	{
		deallocateItem((yyvsp[(3) - (3)].object));
	}
	if((yyvsp[(3) - (3)].object) == NULL)
	{
		for(std::list<Object*>::iterator lIter = (yyvsp[(1) - (3)].l_object)->begin(); lIter != (yyvsp[(1) - (3)].l_object)->end(); ++lIter)
		{
			deallocateItem(*lIter);
		}
		deallocateList((yyvsp[(1) - (3)].l_object));
	}
;}
    break;

  case 53:

/* Line 1464 of yacc.c  */
#line 1111 "parser.y"
    {
	(yyval.object) = (yyvsp[(1) - (1)].object);
;}
    break;

  case 54:

/* Line 1464 of yacc.c  */
#line 1115 "parser.y"
    {
	(yyval.object) = (yyvsp[(2) - (3)].object);
;}
    break;

  case 55:

/* Line 1464 of yacc.c  */
#line 1121 "parser.y"
    {
	// Create a new Object from a bare identifier.
	(yyval.object) = new Object(*(yyvsp[(1) - (1)].str), Translator::sanitizeObjectName(*(yyvsp[(1) - (1)].str)));
	deallocateItem((yyvsp[(1) - (1)].str));
;}
    break;

  case 56:

/* Line 1464 of yacc.c  */
#line 1127 "parser.y"
    {
	// Create a new Object from a parameterized identifier.
	(yyval.object) = new Object(*(yyvsp[(1) - (4)].str), Translator::sanitizeObjectName(*(yyvsp[(1) - (4)].str)));
	if((yyvsp[(3) - (4)].l_sort) != NULL)
	{
		for(std::list<Sort*>::iterator lIter = (yyvsp[(3) - (4)].l_sort)->begin(); lIter != (yyvsp[(3) - (4)].l_sort)->end(); ++lIter)
		{
			if((*lIter) != NULL)
			{
				(yyval.object)->params.push_back(*lIter);
			}
		}
		deallocateList((yyvsp[(3) - (4)].l_sort));
	}
	deallocateItem((yyvsp[(1) - (4)].str));
;}
    break;

  case 57:

/* Line 1464 of yacc.c  */
#line 1144 "parser.y"
    {
	// Create a new object from arbitrary math.
	(yyval.object) = new Object(*(yyvsp[(1) - (1)].str), Translator::sanitizeObjectName(*(yyvsp[(1) - (1)].str)));
	deallocateItem((yyvsp[(1) - (1)].str)); // Free dynamic memory that's not needed anymore.
;}
    break;

  case 58:

/* Line 1464 of yacc.c  */
#line 1150 "parser.y"
    {
	// Upcast a NumberRange into an Object.
	(yyval.object) = (Object*)(yyvsp[(1) - (1)].numRange);
;}
    break;

  case 59:

/* Line 1464 of yacc.c  */
#line 1159 "parser.y"
    {
	(yyval.not_used) = PARSERULE_NOT_USED;
	/* Not supported yet. */
	yyerrok;
;}
    break;

  case 60:

/* Line 1464 of yacc.c  */
#line 1169 "parser.y"
    {
	// Deallocate the main sort list of the statement.
	if((yyvsp[(3) - (4)].l_sort) != NULL)
	{
		deallocateList((yyvsp[(3) - (4)].l_sort));
	}
	(yyval.not_used) = PARSERULE_NOT_USED;
;}
    break;

  case 61:

/* Line 1464 of yacc.c  */
#line 1180 "parser.y"
    {
	(yyval.l_sort) = (yyvsp[(1) - (1)].l_sort);
;}
    break;

  case 62:

/* Line 1464 of yacc.c  */
#line 1184 "parser.y"
    {
	(yyval.l_sort) = (yyvsp[(2) - (3)].l_sort);
;}
    break;

  case 63:

/* Line 1464 of yacc.c  */
#line 1190 "parser.y"
    {
	(yyval.l_sort) = new std::list<Sort*>;
	(yyval.l_sort)->push_back((yyvsp[(1) - (1)].sort));
;}
    break;

  case 64:

/* Line 1464 of yacc.c  */
#line 1195 "parser.y"
    {
	(yyval.l_sort) = NULL;
	if((yyvsp[(1) - (3)].l_sort) != NULL || (yyvsp[(3) - (3)].l_sort) != NULL)
	{
		(yyval.l_sort) = new std::list<Sort*>;
	}
	// Merge the two sort lists, if they exist.
	if((yyvsp[(1) - (3)].l_sort) != NULL)
	{
		for(std::list<Sort*>::iterator lIter = (yyvsp[(1) - (3)].l_sort)->begin(); lIter != (yyvsp[(1) - (3)].l_sort)->end(); ++lIter)
		{
			if((*lIter) != NULL)
			{
				(yyval.l_sort)->push_back((*lIter));
			}
		}
		deallocateList((yyvsp[(1) - (3)].l_sort));
	}
	if((yyvsp[(3) - (3)].l_sort) != NULL)
	{
		for(std::list<Sort*>::iterator lIter = (yyvsp[(3) - (3)].l_sort)->begin(); lIter != (yyvsp[(3) - (3)].l_sort)->end(); ++lIter)
		{
			if((*lIter) != NULL)
			{
				(yyval.l_sort)->push_back((*lIter));
			}
		}
		deallocateList((yyvsp[(3) - (3)].l_sort));
	}
;}
    break;

  case 65:

/* Line 1464 of yacc.c  */
#line 1228 "parser.y"
    {
	// Have a helper function handle making and translating the sort.
	std::list<Sort*>* dummyList = new std::list<Sort*>;
	(yyval.sort) = processSort((yyvsp[(1) - (1)].str), dummyList);
	deallocateList(dummyList);
	deallocateItem((yyvsp[(1) - (1)].str));
	if((yyval.sort) == NULL)
	{
		YYERROR;
	}
;}
    break;

  case 66:

/* Line 1464 of yacc.c  */
#line 1240 "parser.y"
    {
	// Have a helper function handle making and translating the sort.
	(yyval.sort) = processSort((yyvsp[(1) - (3)].str), (yyvsp[(3) - (3)].l_sort));
	deallocateItem((yyvsp[(1) - (3)].str));
	deallocateList((yyvsp[(3) - (3)].l_sort));
	if((yyval.sort) == NULL)
	{
		YYERROR;
	}
;}
    break;

  case 67:

/* Line 1464 of yacc.c  */
#line 1253 "parser.y"
    {
	(yyval.str) = (yyvsp[(1) - (1)].str);
;}
    break;

  case 68:

/* Line 1464 of yacc.c  */
#line 1257 "parser.y"
    {
	(yyval.str) = (yyvsp[(2) - (3)].str);
;}
    break;

  case 69:

/* Line 1464 of yacc.c  */
#line 1263 "parser.y"
    {
	(yyval.str) = (yyvsp[(1) - (1)].str);
;}
    break;

  case 70:

/* Line 1464 of yacc.c  */
#line 1267 "parser.y"
    {
	(yyval.str) = new std::string;
	(*(yyval.str)) = (*(yyvsp[(1) - (2)].str)) + "*";
	deallocateItem((yyvsp[(1) - (2)].str));
;}
    break;

  case 71:

/* Line 1464 of yacc.c  */
#line 1273 "parser.y"
    {
	// Alternate way to express the idea of a starred sort.
	(yyval.str) = new std::string;
	(*(yyval.str)) = (*(yyvsp[(1) - (3)].str)) + "*";
	deallocateItem((yyvsp[(1) - (3)].str));
;}
    break;

  case 72:

/* Line 1464 of yacc.c  */
#line 1282 "parser.y"
    {
	(yyval.str) = (yyvsp[(1) - (1)].str);
;}
    break;

  case 73:

/* Line 1464 of yacc.c  */
#line 1286 "parser.y"
    {
	(yyval.str) = (yyvsp[(1) - (1)].str)
;}
    break;

  case 74:

/* Line 1464 of yacc.c  */
#line 1292 "parser.y"
    {
	// Directly referencing an internal sort, return the name of the desired sort.
	(yyval.str) = new std::string;
	(*(yyval.str)) = "abAction";
;}
    break;

  case 75:

/* Line 1464 of yacc.c  */
#line 1298 "parser.y"
    {
	// Directly referencing an internal sort, return the name of the desired sort.
	(yyval.str) = new std::string;
	(*(yyval.str)) = "action";
;}
    break;

  case 76:

/* Line 1464 of yacc.c  */
#line 1304 "parser.y"
    {
	// Directly referencing an internal sort, return the name of the desired sort.
	(yyval.str) = new std::string;
	(*(yyval.str)) = "additiveAction";
;}
    break;

  case 77:

/* Line 1464 of yacc.c  */
#line 1310 "parser.y"
    {
	// Directly referencing an internal sort, return the name of the desired sort.
	(yyval.str) = new std::string;
	(*(yyval.str)) = "additiveFluent";
;}
    break;

  case 78:

/* Line 1464 of yacc.c  */
#line 1316 "parser.y"
    {
	// Directly referencing an internal sort, return the name of the desired sort.
	(yyval.str) = new std::string;
	(*(yyval.str)) = "exogenousAction";
;}
    break;

  case 79:

/* Line 1464 of yacc.c  */
#line 1322 "parser.y"
    {
	// Directly referencing an internal sort, return the name of the desired sort.
	(yyval.str) = new std::string;
	(*(yyval.str)) = "inertialFluent";
;}
    break;

  case 80:

/* Line 1464 of yacc.c  */
#line 1328 "parser.y"
    {
	// Directly referencing an internal sort, return the name of the desired sort.
	(yyval.str) = new std::string;
	(*(yyval.str)) = "rigid";
;}
    break;

  case 81:

/* Line 1464 of yacc.c  */
#line 1334 "parser.y"
    {
	// Directly referencing an internal sort, return the name of the desired sort.
	(yyval.str) = new std::string;
	(*(yyval.str)) = "sdFluent";
;}
    break;

  case 82:

/* Line 1464 of yacc.c  */
#line 1340 "parser.y"
    {
	// Directly referencing an internal sort, return the name of the desired sort.
	(yyval.str) = new std::string;
	(*(yyval.str)) = "simpleFluent";
;}
    break;

  case 83:

/* Line 1464 of yacc.c  */
#line 1349 "parser.y"
    { (yyval.not_used) = PARSERULE_NOT_USED; ;}
    break;

  case 84:

/* Line 1464 of yacc.c  */
#line 1352 "parser.y"
    { (yyval.not_used) = PARSERULE_NOT_USED; ;}
    break;

  case 85:

/* Line 1464 of yacc.c  */
#line 1353 "parser.y"
    { (yyval.not_used) = PARSERULE_NOT_USED; ;}
    break;

  case 86:

/* Line 1464 of yacc.c  */
#line 1356 "parser.y"
    { (yyval.not_used) = PARSERULE_NOT_USED; ;}
    break;

  case 87:

/* Line 1464 of yacc.c  */
#line 1357 "parser.y"
    { (yyval.not_used) = PARSERULE_NOT_USED; ;}
    break;

  case 88:

/* Line 1464 of yacc.c  */
#line 1360 "parser.y"
    { (yyval.not_used) = PARSERULE_NOT_USED; ;}
    break;

  case 89:

/* Line 1464 of yacc.c  */
#line 1361 "parser.y"
    { (yyval.not_used) = PARSERULE_NOT_USED; ;}
    break;

  case 90:

/* Line 1464 of yacc.c  */
#line 1365 "parser.y"
    {
	// Connect the variables in the list to the binding sort, then translate them.
	if((yyvsp[(1) - (3)].l_variable) != NULL && (yyvsp[(3) - (3)].sort) != NULL)
	{
		std::list<Variable*>::iterator vIter;
		for(vIter = (yyvsp[(1) - (3)].l_variable)->begin(); vIter != (yyvsp[(1) - (3)].l_variable)->end(); ++vIter)
		{
			(*vIter)->sortRef = (yyvsp[(3) - (3)].sort);
			mainTrans.translateVariableDecl(*vIter);
		}
	}
	if((yyvsp[(1) - (3)].l_variable) != NULL)
	{	// Clear out the list, we don't need it anymore.
		deallocateList((yyvsp[(1) - (3)].l_variable));
	}
	(yyval.not_used) = PARSERULE_NOT_USED;
;}
    break;

  case 91:

/* Line 1464 of yacc.c  */
#line 1385 "parser.y"
    {
	(yyval.l_variable) = (yyvsp[(1) - (1)].l_variable);
;}
    break;

  case 92:

/* Line 1464 of yacc.c  */
#line 1389 "parser.y"
    {
	(yyval.l_variable) = (yyvsp[(2) - (3)].l_variable);
;}
    break;

  case 93:

/* Line 1464 of yacc.c  */
#line 1395 "parser.y"
    {
	// Create a new list of Variables, add this one as the first item.
	(yyval.l_variable) = new std::list<Variable*>;
	Variable* tempVar = new Variable(*(yyvsp[(1) - (1)].str), Translator::sanitizeVariableName(*(yyvsp[(1) - (1)].str)));
	int addSymResult = mainTrans.addVariable(tempVar);
	if(addSymResult != SymbolTable::ADDSYM_OK)
	{
		if(addSymResult == SymbolTable::ADDSYM_DUP)
		{	// Warn about duplicate variable declarations (not an error), then grab the already-declared variable.
			ltsyystartCaution(ltsyylloc);
			ltsyyossErr << "Duplicate variable declaration: \"" << *(yyvsp[(1) - (1)].str) << "\".";
			ltsyyreportCaution();
			deallocateItem(tempVar);
			tempVar = mainTrans.getVariable(*(yyvsp[(1) - (1)].str));
			(yyval.l_variable)->push_back(tempVar);
		}
		else
		{	// A real variable error.
			ltsyystartParseError(ltsyylloc);
			ltsyyossErr << "Bad variable declaration: \"" << *(yyvsp[(1) - (1)].str) << "\".";
			ltsyyreportError();
			deallocateList((yyval.l_variable));
			deallocateItem(tempVar);
		}
	}
	else
	{
		(yyval.l_variable)->push_back(tempVar);
	}
	deallocateItem((yyvsp[(1) - (1)].str));
	if(tempVar == NULL || (yyval.l_variable) == NULL)
	{	// If $$ or tempVar are NULL, something went wrong.
		YYERROR;
	}
;}
    break;

  case 94:

/* Line 1464 of yacc.c  */
#line 1431 "parser.y"
    {
	// Merge a new variable declaration into an existing list of variables.
	if((yyvsp[(1) - (3)].l_variable) == NULL)
	{
		(yyval.l_variable) = new std::list<Variable*>;
	}
	Variable* tempVar = new Variable(*(yyvsp[(3) - (3)].str), Translator::sanitizeVariableName(*(yyvsp[(3) - (3)].str)));
	int addSymResult = mainTrans.addVariable(tempVar);
	if(addSymResult != SymbolTable::ADDSYM_OK)
	{
		if(addSymResult == SymbolTable::ADDSYM_DUP)
		{	// Warn about duplicate variable declarations (not an error), then grab the already-declared variable.
			ltsyystartCaution(ltsyylloc);
			ltsyyossErr << "Duplicate variable declaration: \"" << *(yyvsp[(3) - (3)].str) << "\".";
			ltsyyreportCaution();
			deallocateItem(tempVar);
			tempVar = mainTrans.getVariable(*(yyvsp[(3) - (3)].str));
			(yyval.l_variable)->push_back(tempVar);
		}
		else
		{	// A real variable error.
			ltsyystartParseError(ltsyylloc);
			ltsyyossErr << "Bad variable declaration: \"" << *(yyvsp[(3) - (3)].str) << "\".";
			ltsyyreportError();
			deallocateItem(tempVar);
		}
	}
	else
	{
		(yyval.l_variable)->push_back(tempVar);
	}
	deallocateItem((yyvsp[(3) - (3)].str));
	if(tempVar == NULL)
	{	// If tempVar is NULL, something went wrong.
		YYERROR;
	}
;}
    break;

  case 95:

/* Line 1464 of yacc.c  */
#line 1471 "parser.y"
    {
	// Find the sort in question, create it if it doesn't exist and is a "something*" sort (whose "something" exists already), or report an error.
	(yyval.sort) = mainTrans.getSort(*(yyvsp[(1) - (1)].str));
	if((yyval.sort) == NULL)
	{
		(yyval.sort) = checkDynamicSortDecl((yyvsp[(1) - (1)].str)); // Reports appropriate errors, we just need to YYERROR if that happens.
	}
	deallocateItem((yyvsp[(1) - (1)].str));
	if((yyval.sort) == NULL)
	{	// If $$ is NULL, something went wrong.
		YYERROR;
	}
;}
    break;

  case 96:

/* Line 1464 of yacc.c  */
#line 1485 "parser.y"
    {
	// Turn the number range into a sort (if that hasn't happened already).
	(yyval.sort) = NULL;
	if((yyvsp[(1) - (1)].numRange) != NULL)
	{
		std::string numRangeSortName = Translator::numRangeToSortName((yyvsp[(1) - (1)].numRange)->min, (yyvsp[(1) - (1)].numRange)->max);
		(yyval.sort) = mainTrans.getSort(numRangeSortName);
		if((yyval.sort) == NULL)
		{
			// Have a helper function handle making and translating the sort.
			std::list<Sort*>* dummyList = new std::list<Sort*>; // No subsorts.
			(yyval.sort) = processSort(&numRangeSortName, dummyList);
			deallocateList(dummyList);
			// Also add the number range as an object for this new sort.
			int addResult = mainTrans.addObject((yyvsp[(1) - (1)].numRange));
			if(addResult == SymbolTable::ADDSYM_OK)
			{
				(yyval.sort)->domainObjs.push_back((yyvsp[(1) - (1)].numRange));
				// Output the translation of the object declaration.
				mainTrans.translateObjectDecl((yyvsp[(1) - (1)].numRange), (yyval.sort));
			}
		}
	}
	if((yyval.sort) == NULL)
	{	// If $$ is NULL, something went wrong.
		deallocateItem((yyvsp[(1) - (1)].numRange));
		YYERROR;
	}
;}
    break;

  case 97:

/* Line 1464 of yacc.c  */
#line 1518 "parser.y"
    { (yyval.not_used) = PARSERULE_NOT_USED; ;}
    break;

  case 98:

/* Line 1464 of yacc.c  */
#line 1519 "parser.y"
    { (yyval.not_used) = PARSERULE_NOT_USED; ;}
    break;

  case 99:

/* Line 1464 of yacc.c  */
#line 1522 "parser.y"
    { (yyval.not_used) = PARSERULE_NOT_USED; ;}
    break;

  case 100:

/* Line 1464 of yacc.c  */
#line 1523 "parser.y"
    { (yyval.not_used) = PARSERULE_NOT_USED; ;}
    break;

  case 101:

/* Line 1464 of yacc.c  */
#line 1524 "parser.y"
    { (yyval.not_used) = PARSERULE_NOT_USED; ;}
    break;

  case 102:

/* Line 1464 of yacc.c  */
#line 1525 "parser.y"
    { (yyval.not_used) = PARSERULE_NOT_USED; ;}
    break;

  case 103:

/* Line 1464 of yacc.c  */
#line 1526 "parser.y"
    { (yyval.not_used) = PARSERULE_NOT_USED; ;}
    break;

  case 104:

/* Line 1464 of yacc.c  */
#line 1527 "parser.y"
    { (yyval.not_used) = PARSERULE_NOT_USED; ;}
    break;

  case 105:

/* Line 1464 of yacc.c  */
#line 1528 "parser.y"
    { (yyval.not_used) = PARSERULE_NOT_USED; ;}
    break;

  case 106:

/* Line 1464 of yacc.c  */
#line 1529 "parser.y"
    { (yyval.not_used) = PARSERULE_NOT_USED; ;}
    break;

  case 107:

/* Line 1464 of yacc.c  */
#line 1530 "parser.y"
    { (yyval.not_used) = PARSERULE_NOT_USED; ;}
    break;

  case 108:

/* Line 1464 of yacc.c  */
#line 1531 "parser.y"
    { (yyval.not_used) = PARSERULE_NOT_USED; ;}
    break;

  case 109:

/* Line 1464 of yacc.c  */
#line 1532 "parser.y"
    { (yyval.not_used) = PARSERULE_NOT_USED; ;}
    break;

  case 110:

/* Line 1464 of yacc.c  */
#line 1533 "parser.y"
    { (yyval.not_used) = PARSERULE_NOT_USED; ;}
    break;

  case 111:

/* Line 1464 of yacc.c  */
#line 1538 "parser.y"
    {
	bool transResult = handleAlwaysLaw((yyvsp[(2) - (4)].parseElement), (yyvsp[(4) - (4)].parseElement));
	deallocateItem((yyvsp[(2) - (4)].parseElement));
	deallocateItem((yyvsp[(4) - (4)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
	if(!transResult)
	{
		YYERROR;
	}
;}
    break;

  case 112:

/* Line 1464 of yacc.c  */
#line 1549 "parser.y"
    {
	bool transResult = handleAlwaysLaw((yyvsp[(2) - (2)].parseElement), NULL);
	deallocateItem((yyvsp[(2) - (2)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
	if(!transResult)
	{
		YYERROR;
	}
;}
    break;

  case 113:

/* Line 1464 of yacc.c  */
#line 1561 "parser.y"
    {
	bool transResult = handleConstraintLaw((yyvsp[(2) - (8)].parseElement), (yyvsp[(4) - (8)].parseElement), (yyvsp[(6) - (8)].parseElement), (yyvsp[(8) - (8)].parseElement));
	deallocateItem((yyvsp[(2) - (8)].parseElement));
	deallocateItem((yyvsp[(4) - (8)].parseElement));
	deallocateItem((yyvsp[(6) - (8)].parseElement));
	deallocateItem((yyvsp[(8) - (8)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
	if(!transResult)
	{
		YYERROR;
	}
;}
    break;

  case 114:

/* Line 1464 of yacc.c  */
#line 1574 "parser.y"
    {
	bool transResult = handleConstraintLaw((yyvsp[(2) - (6)].parseElement), (yyvsp[(4) - (6)].parseElement), NULL, (yyvsp[(6) - (6)].parseElement));
	deallocateItem((yyvsp[(2) - (6)].parseElement));
	deallocateItem((yyvsp[(4) - (6)].parseElement));
	deallocateItem((yyvsp[(6) - (6)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
	if(!transResult)
	{
		YYERROR;
	}
;}
    break;

  case 115:

/* Line 1464 of yacc.c  */
#line 1586 "parser.y"
    {
	bool transResult = handleConstraintLaw((yyvsp[(2) - (6)].parseElement), (yyvsp[(4) - (6)].parseElement), (yyvsp[(6) - (6)].parseElement), NULL);
	deallocateItem((yyvsp[(2) - (6)].parseElement));
	deallocateItem((yyvsp[(4) - (6)].parseElement));
	deallocateItem((yyvsp[(6) - (6)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
	if(!transResult)
	{
		YYERROR;
	}
;}
    break;

  case 116:

/* Line 1464 of yacc.c  */
#line 1598 "parser.y"
    {
	bool transResult = handleConstraintLaw((yyvsp[(2) - (4)].parseElement), (yyvsp[(4) - (4)].parseElement), NULL, NULL);
	deallocateItem((yyvsp[(2) - (4)].parseElement));
	deallocateItem((yyvsp[(4) - (4)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
	if(!transResult)
	{
		YYERROR;
	}
;}
    break;

  case 117:

/* Line 1464 of yacc.c  */
#line 1609 "parser.y"
    {
	bool transResult = handleConstraintLaw((yyvsp[(2) - (6)].parseElement), NULL, (yyvsp[(4) - (6)].parseElement), (yyvsp[(6) - (6)].parseElement));
	deallocateItem((yyvsp[(2) - (6)].parseElement));
	deallocateItem((yyvsp[(4) - (6)].parseElement));
	deallocateItem((yyvsp[(6) - (6)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
	if(!transResult)
	{
		YYERROR;
	}
;}
    break;

  case 118:

/* Line 1464 of yacc.c  */
#line 1621 "parser.y"
    {
	bool transResult = handleConstraintLaw((yyvsp[(2) - (4)].parseElement), NULL, NULL, (yyvsp[(4) - (4)].parseElement));
	deallocateItem((yyvsp[(2) - (4)].parseElement));
	deallocateItem((yyvsp[(4) - (4)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
	if(!transResult)
	{
		YYERROR;
	}
;}
    break;

  case 119:

/* Line 1464 of yacc.c  */
#line 1632 "parser.y"
    {
	bool transResult = handleConstraintLaw((yyvsp[(2) - (4)].parseElement), NULL, (yyvsp[(4) - (4)].parseElement), NULL);
	deallocateItem((yyvsp[(2) - (4)].parseElement));
	deallocateItem((yyvsp[(4) - (4)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
	if(!transResult)
	{
		YYERROR;
	}
;}
    break;

  case 120:

/* Line 1464 of yacc.c  */
#line 1643 "parser.y"
    {
	bool transResult = handleConstraintLaw((yyvsp[(2) - (2)].parseElement), NULL, NULL, NULL);
	deallocateItem((yyvsp[(2) - (2)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
	if(!transResult)
	{
		YYERROR;
	}
;}
    break;

  case 121:

/* Line 1464 of yacc.c  */
#line 1655 "parser.y"
    {
	bool transResult = handleDefaultLaw((yyvsp[(2) - (8)].parseElement), (yyvsp[(4) - (8)].parseElement), (yyvsp[(6) - (8)].parseElement), (yyvsp[(8) - (8)].parseElement));
	deallocateItem((yyvsp[(2) - (8)].parseElement));
	deallocateItem((yyvsp[(4) - (8)].parseElement));
	deallocateItem((yyvsp[(6) - (8)].parseElement));
	deallocateItem((yyvsp[(8) - (8)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
	if(!transResult)
	{
		YYERROR;
	}
;}
    break;

  case 122:

/* Line 1464 of yacc.c  */
#line 1668 "parser.y"
    {
	bool transResult = handleDefaultLaw((yyvsp[(2) - (6)].parseElement), (yyvsp[(4) - (6)].parseElement), (yyvsp[(6) - (6)].parseElement), NULL);
	deallocateItem((yyvsp[(2) - (6)].parseElement));
	deallocateItem((yyvsp[(4) - (6)].parseElement));
	deallocateItem((yyvsp[(6) - (6)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
	if(!transResult)
	{
		YYERROR;
	}
;}
    break;

  case 123:

/* Line 1464 of yacc.c  */
#line 1680 "parser.y"
    {
	bool transResult = handleDefaultLaw((yyvsp[(2) - (6)].parseElement), (yyvsp[(4) - (6)].parseElement), NULL, (yyvsp[(6) - (6)].parseElement));
	deallocateItem((yyvsp[(2) - (6)].parseElement));
	deallocateItem((yyvsp[(4) - (6)].parseElement));
	deallocateItem((yyvsp[(6) - (6)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
	if(!transResult)
	{
		YYERROR;
	}
;}
    break;

  case 124:

/* Line 1464 of yacc.c  */
#line 1692 "parser.y"
    {
	bool transResult = handleDefaultLaw((yyvsp[(2) - (4)].parseElement), (yyvsp[(4) - (4)].parseElement), NULL, NULL);
	deallocateItem((yyvsp[(2) - (4)].parseElement));
	deallocateItem((yyvsp[(4) - (4)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
	if(!transResult)
	{
		YYERROR;
	}
;}
    break;

  case 125:

/* Line 1464 of yacc.c  */
#line 1703 "parser.y"
    {
	bool transResult = handleDefaultLaw((yyvsp[(2) - (6)].parseElement), NULL, (yyvsp[(4) - (6)].parseElement), (yyvsp[(6) - (6)].parseElement));
	deallocateItem((yyvsp[(2) - (6)].parseElement));
	deallocateItem((yyvsp[(4) - (6)].parseElement));
	deallocateItem((yyvsp[(6) - (6)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
	if(!transResult)
	{
		YYERROR;
	}
;}
    break;

  case 126:

/* Line 1464 of yacc.c  */
#line 1715 "parser.y"
    {
	bool transResult = handleDefaultLaw((yyvsp[(2) - (4)].parseElement), NULL, (yyvsp[(4) - (4)].parseElement), NULL);
	deallocateItem((yyvsp[(2) - (4)].parseElement));
	deallocateItem((yyvsp[(4) - (4)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
	if(!transResult)
	{
		YYERROR;
	}
;}
    break;

  case 127:

/* Line 1464 of yacc.c  */
#line 1726 "parser.y"
    {
	bool transResult = handleDefaultLaw((yyvsp[(2) - (4)].parseElement), NULL, NULL, (yyvsp[(4) - (4)].parseElement));
	deallocateItem((yyvsp[(2) - (4)].parseElement));
	deallocateItem((yyvsp[(4) - (4)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
	if(!transResult)
	{
		YYERROR;
	}
;}
    break;

  case 128:

/* Line 1464 of yacc.c  */
#line 1737 "parser.y"
    {
	bool transResult = handleDefaultLaw((yyvsp[(2) - (2)].parseElement), NULL, NULL, NULL);
	deallocateItem((yyvsp[(2) - (2)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
	if(!transResult)
	{
		YYERROR;
	}
;}
    break;

  case 129:

/* Line 1464 of yacc.c  */
#line 1749 "parser.y"
    {
	bool transResult = handleDeclarativeLaw((yyvsp[(2) - (8)].parseElement), (yyvsp[(4) - (8)].parseElement), (yyvsp[(6) - (8)].parseElement), (yyvsp[(8) - (8)].parseElement), SimpleUnaryOperator::UOP_EXOGENOUS);
	deallocateItem((yyvsp[(2) - (8)].parseElement));
	deallocateItem((yyvsp[(4) - (8)].parseElement));
	deallocateItem((yyvsp[(6) - (8)].parseElement));
	deallocateItem((yyvsp[(8) - (8)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
	if(!transResult)
	{
		YYERROR;
	}
;}
    break;

  case 130:

/* Line 1464 of yacc.c  */
#line 1762 "parser.y"
    {
	bool transResult = handleDeclarativeLaw((yyvsp[(2) - (6)].parseElement), (yyvsp[(4) - (6)].parseElement), (yyvsp[(6) - (6)].parseElement), NULL, SimpleUnaryOperator::UOP_EXOGENOUS);
	deallocateItem((yyvsp[(2) - (6)].parseElement));
	deallocateItem((yyvsp[(4) - (6)].parseElement));
	deallocateItem((yyvsp[(6) - (6)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
	if(!transResult)
	{
		YYERROR;
	}
;}
    break;

  case 131:

/* Line 1464 of yacc.c  */
#line 1774 "parser.y"
    {
	bool transResult = handleDeclarativeLaw((yyvsp[(2) - (6)].parseElement), NULL, (yyvsp[(4) - (6)].parseElement), (yyvsp[(6) - (6)].parseElement), SimpleUnaryOperator::UOP_EXOGENOUS);
	deallocateItem((yyvsp[(2) - (6)].parseElement));
	deallocateItem((yyvsp[(4) - (6)].parseElement));
	deallocateItem((yyvsp[(6) - (6)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
	if(!transResult)
	{
		YYERROR;
	}
;}
    break;

  case 132:

/* Line 1464 of yacc.c  */
#line 1786 "parser.y"
    {
	bool transResult = handleDeclarativeLaw((yyvsp[(2) - (4)].parseElement), NULL, (yyvsp[(4) - (4)].parseElement), NULL, SimpleUnaryOperator::UOP_EXOGENOUS);
	deallocateItem((yyvsp[(2) - (4)].parseElement));
	deallocateItem((yyvsp[(4) - (4)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
	if(!transResult)
	{
		YYERROR;
	}
;}
    break;

  case 133:

/* Line 1464 of yacc.c  */
#line 1797 "parser.y"
    {
	bool transResult = handleDeclarativeLaw((yyvsp[(2) - (6)].parseElement), (yyvsp[(4) - (6)].parseElement), NULL, (yyvsp[(6) - (6)].parseElement), SimpleUnaryOperator::UOP_EXOGENOUS);
	deallocateItem((yyvsp[(2) - (6)].parseElement));
	deallocateItem((yyvsp[(4) - (6)].parseElement));
	deallocateItem((yyvsp[(6) - (6)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
	if(!transResult)
	{
		YYERROR;
	}
;}
    break;

  case 134:

/* Line 1464 of yacc.c  */
#line 1809 "parser.y"
    {
	bool transResult = handleDeclarativeLaw((yyvsp[(2) - (4)].parseElement), (yyvsp[(4) - (4)].parseElement), NULL, NULL, SimpleUnaryOperator::UOP_EXOGENOUS);
	deallocateItem((yyvsp[(2) - (4)].parseElement));
	deallocateItem((yyvsp[(4) - (4)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
	if(!transResult)
	{
		YYERROR;
	}
;}
    break;

  case 135:

/* Line 1464 of yacc.c  */
#line 1820 "parser.y"
    {
	bool transResult = handleDeclarativeLaw((yyvsp[(2) - (4)].parseElement), NULL, NULL, (yyvsp[(4) - (4)].parseElement), SimpleUnaryOperator::UOP_EXOGENOUS);
	deallocateItem((yyvsp[(2) - (4)].parseElement));
	deallocateItem((yyvsp[(4) - (4)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
	if(!transResult)
	{
		YYERROR;
	}
;}
    break;

  case 136:

/* Line 1464 of yacc.c  */
#line 1831 "parser.y"
    {
	bool transResult = handleDeclarativeLaw((yyvsp[(2) - (2)].parseElement), NULL, NULL, NULL, SimpleUnaryOperator::UOP_EXOGENOUS);
	deallocateItem((yyvsp[(2) - (2)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
	if(!transResult)
	{
		YYERROR;
	}
;}
    break;

  case 137:

/* Line 1464 of yacc.c  */
#line 1843 "parser.y"
    {
	bool transResult = handleDeclarativeLaw((yyvsp[(2) - (6)].parseElement), (yyvsp[(4) - (6)].parseElement), NULL, (yyvsp[(6) - (6)].parseElement), SimpleUnaryOperator::UOP_INERTIAL);
	deallocateItem((yyvsp[(2) - (6)].parseElement));
	deallocateItem((yyvsp[(4) - (6)].parseElement));
	deallocateItem((yyvsp[(6) - (6)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
	if(!transResult)
	{
		YYERROR;
	}
;}
    break;

  case 138:

/* Line 1464 of yacc.c  */
#line 1855 "parser.y"
    {
	bool transResult = handleDeclarativeLaw((yyvsp[(2) - (4)].parseElement), (yyvsp[(4) - (4)].parseElement), NULL, NULL, SimpleUnaryOperator::UOP_INERTIAL);
	deallocateItem((yyvsp[(2) - (4)].parseElement));
	deallocateItem((yyvsp[(4) - (4)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
	if(!transResult)
	{
		YYERROR;
	}
;}
    break;

  case 139:

/* Line 1464 of yacc.c  */
#line 1866 "parser.y"
    {
	bool transResult = handleDeclarativeLaw((yyvsp[(2) - (4)].parseElement), NULL, NULL, (yyvsp[(4) - (4)].parseElement), SimpleUnaryOperator::UOP_INERTIAL);
	deallocateItem((yyvsp[(2) - (4)].parseElement));
	deallocateItem((yyvsp[(4) - (4)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
	if(!transResult)
	{
		YYERROR;
	}
;}
    break;

  case 140:

/* Line 1464 of yacc.c  */
#line 1877 "parser.y"
    {
	bool transResult = handleDeclarativeLaw((yyvsp[(2) - (2)].parseElement), NULL, NULL, NULL, SimpleUnaryOperator::UOP_INERTIAL);
	deallocateItem((yyvsp[(2) - (2)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
	if(!transResult)
	{
		YYERROR;
	}
;}
    break;

  case 141:

/* Line 1464 of yacc.c  */
#line 1889 "parser.y"
    {
	bool transResult = handleNonexecutableLaw((yyvsp[(2) - (6)].parseElement), (yyvsp[(4) - (6)].parseElement), (yyvsp[(6) - (6)].parseElement));
	deallocateItem((yyvsp[(2) - (6)].parseElement));
	deallocateItem((yyvsp[(4) - (6)].parseElement));
	deallocateItem((yyvsp[(6) - (6)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
	if(!transResult)
	{
		YYERROR;
	}
;}
    break;

  case 142:

/* Line 1464 of yacc.c  */
#line 1901 "parser.y"
    {
	bool transResult = handleNonexecutableLaw((yyvsp[(2) - (4)].parseElement), (yyvsp[(4) - (4)].parseElement), NULL);
	deallocateItem((yyvsp[(2) - (4)].parseElement));
	deallocateItem((yyvsp[(4) - (4)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
	if(!transResult)
	{
		YYERROR;
	}
;}
    break;

  case 143:

/* Line 1464 of yacc.c  */
#line 1912 "parser.y"
    {
	bool transResult = handleNonexecutableLaw((yyvsp[(2) - (4)].parseElement), NULL, (yyvsp[(4) - (4)].parseElement));
	deallocateItem((yyvsp[(2) - (4)].parseElement));
	deallocateItem((yyvsp[(4) - (4)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
	if(!transResult)
	{
		YYERROR;
	}
;}
    break;

  case 144:

/* Line 1464 of yacc.c  */
#line 1923 "parser.y"
    {
	bool transResult = handleNonexecutableLaw((yyvsp[(2) - (2)].parseElement), NULL, NULL);
	deallocateItem((yyvsp[(2) - (2)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
	if(!transResult)
	{
		YYERROR;
	}
;}
    break;

  case 145:

/* Line 1464 of yacc.c  */
#line 1935 "parser.y"
    {
	bool transResult = handleDeclarativeLaw((yyvsp[(2) - (4)].parseElement), NULL, NULL, (yyvsp[(4) - (4)].parseElement), SimpleUnaryOperator::UOP_RIGID);
	deallocateItem((yyvsp[(2) - (4)].parseElement));
	deallocateItem((yyvsp[(4) - (4)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
	if(!transResult)
	{
		YYERROR;
	}
;}
    break;

  case 146:

/* Line 1464 of yacc.c  */
#line 1946 "parser.y"
    {
	bool transResult = handleDeclarativeLaw((yyvsp[(2) - (2)].parseElement), NULL, NULL, NULL, SimpleUnaryOperator::UOP_RIGID);
	deallocateItem((yyvsp[(2) - (2)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
	if(!transResult)
	{
		YYERROR;
	}
;}
    break;

  case 147:

/* Line 1464 of yacc.c  */
#line 1958 "parser.y"
    {
	bool transResult = handlePossiblyCausedLaw((yyvsp[(2) - (8)].parseElement), (yyvsp[(4) - (8)].parseElement), (yyvsp[(6) - (8)].parseElement), (yyvsp[(8) - (8)].parseElement));
	deallocateItem((yyvsp[(2) - (8)].parseElement));
	deallocateItem((yyvsp[(4) - (8)].parseElement));
	deallocateItem((yyvsp[(6) - (8)].parseElement));
	deallocateItem((yyvsp[(8) - (8)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
	if(!transResult)
	{
		YYERROR;
	}
;}
    break;

  case 148:

/* Line 1464 of yacc.c  */
#line 1971 "parser.y"
    {
	bool transResult = handlePossiblyCausedLaw((yyvsp[(2) - (6)].parseElement), (yyvsp[(4) - (6)].parseElement), (yyvsp[(6) - (6)].parseElement), NULL);
	deallocateItem((yyvsp[(2) - (6)].parseElement));
	deallocateItem((yyvsp[(4) - (6)].parseElement));
	deallocateItem((yyvsp[(6) - (6)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
	if(!transResult)
	{
		YYERROR;
	}
;}
    break;

  case 149:

/* Line 1464 of yacc.c  */
#line 1983 "parser.y"
    {
	bool transResult = handlePossiblyCausedLaw((yyvsp[(2) - (6)].parseElement), (yyvsp[(4) - (6)].parseElement), NULL, (yyvsp[(6) - (6)].parseElement));
	deallocateItem((yyvsp[(2) - (6)].parseElement));
	deallocateItem((yyvsp[(4) - (6)].parseElement));
	deallocateItem((yyvsp[(6) - (6)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
	if(!transResult)
	{
		YYERROR;
	}
;}
    break;

  case 150:

/* Line 1464 of yacc.c  */
#line 1995 "parser.y"
    {
	bool transResult = handlePossiblyCausedLaw((yyvsp[(2) - (4)].parseElement), (yyvsp[(4) - (4)].parseElement), NULL, NULL);
	deallocateItem((yyvsp[(2) - (4)].parseElement));
	deallocateItem((yyvsp[(4) - (4)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
	if(!transResult)
	{
		YYERROR;
	}
;}
    break;

  case 151:

/* Line 1464 of yacc.c  */
#line 2006 "parser.y"
    {
	bool transResult = handlePossiblyCausedLaw((yyvsp[(2) - (6)].parseElement), NULL, (yyvsp[(4) - (6)].parseElement), (yyvsp[(6) - (6)].parseElement));
	deallocateItem((yyvsp[(2) - (6)].parseElement));
	deallocateItem((yyvsp[(4) - (6)].parseElement));
	deallocateItem((yyvsp[(6) - (6)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
	if(!transResult)
	{
		YYERROR;
	}
;}
    break;

  case 152:

/* Line 1464 of yacc.c  */
#line 2018 "parser.y"
    {
	bool transResult = handlePossiblyCausedLaw((yyvsp[(2) - (4)].parseElement), NULL, (yyvsp[(4) - (4)].parseElement), NULL);
	deallocateItem((yyvsp[(2) - (4)].parseElement));
	deallocateItem((yyvsp[(4) - (4)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
	if(!transResult)
	{
		YYERROR;
	}
;}
    break;

  case 153:

/* Line 1464 of yacc.c  */
#line 2029 "parser.y"
    {
	bool transResult = handlePossiblyCausedLaw((yyvsp[(2) - (4)].parseElement), NULL, NULL, (yyvsp[(4) - (4)].parseElement));
	deallocateItem((yyvsp[(2) - (4)].parseElement));
	deallocateItem((yyvsp[(4) - (4)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
	if(!transResult)
	{
		YYERROR;
	}
;}
    break;

  case 154:

/* Line 1464 of yacc.c  */
#line 2040 "parser.y"
    {
	bool transResult = handlePossiblyCausedLaw((yyvsp[(2) - (2)].parseElement), NULL, NULL, NULL);
	deallocateItem((yyvsp[(2) - (2)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
	if(!transResult)
	{
		YYERROR;
	}
;}
    break;

  case 155:

/* Line 1464 of yacc.c  */
#line 2052 "parser.y"
    {
	bool transResult = handleMayCauseLaw((yyvsp[(1) - (7)].parseElement), (yyvsp[(3) - (7)].parseElement), (yyvsp[(5) - (7)].parseElement), (yyvsp[(7) - (7)].parseElement));
	deallocateItem((yyvsp[(1) - (7)].parseElement));
	deallocateItem((yyvsp[(3) - (7)].parseElement));
	deallocateItem((yyvsp[(5) - (7)].parseElement));
	deallocateItem((yyvsp[(7) - (7)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
	if(!transResult)
	{
		YYERROR;
	}
;}
    break;

  case 156:

/* Line 1464 of yacc.c  */
#line 2065 "parser.y"
    {
	bool transResult = handleMayCauseLaw((yyvsp[(1) - (5)].parseElement), (yyvsp[(3) - (5)].parseElement), (yyvsp[(5) - (5)].parseElement), NULL);
	deallocateItem((yyvsp[(1) - (5)].parseElement));
	deallocateItem((yyvsp[(3) - (5)].parseElement));
	deallocateItem((yyvsp[(5) - (5)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
	if(!transResult)
	{
		YYERROR;
	}
;}
    break;

  case 157:

/* Line 1464 of yacc.c  */
#line 2077 "parser.y"
    {
	bool transResult = handleMayCauseLaw((yyvsp[(1) - (5)].parseElement), (yyvsp[(3) - (5)].parseElement), NULL, (yyvsp[(5) - (5)].parseElement));
	deallocateItem((yyvsp[(1) - (5)].parseElement));
	deallocateItem((yyvsp[(3) - (5)].parseElement));
	deallocateItem((yyvsp[(5) - (5)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
	if(!transResult)
	{
		YYERROR;
	}
;}
    break;

  case 158:

/* Line 1464 of yacc.c  */
#line 2089 "parser.y"
    {
	bool transResult = handleMayCauseLaw((yyvsp[(1) - (3)].parseElement), (yyvsp[(3) - (3)].parseElement), NULL, NULL);
	deallocateItem((yyvsp[(1) - (3)].parseElement));
	deallocateItem((yyvsp[(3) - (3)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
	if(!transResult)
	{
		YYERROR;
	}
;}
    break;

  case 159:

/* Line 1464 of yacc.c  */
#line 2102 "parser.y"
    {
	bool transResult = handleCausesLaw((yyvsp[(1) - (7)].parseElement), (yyvsp[(3) - (7)].parseElement), (yyvsp[(5) - (7)].parseElement), (yyvsp[(7) - (7)].parseElement));
	deallocateItem((yyvsp[(1) - (7)].parseElement));
	deallocateItem((yyvsp[(3) - (7)].parseElement));
	deallocateItem((yyvsp[(5) - (7)].parseElement));
	deallocateItem((yyvsp[(7) - (7)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
	if(!transResult)
	{
		YYERROR;
	}
;}
    break;

  case 160:

/* Line 1464 of yacc.c  */
#line 2115 "parser.y"
    {
	bool transResult = handleCausesLaw((yyvsp[(1) - (5)].parseElement), (yyvsp[(3) - (5)].parseElement), (yyvsp[(5) - (5)].parseElement), NULL);
	deallocateItem((yyvsp[(1) - (5)].parseElement));
	deallocateItem((yyvsp[(3) - (5)].parseElement));
	deallocateItem((yyvsp[(5) - (5)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
	if(!transResult)
	{
		YYERROR;
	}
;}
    break;

  case 161:

/* Line 1464 of yacc.c  */
#line 2127 "parser.y"
    {
	bool transResult = handleCausesLaw((yyvsp[(1) - (5)].parseElement), (yyvsp[(3) - (5)].parseElement), NULL, (yyvsp[(5) - (5)].parseElement));
	deallocateItem((yyvsp[(1) - (5)].parseElement));
	deallocateItem((yyvsp[(3) - (5)].parseElement));
	deallocateItem((yyvsp[(5) - (5)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
	if(!transResult)
	{
		YYERROR;
	}
;}
    break;

  case 162:

/* Line 1464 of yacc.c  */
#line 2139 "parser.y"
    {
	bool transResult = handleCausesLaw((yyvsp[(1) - (3)].parseElement), (yyvsp[(3) - (3)].parseElement), NULL, NULL);
	deallocateItem((yyvsp[(1) - (3)].parseElement));
	deallocateItem((yyvsp[(3) - (3)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
	if(!transResult)
	{
		YYERROR;
	}
;}
    break;

  case 163:

/* Line 1464 of yacc.c  */
#line 2152 "parser.y"
    {
	// This one's easy, it's just a pass-through.
	mainTrans.output("noconcurrency.", true);
	(yyval.not_used) = PARSERULE_NOT_USED;
;}
    break;

  case 164:

/* Line 1464 of yacc.c  */
#line 2160 "parser.y"
    {
	bool transResult = handleIncrementLaw((yyvsp[(1) - (9)].parseElement), (yyvsp[(3) - (9)].parseElement), (yyvsp[(5) - (9)].parseElement), (yyvsp[(7) - (9)].parseElement), (yyvsp[(9) - (9)].parseElement), true);
	deallocateItem((yyvsp[(1) - (9)].parseElement));
	deallocateItem((yyvsp[(3) - (9)].parseElement));
	deallocateItem((yyvsp[(5) - (9)].parseElement));
	deallocateItem((yyvsp[(7) - (9)].parseElement));
	deallocateItem((yyvsp[(9) - (9)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
	
	if(!transResult)
	{
		YYERROR;
	}
;}
    break;

  case 165:

/* Line 1464 of yacc.c  */
#line 2175 "parser.y"
    {
	bool transResult = handleIncrementLaw((yyvsp[(1) - (7)].parseElement), (yyvsp[(3) - (7)].parseElement), (yyvsp[(5) - (7)].parseElement), (yyvsp[(7) - (7)].parseElement), NULL, true);
	deallocateItem((yyvsp[(1) - (7)].parseElement));
	deallocateItem((yyvsp[(3) - (7)].parseElement));
	deallocateItem((yyvsp[(5) - (7)].parseElement));
	deallocateItem((yyvsp[(7) - (7)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
	
	if(!transResult)
	{
		YYERROR;
	}
;}
    break;

  case 166:

/* Line 1464 of yacc.c  */
#line 2189 "parser.y"
    {
	bool transResult = handleIncrementLaw((yyvsp[(1) - (7)].parseElement), (yyvsp[(3) - (7)].parseElement), (yyvsp[(5) - (7)].parseElement), NULL, (yyvsp[(7) - (7)].parseElement), true);
	deallocateItem((yyvsp[(1) - (7)].parseElement));
	deallocateItem((yyvsp[(3) - (7)].parseElement));
	deallocateItem((yyvsp[(5) - (7)].parseElement));
	deallocateItem((yyvsp[(7) - (7)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
	
	if(!transResult)
	{
		YYERROR;
	}
;}
    break;

  case 167:

/* Line 1464 of yacc.c  */
#line 2203 "parser.y"
    {
	bool transResult = handleIncrementLaw((yyvsp[(1) - (5)].parseElement), (yyvsp[(3) - (5)].parseElement), (yyvsp[(5) - (5)].parseElement), NULL, NULL, true);
	deallocateItem((yyvsp[(1) - (5)].parseElement));
	deallocateItem((yyvsp[(3) - (5)].parseElement));
	deallocateItem((yyvsp[(5) - (5)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
	
	if(!transResult)
	{
		YYERROR;
	}
;}
    break;

  case 168:

/* Line 1464 of yacc.c  */
#line 2216 "parser.y"
    {
	bool transResult = handleIncrementLaw((yyvsp[(1) - (9)].parseElement), (yyvsp[(3) - (9)].parseElement), (yyvsp[(5) - (9)].parseElement), (yyvsp[(7) - (9)].parseElement), (yyvsp[(9) - (9)].parseElement), false);
	deallocateItem((yyvsp[(1) - (9)].parseElement));
	deallocateItem((yyvsp[(3) - (9)].parseElement));
	deallocateItem((yyvsp[(5) - (9)].parseElement));
	deallocateItem((yyvsp[(7) - (9)].parseElement));
	deallocateItem((yyvsp[(9) - (9)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
	
	if(!transResult)
	{
		YYERROR;
	}
;}
    break;

  case 169:

/* Line 1464 of yacc.c  */
#line 2231 "parser.y"
    {
	bool transResult = handleIncrementLaw((yyvsp[(1) - (7)].parseElement), (yyvsp[(3) - (7)].parseElement), (yyvsp[(5) - (7)].parseElement), (yyvsp[(7) - (7)].parseElement),NULL, false);
	deallocateItem((yyvsp[(1) - (7)].parseElement));
	deallocateItem((yyvsp[(3) - (7)].parseElement));
	deallocateItem((yyvsp[(5) - (7)].parseElement));
	deallocateItem((yyvsp[(7) - (7)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
	
	if(!transResult)
	{
		YYERROR;
	}
;}
    break;

  case 170:

/* Line 1464 of yacc.c  */
#line 2245 "parser.y"
    {
	bool transResult = handleIncrementLaw((yyvsp[(1) - (7)].parseElement), (yyvsp[(3) - (7)].parseElement), (yyvsp[(5) - (7)].parseElement), NULL, (yyvsp[(7) - (7)].parseElement), false);
	deallocateItem((yyvsp[(1) - (7)].parseElement));
	deallocateItem((yyvsp[(3) - (7)].parseElement));
	deallocateItem((yyvsp[(5) - (7)].parseElement));
	deallocateItem((yyvsp[(7) - (7)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
	
	if(!transResult)
	{
		YYERROR;
	}
;}
    break;

  case 171:

/* Line 1464 of yacc.c  */
#line 2259 "parser.y"
    {
	bool transResult = handleIncrementLaw((yyvsp[(1) - (5)].parseElement), (yyvsp[(3) - (5)].parseElement), (yyvsp[(5) - (5)].parseElement), NULL, NULL, false);
	deallocateItem((yyvsp[(1) - (5)].parseElement));
	deallocateItem((yyvsp[(3) - (5)].parseElement));
	deallocateItem((yyvsp[(5) - (5)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
	
	if(!transResult)
	{
		YYERROR;
	}
;}
    break;

  case 172:

/* Line 1464 of yacc.c  */
#line 2274 "parser.y"
    {
	mainTrans.translateCausalLaw((yyvsp[(2) - (10)].parseElement), (yyvsp[(4) - (10)].parseElement), (yyvsp[(6) - (10)].parseElement), (yyvsp[(8) - (10)].parseElement), (yyvsp[(10) - (10)].parseElement));
	deallocateItem((yyvsp[(2) - (10)].parseElement));
	deallocateItem((yyvsp[(4) - (10)].parseElement));
	deallocateItem((yyvsp[(6) - (10)].parseElement));
	deallocateItem((yyvsp[(8) - (10)].parseElement));
	deallocateItem((yyvsp[(10) - (10)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
;}
    break;

  case 173:

/* Line 1464 of yacc.c  */
#line 2284 "parser.y"
    {
	mainTrans.translateCausalLaw((yyvsp[(2) - (8)].parseElement), (yyvsp[(4) - (8)].parseElement), (yyvsp[(6) - (8)].parseElement), (yyvsp[(8) - (8)].parseElement), NULL);
	deallocateItem((yyvsp[(2) - (8)].parseElement));
	deallocateItem((yyvsp[(4) - (8)].parseElement));
	deallocateItem((yyvsp[(6) - (8)].parseElement));
	deallocateItem((yyvsp[(8) - (8)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
;}
    break;

  case 174:

/* Line 1464 of yacc.c  */
#line 2293 "parser.y"
    {
	mainTrans.translateCausalLaw((yyvsp[(2) - (8)].parseElement), (yyvsp[(4) - (8)].parseElement), (yyvsp[(6) - (8)].parseElement), NULL, (yyvsp[(8) - (8)].parseElement));
	deallocateItem((yyvsp[(2) - (8)].parseElement));
	deallocateItem((yyvsp[(4) - (8)].parseElement));
	deallocateItem((yyvsp[(6) - (8)].parseElement));
	deallocateItem((yyvsp[(8) - (8)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
;}
    break;

  case 175:

/* Line 1464 of yacc.c  */
#line 2302 "parser.y"
    {
	mainTrans.translateCausalLaw((yyvsp[(2) - (6)].parseElement), (yyvsp[(4) - (6)].parseElement), (yyvsp[(6) - (6)].parseElement), NULL, NULL);
	deallocateItem((yyvsp[(2) - (6)].parseElement));
	deallocateItem((yyvsp[(4) - (6)].parseElement));
	deallocateItem((yyvsp[(6) - (6)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
;}
    break;

  case 176:

/* Line 1464 of yacc.c  */
#line 2310 "parser.y"
    {
	mainTrans.translateCausalLaw((yyvsp[(2) - (8)].parseElement), (yyvsp[(4) - (8)].parseElement), NULL, (yyvsp[(6) - (8)].parseElement), (yyvsp[(8) - (8)].parseElement));
	deallocateItem((yyvsp[(2) - (8)].parseElement));
	deallocateItem((yyvsp[(4) - (8)].parseElement));
	deallocateItem((yyvsp[(6) - (8)].parseElement));
	deallocateItem((yyvsp[(8) - (8)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
;}
    break;

  case 177:

/* Line 1464 of yacc.c  */
#line 2319 "parser.y"
    {
	mainTrans.translateCausalLaw((yyvsp[(2) - (6)].parseElement), (yyvsp[(4) - (6)].parseElement), NULL, (yyvsp[(6) - (6)].parseElement), NULL);
	deallocateItem((yyvsp[(2) - (6)].parseElement));
	deallocateItem((yyvsp[(4) - (6)].parseElement));
	deallocateItem((yyvsp[(6) - (6)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
;}
    break;

  case 178:

/* Line 1464 of yacc.c  */
#line 2327 "parser.y"
    {
	mainTrans.translateCausalLaw((yyvsp[(2) - (6)].parseElement), (yyvsp[(4) - (6)].parseElement), NULL, NULL, (yyvsp[(6) - (6)].parseElement));
	deallocateItem((yyvsp[(2) - (6)].parseElement));
	deallocateItem((yyvsp[(4) - (6)].parseElement));
	deallocateItem((yyvsp[(6) - (6)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
;}
    break;

  case 179:

/* Line 1464 of yacc.c  */
#line 2335 "parser.y"
    {
	mainTrans.translateCausalLaw((yyvsp[(2) - (4)].parseElement), (yyvsp[(4) - (4)].parseElement), NULL, NULL, NULL);
	deallocateItem((yyvsp[(2) - (4)].parseElement));
	deallocateItem((yyvsp[(4) - (4)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
;}
    break;

  case 180:

/* Line 1464 of yacc.c  */
#line 2342 "parser.y"
    {
	mainTrans.translateCausalLaw((yyvsp[(2) - (8)].parseElement), NULL, (yyvsp[(4) - (8)].parseElement), (yyvsp[(6) - (8)].parseElement), (yyvsp[(8) - (8)].parseElement));
	deallocateItem((yyvsp[(2) - (8)].parseElement));
	deallocateItem((yyvsp[(4) - (8)].parseElement));
	deallocateItem((yyvsp[(6) - (8)].parseElement));
	deallocateItem((yyvsp[(8) - (8)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
;}
    break;

  case 181:

/* Line 1464 of yacc.c  */
#line 2351 "parser.y"
    {
	mainTrans.translateCausalLaw((yyvsp[(2) - (6)].parseElement), NULL, (yyvsp[(4) - (6)].parseElement), (yyvsp[(6) - (6)].parseElement), NULL);
	deallocateItem((yyvsp[(2) - (6)].parseElement));
	deallocateItem((yyvsp[(4) - (6)].parseElement));
	deallocateItem((yyvsp[(6) - (6)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
;}
    break;

  case 182:

/* Line 1464 of yacc.c  */
#line 2359 "parser.y"
    {
	mainTrans.translateCausalLaw((yyvsp[(2) - (6)].parseElement), NULL, (yyvsp[(4) - (6)].parseElement), NULL, (yyvsp[(6) - (6)].parseElement));
	deallocateItem((yyvsp[(2) - (6)].parseElement));
	deallocateItem((yyvsp[(4) - (6)].parseElement));
	deallocateItem((yyvsp[(6) - (6)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
;}
    break;

  case 183:

/* Line 1464 of yacc.c  */
#line 2367 "parser.y"
    {
	mainTrans.translateCausalLaw((yyvsp[(2) - (4)].parseElement), NULL, (yyvsp[(4) - (4)].parseElement), NULL, NULL);
	deallocateItem((yyvsp[(2) - (4)].parseElement));
	deallocateItem((yyvsp[(4) - (4)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
;}
    break;

  case 184:

/* Line 1464 of yacc.c  */
#line 2374 "parser.y"
    {
	mainTrans.translateCausalLaw((yyvsp[(2) - (6)].parseElement), NULL, NULL, (yyvsp[(4) - (6)].parseElement), (yyvsp[(6) - (6)].parseElement));
	deallocateItem((yyvsp[(2) - (6)].parseElement));
	deallocateItem((yyvsp[(4) - (6)].parseElement));
	deallocateItem((yyvsp[(6) - (6)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
;}
    break;

  case 185:

/* Line 1464 of yacc.c  */
#line 2382 "parser.y"
    {
	mainTrans.translateCausalLaw((yyvsp[(2) - (4)].parseElement), NULL, NULL, (yyvsp[(4) - (4)].parseElement), NULL);
	deallocateItem((yyvsp[(2) - (4)].parseElement));
	deallocateItem((yyvsp[(4) - (4)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
;}
    break;

  case 186:

/* Line 1464 of yacc.c  */
#line 2389 "parser.y"
    {
	mainTrans.translateCausalLaw((yyvsp[(2) - (4)].parseElement), NULL, NULL, NULL, (yyvsp[(4) - (4)].parseElement));
	deallocateItem((yyvsp[(2) - (4)].parseElement));
	deallocateItem((yyvsp[(4) - (4)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
;}
    break;

  case 187:

/* Line 1464 of yacc.c  */
#line 2396 "parser.y"
    {
	mainTrans.translateCausalLaw((yyvsp[(2) - (2)].parseElement), NULL, NULL, NULL, NULL);
	deallocateItem((yyvsp[(2) - (2)].parseElement));
	(yyval.not_used) = PARSERULE_NOT_USED;
;}
    break;

  case 188:

/* Line 1464 of yacc.c  */
#line 2404 "parser.y"
    {
	(yyval.parseElement) = (yyvsp[(1) - (1)].parseElement);
;}
    break;

  case 189:

/* Line 1464 of yacc.c  */
#line 2408 "parser.y"
    {
	ObjectLikeElement* tempPE = new ObjectLikeElement();
	tempPE->baseName = "true";
	tempPE->objRef = mainTrans.getObjectLike(tempPE->baseName, 0);
	(yyval.parseElement) = tempPE;
;}
    break;

  case 190:

/* Line 1464 of yacc.c  */
#line 2415 "parser.y"
    {
	ObjectLikeElement* tempPE = new ObjectLikeElement();
	tempPE->baseName = "false";
	tempPE->objRef = mainTrans.getObjectLike(tempPE->baseName, 0);
	(yyval.parseElement) = tempPE;
;}
    break;

  case 191:

/* Line 1464 of yacc.c  */
#line 2424 "parser.y"
    {
	(yyval.parseElement) = (yyvsp[(1) - (1)].parseElement);
;}
    break;

  case 192:

/* Line 1464 of yacc.c  */
#line 2428 "parser.y"
    {
	if((yyvsp[(2) - (3)].parseElement) != NULL)
	{
		(yyvsp[(2) - (3)].parseElement)->parenBefore = true;
		(yyvsp[(2) - (3)].parseElement)->parenAfter = true;
	}
	(yyval.parseElement) = (yyvsp[(2) - (3)].parseElement);
;}
    break;

  case 193:

/* Line 1464 of yacc.c  */
#line 2439 "parser.y"
    {
	(yyval.parseElement) = (yyvsp[(1) - (1)].parseElement);
;}
    break;

  case 194:

/* Line 1464 of yacc.c  */
#line 2443 "parser.y"
    {
	SimpleUnaryOperator* tempPE = new SimpleUnaryOperator();
	tempPE->opType = SimpleUnaryOperator::UOP_NOT;
	tempPE->postOp = (yyvsp[(2) - (2)].parseElement);
	(yyval.parseElement) = tempPE;
;}
    break;

  case 195:

/* Line 1464 of yacc.c  */
#line 2450 "parser.y"
    {
	SimpleBinaryOperator* tempPE = new SimpleBinaryOperator();
	tempPE->opType = SimpleBinaryOperator::BOP_AND;
	tempPE->preOp = (yyvsp[(1) - (3)].parseElement);
	tempPE->postOp = (yyvsp[(3) - (3)].parseElement);
	(yyval.parseElement) = tempPE;
;}
    break;

  case 196:

/* Line 1464 of yacc.c  */
#line 2458 "parser.y"
    {
	SimpleBinaryOperator* tempPE = new SimpleBinaryOperator();
	tempPE->opType = SimpleBinaryOperator::BOP_OR;
	tempPE->preOp = (yyvsp[(1) - (3)].parseElement);
	tempPE->postOp = (yyvsp[(3) - (3)].parseElement);
	(yyval.parseElement) = tempPE;
;}
    break;

  case 197:

/* Line 1464 of yacc.c  */
#line 2466 "parser.y"
    {
	SimpleBinaryOperator* tempPE = new SimpleBinaryOperator();
	tempPE->opType = SimpleBinaryOperator::BOP_EQUIV;
	tempPE->preOp = (yyvsp[(1) - (3)].parseElement);
	tempPE->postOp = (yyvsp[(3) - (3)].parseElement);
	(yyval.parseElement) = tempPE;
;}
    break;

  case 198:

/* Line 1464 of yacc.c  */
#line 2474 "parser.y"
    {
	SimpleBinaryOperator* tempPE = new SimpleBinaryOperator();
	tempPE->opType = SimpleBinaryOperator::BOP_IMPL;
	tempPE->preOp = (yyvsp[(1) - (3)].parseElement);
	tempPE->postOp = (yyvsp[(3) - (3)].parseElement);
	(yyval.parseElement) = tempPE;
;}
    break;

  case 199:

/* Line 1464 of yacc.c  */
#line 2484 "parser.y"
    {
	(yyval.parseElement) = (yyvsp[(1) - (1)].parseElement);
;}
    break;

  case 200:

/* Line 1464 of yacc.c  */
#line 2488 "parser.y"
    {
	if((yyvsp[(2) - (3)].parseElement) != NULL)
	{
		(yyvsp[(2) - (3)].parseElement)->parenBefore = true;
		(yyvsp[(2) - (3)].parseElement)->parenAfter = true;
	}
	(yyval.parseElement) = (yyvsp[(2) - (3)].parseElement);
;}
    break;

  case 201:

/* Line 1464 of yacc.c  */
#line 2499 "parser.y"
    {
	// This is really only allowed to be a constant/variable/object expression, verify that.
	if((yyvsp[(1) - (1)].parseElement) != NULL)
	{
		if((yyvsp[(1) - (1)].parseElement)->elemType != ParseElement::PELEM_BASELIKE && (yyvsp[(1) - (1)].parseElement)->elemType != ParseElement::PELEM_CONSTLIKE && (yyvsp[(1) - (1)].parseElement)->elemType != ParseElement::PELEM_OBJLIKE && (yyvsp[(1) - (1)].parseElement)->elemType != ParseElement::PELEM_VARLIKE)
		{
			ltsyystartParseError(ltsyylloc);
			ltsyyossErr << "Bare expression \"" << (yyvsp[(1) - (1)].parseElement)->fullName() << "\" not allowed there, did you forget an equality or comparison sign?";
			ltsyyreportError();
			deallocateItem((yyvsp[(1) - (1)].parseElement));
		}
	}
	(yyval.parseElement) = (yyvsp[(1) - (1)].parseElement);
	if((yyval.parseElement) == NULL)
	{
		YYERROR;
	}
;}
    break;

  case 202:

/* Line 1464 of yacc.c  */
#line 2518 "parser.y"
    {
	SimpleBinaryOperator* tempPE = new SimpleBinaryOperator();
	tempPE->opType = SimpleBinaryOperator::BOP_EQ;
	tempPE->preOp = (yyvsp[(1) - (3)].parseElement);
	tempPE->postOp = (yyvsp[(3) - (3)].parseElement);
	(yyval.parseElement) = tempPE;
;}
    break;

  case 203:

/* Line 1464 of yacc.c  */
#line 2526 "parser.y"
    {
	SimpleBinaryOperator* tempPE = new SimpleBinaryOperator();
	tempPE->opType = SimpleBinaryOperator::BOP_NEQ;
	tempPE->preOp = (yyvsp[(1) - (3)].parseElement);
	tempPE->postOp = (yyvsp[(3) - (3)].parseElement);
	(yyval.parseElement) = tempPE;
;}
    break;

  case 204:

/* Line 1464 of yacc.c  */
#line 2534 "parser.y"
    {
	SimpleBinaryOperator* tempPE = new SimpleBinaryOperator();
	// A bunch of possible operators bundle into COMPARISON. Find out which one.
	switch((yyvsp[(2) - (3)].integer))
	{
	case T_DBL_EQ:
		tempPE->opType = SimpleBinaryOperator::BOP_DBL_EQ;
		break;
	case T_LTHAN:
		tempPE->opType = SimpleBinaryOperator::BOP_LTHAN;
		break;
	case T_GTHAN:
		tempPE->opType = SimpleBinaryOperator::BOP_GTHAN;
		break;
	case T_EQ_LTHAN:
		tempPE->opType = SimpleBinaryOperator::BOP_LTHAN_EQ;
		break;
	case T_GTHAN_EQ:
		tempPE->opType = SimpleBinaryOperator::BOP_GTHAN_EQ;
		break;
	default:
		tempPE->opType = SimpleBinaryOperator::BOP_UNKNOWN;
	}
	tempPE->preOp = (yyvsp[(1) - (3)].parseElement);
	tempPE->postOp = (yyvsp[(3) - (3)].parseElement);
	(yyval.parseElement) = tempPE;
;}
    break;

  case 205:

/* Line 1464 of yacc.c  */
#line 2562 "parser.y"
    {
	(yyval.parseElement) = (yyvsp[(1) - (1)].parseElement);
;}
    break;

  case 206:

/* Line 1464 of yacc.c  */
#line 2568 "parser.y"
    {
	(yyval.parseElement) = (yyvsp[(1) - (1)].parseElement);
;}
    break;

  case 207:

/* Line 1464 of yacc.c  */
#line 2574 "parser.y"
    {
	(yyval.parseElement) = (yyvsp[(1) - (1)].parseElement);
;}
    break;

  case 208:

/* Line 1464 of yacc.c  */
#line 2578 "parser.y"
    {
	if((yyvsp[(2) - (3)].parseElement) != NULL)
	{
		(yyvsp[(2) - (3)].parseElement)->parenBefore = true;
		(yyvsp[(2) - (3)].parseElement)->parenAfter = true;
	}
	(yyval.parseElement) = (yyvsp[(2) - (3)].parseElement);
;}
    break;

  case 209:

/* Line 1464 of yacc.c  */
#line 2589 "parser.y"
    {
	(yyval.parseElement) = (yyvsp[(1) - (1)].parseElement);
;}
    break;

  case 210:

/* Line 1464 of yacc.c  */
#line 2593 "parser.y"
    {
	SimpleBinaryOperator* tempPE = new SimpleBinaryOperator();
	tempPE->opType = SimpleBinaryOperator::BOP_AND;
	tempPE->preOp = (yyvsp[(1) - (3)].parseElement);
	tempPE->postOp = (yyvsp[(3) - (3)].parseElement);
	(yyval.parseElement) = tempPE;
;}
    break;

  case 211:

/* Line 1464 of yacc.c  */
#line 2603 "parser.y"
    {
	(yyval.parseElement) = (yyvsp[(1) - (1)].parseElement);
;}
    break;

  case 212:

/* Line 1464 of yacc.c  */
#line 2607 "parser.y"
    {
	SimpleUnaryOperator* tempPE = new SimpleUnaryOperator();
	tempPE->opType = SimpleUnaryOperator::UOP_NOT;
	tempPE->postOp = (yyvsp[(2) - (2)].parseElement);
	(yyval.parseElement) = tempPE;
;}
    break;

  case 213:

/* Line 1464 of yacc.c  */
#line 2614 "parser.y"
    {
	SimpleBinaryOperator* tempPE = new SimpleBinaryOperator();
	tempPE->opType = SimpleBinaryOperator::BOP_EQ;
	tempPE->preOp = (yyvsp[(1) - (3)].parseElement);
	tempPE->postOp = (yyvsp[(3) - (3)].parseElement);
	(yyval.parseElement) = tempPE;
;}
    break;

  case 214:

/* Line 1464 of yacc.c  */
#line 2655 "parser.y"
    {
	(yyval.parseElement) = NULL;
	if((yyvsp[(2) - (5)].l_quantPair) != NULL && (yyvsp[(4) - (5)].parseElement) != NULL)
	{
		BigQuantifiers* tempPE = new BigQuantifiers();
		tempPE->quants = *(yyvsp[(2) - (5)].l_quantPair);
		tempPE->postOp = (yyvsp[(4) - (5)].parseElement);
		deallocateList((yyvsp[(2) - (5)].l_quantPair));
		(yyval.parseElement) = tempPE;
	}
;}
    break;

  case 215:

/* Line 1464 of yacc.c  */
#line 2669 "parser.y"
    {
	(yyval.l_quantPair) = NULL;
	if((yyvsp[(1) - (1)].p_quantPair) != NULL)
	{
		(yyval.l_quantPair) = new std::list<std::pair<enum BigQuantifiers::QuantifierType, ParseElement*>* >();
		(yyval.l_quantPair)->push_back((yyvsp[(1) - (1)].p_quantPair));
	}
;}
    break;

  case 216:

/* Line 1464 of yacc.c  */
#line 2678 "parser.y"
    {
	(yyval.l_quantPair) = NULL;
	if((yyvsp[(1) - (1)].p_quantPair) != NULL)
	{
		(yyval.l_quantPair) = new std::list<std::pair<enum BigQuantifiers::QuantifierType, ParseElement*>* >();
		(yyval.l_quantPair)->push_back((yyvsp[(1) - (1)].p_quantPair));
	}
;}
    break;

  case 217:

/* Line 1464 of yacc.c  */
#line 2687 "parser.y"
    {
	if((yyvsp[(1) - (2)].l_quantPair) != NULL && (yyvsp[(2) - (2)].p_quantPair) != NULL)
	{
		(yyval.l_quantPair) = (yyvsp[(1) - (2)].l_quantPair);
		(yyval.l_quantPair)->push_back((yyvsp[(2) - (2)].p_quantPair));
	}
	else
	{
		if((yyvsp[(1) - (2)].l_quantPair) != NULL)
		{
			for(std::list<std::pair<enum BigQuantifiers::QuantifierType, ParseElement*>* >::iterator lIter = (yyvsp[(1) - (2)].l_quantPair)->begin(); lIter != (yyvsp[(1) - (2)].l_quantPair)->end(); ++lIter)
			{
				if((*lIter)->second != NULL)
				{
					deallocateItem((*lIter)->second);
				}
				deallocateItem(*lIter);
			}
			deallocateList((yyvsp[(1) - (2)].l_quantPair));
		}
		if((yyvsp[(2) - (2)].p_quantPair) != NULL)
		{
			if((yyvsp[(2) - (2)].p_quantPair)->second != NULL)
			{
				deallocateItem((yyvsp[(2) - (2)].p_quantPair)->second);
			}
			deallocateItem((yyvsp[(2) - (2)].p_quantPair));
		}
		(yyval.l_quantPair) = NULL;
	}
;}
    break;

  case 218:

/* Line 1464 of yacc.c  */
#line 2719 "parser.y"
    {
	if((yyvsp[(1) - (2)].l_quantPair) != NULL && (yyvsp[(2) - (2)].p_quantPair) != NULL)
	{
		(yyval.l_quantPair) = (yyvsp[(1) - (2)].l_quantPair);
		(yyval.l_quantPair)->push_back((yyvsp[(2) - (2)].p_quantPair));
	}
	else
	{
		if((yyvsp[(1) - (2)].l_quantPair) != NULL)
		{
			for(std::list<std::pair<enum BigQuantifiers::QuantifierType, ParseElement*>* >::iterator lIter = (yyvsp[(1) - (2)].l_quantPair)->begin(); lIter != (yyvsp[(1) - (2)].l_quantPair)->end(); ++lIter)
			{
				if((*lIter)->second != NULL)
				{
					deallocateItem((*lIter)->second);
				}
				deallocateItem(*lIter);
			}
			deallocateList((yyvsp[(1) - (2)].l_quantPair));
		}
		if((yyvsp[(2) - (2)].p_quantPair) != NULL)
		{
			if((yyvsp[(2) - (2)].p_quantPair)->second != NULL)
			{
				deallocateItem((yyvsp[(2) - (2)].p_quantPair)->second);
			}
			deallocateItem((yyvsp[(2) - (2)].p_quantPair));
		}
		(yyval.l_quantPair) = NULL;
	}
;}
    break;

  case 219:

/* Line 1464 of yacc.c  */
#line 2753 "parser.y"
    {
	(yyval.p_quantPair) = new std::pair<enum BigQuantifiers::QuantifierType, ParseElement*>();
	(yyval.p_quantPair)->first = BigQuantifiers::QUANT_CONJ;
	// Guess that the identifier is a variable, otherwise just default to object.
	Variable* varRef = mainTrans.getVariableLike(*(yyvsp[(2) - (2)].str));
	if(varRef == NULL)
	{
		Object* objRef = mainTrans.getObjectLike(*(yyvsp[(2) - (2)].str),0);;
		ObjectLikeElement* tempPE = new ObjectLikeElement();
		tempPE->baseName = *(yyvsp[(2) - (2)].str);
		tempPE->objRef = objRef;
		(yyval.p_quantPair)->second = tempPE;
	}
	else
	{
		VariableLikeElement* tempPE = new VariableLikeElement();
		tempPE->baseName = *(yyvsp[(2) - (2)].str);
		tempPE->varRef = varRef;
		(yyval.p_quantPair)->second = tempPE;
	}
	deallocateItem((yyvsp[(2) - (2)].str));
;}
    break;

  case 220:

/* Line 1464 of yacc.c  */
#line 2778 "parser.y"
    {
	(yyval.p_quantPair) = new std::pair<enum BigQuantifiers::QuantifierType, ParseElement*>();
	(yyval.p_quantPair)->first = BigQuantifiers::QUANT_DISJ;
	// Guess that the identifier is a variable, otherwise just default to object.
	Variable* varRef = mainTrans.getVariableLike(*(yyvsp[(2) - (2)].str));
	if(varRef == NULL)
	{
		Object* objRef = mainTrans.getObjectLike(*(yyvsp[(2) - (2)].str),0);;
		ObjectLikeElement* tempPE = new ObjectLikeElement();
		tempPE->baseName = *(yyvsp[(2) - (2)].str);
		tempPE->objRef = objRef;
		(yyval.p_quantPair)->second = tempPE;
	}
	else
	{
		VariableLikeElement* tempPE = new VariableLikeElement();
		tempPE->baseName = *(yyvsp[(2) - (2)].str);
		tempPE->varRef = varRef;
		(yyval.p_quantPair)->second = tempPE;
	}
	deallocateItem((yyvsp[(2) - (2)].str));
;}
    break;

  case 221:

/* Line 1464 of yacc.c  */
#line 2805 "parser.y"
    {
	(yyval.not_used) = PARSERULE_NOT_USED;
	int addQueryResult = mainTrans.addQuery(mainTrans.tempQuery);
	if(addQueryResult != SymbolTable::ADDSYM_OK)
	{
		if(addQueryResult == SymbolTable::ADDSYM_DUP)
		{	// Query with same label already exists.
			ltsyystartParseError(ltsyylloc);
			ltsyyossErr << "A query with label \"" << mainTrans.tempQuery->label << "\" already exists, query labels must be unique.";
			ltsyyreportError();
		}
		else
		{	// General error.
			ltsyystartParseError(ltsyylloc);
			ltsyyossErr << "Query malformed or missing critical information (e.g., maxstep).";
			ltsyyreportError();
		}
		// We can just error here, the error reporting functions already handle creating a new tempQuery.
		YYERROR;
	}
	else
	{	// It added okay, translate it and make a new tempQuery without destroying the one that just got added.
		mainTrans.translateQuery(mainTrans.tempQuery);
		mainTrans.allocateNewTempQuery();
	}
;}
    break;

  case 222:

/* Line 1464 of yacc.c  */
#line 2834 "parser.y"
    {
	(yyval.not_used) = PARSERULE_NOT_USED;
;}
    break;

  case 223:

/* Line 1464 of yacc.c  */
#line 2838 "parser.y"
    {
	(yyval.not_used) = PARSERULE_NOT_USED;
;}
    break;

  case 224:

/* Line 1464 of yacc.c  */
#line 2844 "parser.y"
    {
	(yyval.not_used) = PARSERULE_NOT_USED;
	if(mainTrans.tempQuery->label == "")
	{
		mainTrans.tempQuery->label = utils::to_string((yyvsp[(3) - (3)].integer));
	}
	else
	{
		ltsyystartParseError(ltsyylloc);
		ltsyyossErr << "label already defined as \"" << mainTrans.tempQuery->maxstep << "\" in this query, can only define it once per query.";
		ltsyyreportError();
		YYERROR;
	}
;}
    break;

  case 225:

/* Line 1464 of yacc.c  */
#line 2859 "parser.y"
    {
	(yyval.not_used) = PARSERULE_NOT_USED;
	if(mainTrans.tempQuery->maxstep == "")
	{
		mainTrans.tempQuery->maxstep = utils::to_string((yyvsp[(3) - (3)].integer));
	}
	else
	{
		ltsyystartParseError(ltsyylloc);
		ltsyyossErr << "maxstep already defined as \"" << mainTrans.tempQuery->maxstep << "\" in this query, can only define it once per query.";
		ltsyyreportError();
		YYERROR;
	}
;}
    break;

  case 226:

/* Line 1464 of yacc.c  */
#line 2874 "parser.y"
    {
	(yyval.not_used) = PARSERULE_NOT_USED;
	// Explicit declaration of a limited form of a number range that only supports (positive) integers as its bounds.
	if(mainTrans.tempQuery->maxstep == "")
	{
		mainTrans.tempQuery->maxstep = utils::to_string((yyvsp[(3) - (5)].integer));
		mainTrans.tempQuery->maxstep += "..";
		mainTrans.tempQuery->maxstep += utils::to_string((yyvsp[(5) - (5)].integer));
	}
	else
	{
		ltsyystartParseError(ltsyylloc);
		ltsyyossErr << "maxstep already defined as \"" << mainTrans.tempQuery->maxstep << "\" in this query, can only define it once per query.";
		ltsyyreportError();
		YYERROR;
	}
;}
    break;

  case 227:

/* Line 1464 of yacc.c  */
#line 2892 "parser.y"
    {
	(yyval.not_used) = PARSERULE_NOT_USED;
	if((yyvsp[(1) - (1)].parseElement) != NULL)
	{
		// Add this new condition to the temp query.
		mainTrans.tempQuery->queryConditions.push_back((yyvsp[(1) - (1)].parseElement));
	}
	else
	{
		ltsyystartWarning(ltsyylloc);
		ltsyyossErr << "Query body formula is NULL!";
		ltsyyreportWarning();
	}
;}
    break;

  case 228:

/* Line 1464 of yacc.c  */
#line 2910 "parser.y"
    {
	(yyval.parseElement) = (yyvsp[(1) - (1)].parseElement);
;}
    break;

  case 229:

/* Line 1464 of yacc.c  */
#line 2914 "parser.y"
    {
	if((yyvsp[(2) - (3)].parseElement) != NULL)
	{
		(yyvsp[(2) - (3)].parseElement)->parenBefore = true;
		(yyvsp[(2) - (3)].parseElement)->parenAfter = true;
	}
	(yyval.parseElement) = (yyvsp[(2) - (3)].parseElement);
;}
    break;

  case 230:

/* Line 1464 of yacc.c  */
#line 2923 "parser.y"
    {
	// Turn the time stamp into a plain, translated string representation, then propogate it through the body formula.
	std::string tempTimeStamp = "";
	if((yyvsp[(1) - (3)].parseElement) != NULL)
	{
		tempTimeStamp = (yyvsp[(1) - (3)].parseElement)->translate();
		deallocateItem((yyvsp[(1) - (3)].parseElement));
	}
	if((yyvsp[(3) - (3)].parseElement) != NULL)
	{
		(yyvsp[(3) - (3)].parseElement)->propogateTimeStamp(tempTimeStamp);
	}
	else
	{
		ltsyystartWarning(ltsyylloc);
		ltsyyossErr << "Query body formula with time stamp \"" << tempTimeStamp << "\" is NULL!";
		ltsyyreportWarning();
	}
	(yyval.parseElement) = (yyvsp[(3) - (3)].parseElement);
;}
    break;

  case 231:

/* Line 1464 of yacc.c  */
#line 2946 "parser.y"
    {
	(yyval.parseElement) = (yyvsp[(1) - (1)].parseElement);
;}
    break;

  case 232:

/* Line 1464 of yacc.c  */
#line 2950 "parser.y"
    {
	SimpleUnaryOperator* tempPE = new SimpleUnaryOperator();
	tempPE->opType = SimpleUnaryOperator::UOP_NOT;
	tempPE->postOp = (yyvsp[(2) - (2)].parseElement);
	(yyval.parseElement) = tempPE;
;}
    break;

  case 233:

/* Line 1464 of yacc.c  */
#line 2957 "parser.y"
    {
	SimpleBinaryOperator* tempPE = new SimpleBinaryOperator();
	tempPE->opType = SimpleBinaryOperator::BOP_AND;
	tempPE->preOp = (yyvsp[(1) - (3)].parseElement);
	tempPE->postOp = (yyvsp[(3) - (3)].parseElement);
	(yyval.parseElement) = tempPE;
;}
    break;

  case 234:

/* Line 1464 of yacc.c  */
#line 2965 "parser.y"
    {
	SimpleBinaryOperator* tempPE = new SimpleBinaryOperator();
	tempPE->opType = SimpleBinaryOperator::BOP_OR;
	tempPE->preOp = (yyvsp[(1) - (3)].parseElement);
	tempPE->postOp = (yyvsp[(3) - (3)].parseElement);
	(yyval.parseElement) = tempPE;
;}
    break;

  case 235:

/* Line 1464 of yacc.c  */
#line 2973 "parser.y"
    {
	SimpleBinaryOperator* tempPE = new SimpleBinaryOperator();
	tempPE->opType = SimpleBinaryOperator::BOP_EQUIV;
	tempPE->preOp = (yyvsp[(1) - (3)].parseElement);
	tempPE->postOp = (yyvsp[(3) - (3)].parseElement);
	(yyval.parseElement) = tempPE;
;}
    break;

  case 236:

/* Line 1464 of yacc.c  */
#line 2981 "parser.y"
    {
	SimpleBinaryOperator* tempPE = new SimpleBinaryOperator();
	tempPE->opType = SimpleBinaryOperator::BOP_IMPL;
	tempPE->preOp = (yyvsp[(1) - (3)].parseElement);
	tempPE->postOp = (yyvsp[(3) - (3)].parseElement);
	(yyval.parseElement) = tempPE;
;}
    break;

  case 237:

/* Line 1464 of yacc.c  */
#line 2991 "parser.y"
    {
	(yyval.parseElement) = (yyvsp[(1) - (1)].parseElement);
;}
    break;

  case 238:

/* Line 1464 of yacc.c  */
#line 2995 "parser.y"
    {
	if((yyvsp[(2) - (3)].parseElement) != NULL)
	{
		(yyvsp[(2) - (3)].parseElement)->parenBefore = true;
		(yyvsp[(2) - (3)].parseElement)->parenAfter = true;
	}
	(yyval.parseElement) = (yyvsp[(2) - (3)].parseElement);
;}
    break;

  case 239:

/* Line 1464 of yacc.c  */
#line 3006 "parser.y"
    {
	// This is really only allowed to be a constant/variable/object expression, verify that.
	if((yyvsp[(1) - (1)].parseElement) != NULL)
	{
		if((yyvsp[(1) - (1)].parseElement)->elemType != ParseElement::PELEM_BASELIKE && (yyvsp[(1) - (1)].parseElement)->elemType != ParseElement::PELEM_CONSTLIKE && (yyvsp[(1) - (1)].parseElement)->elemType != ParseElement::PELEM_OBJLIKE && (yyvsp[(1) - (1)].parseElement)->elemType != ParseElement::PELEM_VARLIKE)
		{
			ltsyystartParseError(ltsyylloc);
			ltsyyossErr << "Bare expression \"" << (yyvsp[(1) - (1)].parseElement)->fullName() << "\" not allowed there, did you forget an equality or comparison sign?";
			ltsyyreportError();
			deallocateItem((yyvsp[(1) - (1)].parseElement));
		}
	}
	(yyval.parseElement) = (yyvsp[(1) - (1)].parseElement);
	if((yyval.parseElement) == NULL)
	{
		YYERROR;
	}
;}
    break;

  case 240:

/* Line 1464 of yacc.c  */
#line 3025 "parser.y"
    {
	SimpleBinaryOperator* tempPE = new SimpleBinaryOperator();
	tempPE->opType = SimpleBinaryOperator::BOP_EQ;
	tempPE->preOp = (yyvsp[(1) - (3)].parseElement);
	tempPE->postOp = (yyvsp[(3) - (3)].parseElement);
	(yyval.parseElement) = tempPE;
;}
    break;

  case 241:

/* Line 1464 of yacc.c  */
#line 3033 "parser.y"
    {
	SimpleBinaryOperator* tempPE = new SimpleBinaryOperator();
	tempPE->opType = SimpleBinaryOperator::BOP_NEQ;
	tempPE->preOp = (yyvsp[(1) - (3)].parseElement);
	tempPE->postOp = (yyvsp[(3) - (3)].parseElement);
	(yyval.parseElement) = tempPE;
;}
    break;

  case 242:

/* Line 1464 of yacc.c  */
#line 3041 "parser.y"
    {
	SimpleBinaryOperator* tempPE = new SimpleBinaryOperator();
	// A bunch of possible operators bundle into COMPARISON. Find out which one.
	switch((yyvsp[(2) - (3)].integer))
	{
	case T_DBL_EQ:
		tempPE->opType = SimpleBinaryOperator::BOP_DBL_EQ;
		break;
	case T_LTHAN:
		tempPE->opType = SimpleBinaryOperator::BOP_LTHAN;
		break;
	case T_GTHAN:
		tempPE->opType = SimpleBinaryOperator::BOP_GTHAN;
		break;
	case T_EQ_LTHAN:
		tempPE->opType = SimpleBinaryOperator::BOP_LTHAN_EQ;
		break;
	case T_GTHAN_EQ:
		tempPE->opType = SimpleBinaryOperator::BOP_GTHAN_EQ;
		break;
	default:
		tempPE->opType = SimpleBinaryOperator::BOP_UNKNOWN;
	}
	tempPE->preOp = (yyvsp[(1) - (3)].parseElement);
	tempPE->postOp = (yyvsp[(3) - (3)].parseElement);
	(yyval.parseElement) = tempPE;
;}
    break;

  case 243:

/* Line 1464 of yacc.c  */
#line 3069 "parser.y"
    {
	(yyval.parseElement) = (yyvsp[(1) - (1)].parseElement);
;}
    break;

  case 244:

/* Line 1464 of yacc.c  */
#line 3075 "parser.y"
    {
	(yyval.parseElement) = NULL;
	if((yyvsp[(2) - (5)].l_quantPair) != NULL && (yyvsp[(4) - (5)].parseElement) != NULL)
	{
		BigQuantifiers* tempPE = new BigQuantifiers();
		tempPE->quants = *(yyvsp[(2) - (5)].l_quantPair);
		tempPE->postOp = (yyvsp[(4) - (5)].parseElement);
		deallocateList((yyvsp[(2) - (5)].l_quantPair));
		(yyval.parseElement) = tempPE;
	}
;}
    break;

  case 245:

/* Line 1464 of yacc.c  */
#line 3091 "parser.y"
    {
	// Guess what kind of instance this might be, go with the best match.
	// Guess variable, then constant, then just default to object.
	Variable* varRef = mainTrans.getVariableLike(*(yyvsp[(1) - (1)].str));
	if(varRef == NULL)
	{
		Constant* constRef = mainTrans.getConstantLike(*(yyvsp[(1) - (1)].str),0);
		if(constRef == NULL)
		{
			Object* objRef = mainTrans.getObjectLike(*(yyvsp[(1) - (1)].str),0);;
			ObjectLikeElement* tempPE = new ObjectLikeElement();
			tempPE->baseName = *(yyvsp[(1) - (1)].str);
			tempPE->objRef = objRef;
			(yyval.parseElement) = tempPE;
		}
		else
		{
			ConstantLikeElement* tempPE = new ConstantLikeElement();
			tempPE->baseName = *(yyvsp[(1) - (1)].str);
			tempPE->constRef = constRef;
			(yyval.parseElement) = tempPE;
		}
	}
	else
	{
		VariableLikeElement* tempPE = new VariableLikeElement();
		tempPE->baseName = *(yyvsp[(1) - (1)].str);
		tempPE->varRef = varRef;
		(yyval.parseElement) = tempPE;
	}
	deallocateItem((yyvsp[(1) - (1)].str));
;}
    break;

  case 246:

/* Line 1464 of yacc.c  */
#line 3124 "parser.y"
    {
	// Guess what kind of instance this might be, go with the best match.
	// Guess constant, then just default to object.
	Constant* constRef = mainTrans.getConstantLike(*(yyvsp[(1) - (4)].str),(yyvsp[(3) - (4)].v_parseElement)->size());
	if(constRef == NULL)
	{
		Object* objRef = mainTrans.getObjectLike(*(yyvsp[(1) - (4)].str),(yyvsp[(3) - (4)].v_parseElement)->size());
		ObjectLikeElement* tempPE = new ObjectLikeElement();
		tempPE->baseName = *(yyvsp[(1) - (4)].str);
		tempPE->objRef = objRef;
		(yyval.parseElement) = tempPE;
	}
	else
	{
		ConstantLikeElement* tempPE = new ConstantLikeElement();
		tempPE->baseName = *(yyvsp[(1) - (4)].str);
		tempPE->constRef = constRef;
		(yyval.parseElement) = tempPE;
	}
	// Add the parameters.
	if((yyvsp[(3) - (4)].v_parseElement) != NULL)
	{
		for(std::vector<ParseElement*>::iterator vIter = (yyvsp[(3) - (4)].v_parseElement)->begin(); vIter != (yyvsp[(3) - (4)].v_parseElement)->end(); ++vIter)
		{
			((BaseLikeElement*)(yyval.parseElement))->params.push_back(*vIter);
		}
	}
	deallocateItem((yyvsp[(1) - (4)].str));
	deallocateList((yyvsp[(3) - (4)].v_parseElement));
;}
    break;

  case 247:

/* Line 1464 of yacc.c  */
#line 3157 "parser.y"
    {
	(yyval.v_parseElement) = NULL;
	if((yyvsp[(1) - (1)].parseElement) != NULL)
	{
		(yyval.v_parseElement) = new std::vector<ParseElement*>();
		(yyval.v_parseElement)->push_back((yyvsp[(1) - (1)].parseElement));
	}
;}
    break;

  case 248:

/* Line 1464 of yacc.c  */
#line 3166 "parser.y"
    {
	(yyval.v_parseElement) = NULL;
	if((yyvsp[(1) - (3)].v_parseElement) != NULL && (yyvsp[(3) - (3)].parseElement) != NULL)
	{
		(yyval.v_parseElement) = (yyvsp[(1) - (3)].v_parseElement);
		(yyval.v_parseElement)->push_back((yyvsp[(3) - (3)].parseElement));
	}
;}
    break;

  case 249:

/* Line 1464 of yacc.c  */
#line 3177 "parser.y"
    {
	(yyval.parseElement) = (yyvsp[(1) - (1)].parseElement);
;}
    break;

  case 250:

/* Line 1464 of yacc.c  */
#line 3183 "parser.y"
    {
	Sort* tempSort = mainTrans.getSort(*(yyvsp[(1) - (1)].str));
	(yyval.l_sort) = NULL;
	if(tempSort != NULL)
	{
		(yyval.l_sort) = new std::list<Sort*>;
		(yyval.l_sort)->push_back(tempSort);
	}
	else
	{
		ltsyystartParseError(ltsyylloc);
		ltsyyossErr << "Sort \"" << *(yyvsp[(1) - (1)].str) << "\" not declared, can't use as part of another declaration.";
		ltsyyreportError();
	}
	deallocateItem((yyvsp[(1) - (1)].str));
	if((yyval.l_sort) == NULL)
	{	// If $$ is NULL, something went wrong.
		YYERROR;
	}
;}
    break;

  case 251:

/* Line 1464 of yacc.c  */
#line 3204 "parser.y"
    {
	(yyval.l_sort) = NULL;
	if((yyvsp[(1) - (3)].l_sort) != NULL)
	{
		(yyval.l_sort) = (yyvsp[(1) - (3)].l_sort);
		Sort* tempSort = mainTrans.getSort(*(yyvsp[(3) - (3)].str));
		if(tempSort != NULL)
		{
			(yyval.l_sort)->push_back(tempSort);
		}
		else
		{
			ltsyystartParseError(ltsyylloc);
			ltsyyossErr << "Sort \"" << *(yyvsp[(3) - (3)].str) << "\" not declared, can't use as part of another declaration.";
			ltsyyreportError();
			deallocateList((yyval.l_sort));
		}
	}
	deallocateItem((yyvsp[(3) - (3)].str));
	if((yyval.l_sort) == NULL)
	{	// If $$ is NULL, something went wrong.
		YYERROR;
	}
;}
    break;

  case 252:

/* Line 1464 of yacc.c  */
#line 3231 "parser.y"
    {
	ObjectLikeElement* tempPE = new ObjectLikeElement();
	tempPE->baseName = "true";
	tempPE->objRef = mainTrans.getObjectLike(tempPE->baseName, 0);
	(yyval.parseElement) = tempPE;
;}
    break;

  case 253:

/* Line 1464 of yacc.c  */
#line 3238 "parser.y"
    {
	ObjectLikeElement* tempPE = new ObjectLikeElement();
	tempPE->baseName = "false";
	tempPE->objRef = mainTrans.getObjectLike(tempPE->baseName, 0);
	(yyval.parseElement) = tempPE;
;}
    break;

  case 254:

/* Line 1464 of yacc.c  */
#line 3245 "parser.y"
    {
	ObjectLikeElement* tempPE = new ObjectLikeElement();
	tempPE->baseName = "none";
	tempPE->objRef = mainTrans.getObjectLike(tempPE->baseName, 0);
	(yyval.parseElement) = tempPE;
;}
    break;

  case 255:

/* Line 1464 of yacc.c  */
#line 3252 "parser.y"
    {
	(yyval.parseElement) = (yyvsp[(1) - (1)].parseElement);
;}
    break;

  case 256:

/* Line 1464 of yacc.c  */
#line 3258 "parser.y"
    {
	(yyval.parseElement) = (yyvsp[(1) - (1)].parseElement);
;}
    break;

  case 257:

/* Line 1464 of yacc.c  */
#line 3262 "parser.y"
    {
	(yyval.parseElement) = NULL;
	if((yyvsp[(2) - (3)].parseElement) != NULL)
	{
		(yyval.parseElement) = (yyvsp[(2) - (3)].parseElement);
		(yyval.parseElement)->parenBefore = true;
		(yyval.parseElement)->parenAfter = true;
	}
;}
    break;

  case 258:

/* Line 1464 of yacc.c  */
#line 3274 "parser.y"
    {
	(yyval.parseElement) = (yyvsp[(1) - (1)].parseElement);
;}
    break;

  case 259:

/* Line 1464 of yacc.c  */
#line 3278 "parser.y"
    {
	SimpleBinaryOperator* tempPE = new SimpleBinaryOperator();
	tempPE->opType = SimpleBinaryOperator::BOP_PLUS;
	tempPE->preOp = (yyvsp[(1) - (3)].parseElement);
	tempPE->postOp = (yyvsp[(3) - (3)].parseElement);
	(yyval.parseElement) = tempPE;
;}
    break;

  case 260:

/* Line 1464 of yacc.c  */
#line 3286 "parser.y"
    {
	SimpleBinaryOperator* tempPE = new SimpleBinaryOperator();
	tempPE->opType = SimpleBinaryOperator::BOP_MINUS;
	tempPE->preOp = (yyvsp[(1) - (3)].parseElement);
	tempPE->postOp = (yyvsp[(3) - (3)].parseElement);
	(yyval.parseElement) = tempPE;
;}
    break;

  case 261:

/* Line 1464 of yacc.c  */
#line 3294 "parser.y"
    {
	SimpleBinaryOperator* tempPE = new SimpleBinaryOperator();
	tempPE->opType = SimpleBinaryOperator::BOP_TIMES;
	tempPE->preOp = (yyvsp[(1) - (3)].parseElement);
	tempPE->postOp = (yyvsp[(3) - (3)].parseElement);
	(yyval.parseElement) = tempPE;
;}
    break;

  case 262:

/* Line 1464 of yacc.c  */
#line 3302 "parser.y"
    {
	SimpleBinaryOperator* tempPE = new SimpleBinaryOperator();
	tempPE->opType = SimpleBinaryOperator::BOP_DIVIDE;
	tempPE->preOp = (yyvsp[(1) - (3)].parseElement);
	tempPE->postOp = (yyvsp[(3) - (3)].parseElement);
	(yyval.parseElement) = tempPE;
;}
    break;

  case 263:

/* Line 1464 of yacc.c  */
#line 3310 "parser.y"
    {
	SimpleBinaryOperator* tempPE = new SimpleBinaryOperator();
	tempPE->opType = SimpleBinaryOperator::BOP_MOD;
	tempPE->preOp = (yyvsp[(1) - (3)].parseElement);
	tempPE->postOp = (yyvsp[(3) - (3)].parseElement);
	(yyval.parseElement) = tempPE;
;}
    break;

  case 264:

/* Line 1464 of yacc.c  */
#line 3318 "parser.y"
    {
	SimpleUnaryOperator* tempPE = new SimpleUnaryOperator();
	tempPE->opType = SimpleUnaryOperator::UOP_ABS;
	tempPE->postOp = (yyvsp[(2) - (2)].parseElement);
	(yyval.parseElement) = tempPE;
;}
    break;

  case 265:

/* Line 1464 of yacc.c  */
#line 3325 "parser.y"
    {
	// Not necessary to flag parenBefore and parenAfter, translation of abs
	// automatically adds parentheses around the expression.
	SimpleUnaryOperator* tempPE = new SimpleUnaryOperator();
	tempPE->opType = SimpleUnaryOperator::UOP_ABS;
	tempPE->postOp = (yyvsp[(3) - (4)].parseElement);
	(yyval.parseElement) = tempPE;
;}
    break;

  case 266:

/* Line 1464 of yacc.c  */
#line 3336 "parser.y"
    {
	ObjectLikeElement* tempPE = new ObjectLikeElement();
	tempPE->baseName = *(yyvsp[(1) - (1)].str);
	tempPE->objRef = mainTrans.getObjectLike(tempPE->baseName, 0);
	(yyval.parseElement) = tempPE;
	deallocateItem((yyvsp[(1) - (1)].str));
;}
    break;

  case 267:

/* Line 1464 of yacc.c  */
#line 3344 "parser.y"
    {
	(yyval.parseElement) = (yyvsp[(1) - (1)].parseElement);
;}
    break;

  case 268:

/* Line 1464 of yacc.c  */
#line 3350 "parser.y"
    {
	(yyval.numRange) = new NumberRange();
	std::string tempStr = (*(yyvsp[(1) - (3)].str));
	tempStr += "..";
	tempStr += (*(yyvsp[(3) - (3)].str));
	(yyval.numRange)->name = tempStr;
	(yyval.numRange)->transName = Translator::sanitizeObjectName(tempStr);
	(yyval.numRange)->min = (*(yyvsp[(1) - (3)].str));
	(yyval.numRange)->max = (*(yyvsp[(3) - (3)].str));
	deallocateItem((yyvsp[(1) - (3)].str));
	deallocateItem((yyvsp[(3) - (3)].str));
;}
    break;

  case 269:

/* Line 1464 of yacc.c  */
#line 3365 "parser.y"
    {
	(yyval.str) = new std::string();
	(*(yyval.str)) = utils::to_string((yyvsp[(1) - (1)].integer));
;}
    break;

  case 270:

/* Line 1464 of yacc.c  */
#line 3370 "parser.y"
    {
	(yyval.str) = new std::string;
	(*(yyval.str)) = "maxAdditive";
;}
    break;

  case 271:

/* Line 1464 of yacc.c  */
#line 3375 "parser.y"
    {
	(yyval.str) = new std::string;
	(*(yyval.str)) = "maxstep";
;}
    break;

  case 272:

/* Line 1464 of yacc.c  */
#line 3380 "parser.y"
    {
	(yyval.str) = new std::string();
	(*(yyval.str)) = "-";
	(*(yyval.str)) += (*(yyvsp[(2) - (2)].str));
	deallocateItem((yyvsp[(2) - (2)].str));
;}
    break;

  case 273:

/* Line 1464 of yacc.c  */
#line 3389 "parser.y"
    {
	(yyval.str) = (yyvsp[(1) - (1)].str);
;}
    break;

  case 274:

/* Line 1464 of yacc.c  */
#line 3393 "parser.y"
    {
	(yyval.str) = new std::string();
	(*(yyval.str)) += "(";
	(*(yyval.str)) += (*(yyvsp[(2) - (3)].str));
	(*(yyval.str)) += ")";
	deallocateItem((yyvsp[(2) - (3)].str));
;}
    break;

  case 275:

/* Line 1464 of yacc.c  */
#line 3403 "parser.y"
    {
	(yyval.str) = (yyvsp[(1) - (1)].str);
;}
    break;

  case 276:

/* Line 1464 of yacc.c  */
#line 3407 "parser.y"
    {
	(yyval.str) = new std::string();
	(*(yyval.str)) += (*(yyvsp[(1) - (3)].str));
	(*(yyval.str)) += " + ";
	(*(yyval.str)) += (*(yyvsp[(3) - (3)].str));
	deallocateItem((yyvsp[(1) - (3)].str));
	deallocateItem((yyvsp[(3) - (3)].str));
;}
    break;

  case 277:

/* Line 1464 of yacc.c  */
#line 3416 "parser.y"
    {
	(yyval.str) = new std::string();
	(*(yyval.str)) += (*(yyvsp[(1) - (3)].str));
	(*(yyval.str)) += " - ";
	(*(yyval.str)) += (*(yyvsp[(3) - (3)].str));
	deallocateItem((yyvsp[(1) - (3)].str));
	deallocateItem((yyvsp[(3) - (3)].str));
;}
    break;

  case 278:

/* Line 1464 of yacc.c  */
#line 3425 "parser.y"
    {
	(yyval.str) = new std::string();
	(*(yyval.str)) += (*(yyvsp[(1) - (3)].str));
	(*(yyval.str)) += " * ";
	(*(yyval.str)) += (*(yyvsp[(3) - (3)].str));
	deallocateItem((yyvsp[(1) - (3)].str));
	deallocateItem((yyvsp[(3) - (3)].str));
;}
    break;

  case 279:

/* Line 1464 of yacc.c  */
#line 3434 "parser.y"
    {
	(yyval.str) = new std::string();
	(*(yyval.str)) += (*(yyvsp[(1) - (3)].str));
	(*(yyval.str)) += " // ";
	(*(yyval.str)) += (*(yyvsp[(3) - (3)].str));
	deallocateItem((yyvsp[(1) - (3)].str));
	deallocateItem((yyvsp[(3) - (3)].str));
;}
    break;

  case 280:

/* Line 1464 of yacc.c  */
#line 3443 "parser.y"
    {
	(yyval.str) = new std::string();
	(*(yyval.str)) += (*(yyvsp[(1) - (3)].str));
	(*(yyval.str)) += " mod ";
	(*(yyval.str)) += (*(yyvsp[(3) - (3)].str));
	deallocateItem((yyvsp[(1) - (3)].str));
	deallocateItem((yyvsp[(3) - (3)].str));
;}
    break;

  case 281:

/* Line 1464 of yacc.c  */
#line 3455 "parser.y"
    {
	(yyval.integer) = (yyvsp[(1) - (1)].integer);
;}
    break;

  case 282:

/* Line 1464 of yacc.c  */
#line 3459 "parser.y"
    {
	(yyval.integer) = (yyvsp[(1) - (1)].integer);
;}
    break;

  case 283:

/* Line 1464 of yacc.c  */
#line 3463 "parser.y"
    {
	(yyval.integer) = (yyvsp[(1) - (1)].integer);
;}
    break;

  case 284:

/* Line 1464 of yacc.c  */
#line 3469 "parser.y"
    {
	(yyval.integer) = (yyvsp[(1) - (1)].integer);
;}
    break;

  case 285:

/* Line 1464 of yacc.c  */
#line 3475 "parser.y"
    {
	(yyval.integer) = T_UMINUS;
;}
    break;

  case 286:

/* Line 1464 of yacc.c  */
#line 3479 "parser.y"
    {
	(yyval.integer) = (yyvsp[(1) - (1)].integer);
;}
    break;

  case 287:

/* Line 1464 of yacc.c  */
#line 3485 "parser.y"
    {
	(yyval.integer) = (yyvsp[(1) - (1)].integer);
;}
    break;

  case 288:

/* Line 1464 of yacc.c  */
#line 3491 "parser.y"
    {
	(yyval.integer) = (yyvsp[(1) - (1)].integer);
;}
    break;

  case 289:

/* Line 1464 of yacc.c  */
#line 3495 "parser.y"
    {
	// This means "less than in sorted order", which can be safely approximated with !=.
	(yyval.integer) = (yyvsp[(2) - (2)].integer);
;}
    break;

  case 290:

/* Line 1464 of yacc.c  */
#line 3500 "parser.y"
    {
	// This means "greater than in sorted order", which can be safely approximated with !=.
	(yyval.integer) = (yyvsp[(2) - (2)].integer);
;}
    break;

  case 291:

/* Line 1464 of yacc.c  */
#line 3507 "parser.y"
    {
	(yyval.integer) = (yyvsp[(1) - (1)].integer);
;}
    break;

  case 292:

/* Line 1464 of yacc.c  */
#line 3511 "parser.y"
    {
	(yyval.integer) = (yyvsp[(1) - (1)].integer);
;}
    break;

  case 293:

/* Line 1464 of yacc.c  */
#line 3515 "parser.y"
    {
	(yyval.integer) = (yyvsp[(1) - (1)].integer);
;}
    break;

  case 294:

/* Line 1464 of yacc.c  */
#line 3519 "parser.y"
    {
	(yyval.integer) = (yyvsp[(1) - (1)].integer);
;}
    break;

  case 295:

/* Line 1464 of yacc.c  */
#line 3523 "parser.y"
    {
	(yyval.integer) = (yyvsp[(1) - (1)].integer);
;}
    break;

  case 296:

/* Line 1464 of yacc.c  */
#line 3529 "parser.y"
    {
	(yyval.integer) = (yyvsp[(1) - (1)].integer);
;}
    break;

  case 297:

/* Line 1464 of yacc.c  */
#line 3535 "parser.y"
    {
	(yyval.integer) = (yyvsp[(1) - (1)].integer);
;}
    break;

  case 298:

/* Line 1464 of yacc.c  */
#line 3541 "parser.y"
    {
	(yyval.integer) = (yyvsp[(1) - (1)].integer);
;}
    break;

  case 299:

/* Line 1464 of yacc.c  */
#line 3545 "parser.y"
    {
	// This means "less than or equal to in sorted order", which has no good approximation except for <=.
	(yyval.integer) = (yyvsp[(2) - (2)].integer);
;}
    break;

  case 300:

/* Line 1464 of yacc.c  */
#line 3552 "parser.y"
    {
	(yyval.integer) = (yyvsp[(1) - (1)].integer);
;}
    break;

  case 301:

/* Line 1464 of yacc.c  */
#line 3556 "parser.y"
    {
	// This means "greater than or equal to in sorted order", which has no good approximation except for >=.
	(yyval.integer) = (yyvsp[(2) - (2)].integer);
;}
    break;



/* Line 1464 of yacc.c  */
#line 7111 "parser.cpp"
      default: break;
    }
  YY_SYMBOL_PRINT ("-> $$ =", yyr1[yyn], &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);

  *++yyvsp = yyval;
  *++yylsp = yyloc;

  /* Now `shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTOKENS] + *yyssp;
  if (0 <= yystate && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTOKENS];

  goto yynewstate;


/*------------------------------------.
| yyerrlab -- here on detecting error |
`------------------------------------*/
yyerrlab:
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
#if ! YYERROR_VERBOSE
      yyerror (YY_("syntax error"));
#else
      {
	YYSIZE_T yysize = yysyntax_error (0, yystate, yychar);
	if (yymsg_alloc < yysize && yymsg_alloc < YYSTACK_ALLOC_MAXIMUM)
	  {
	    YYSIZE_T yyalloc = 2 * yysize;
	    if (! (yysize <= yyalloc && yyalloc <= YYSTACK_ALLOC_MAXIMUM))
	      yyalloc = YYSTACK_ALLOC_MAXIMUM;
	    if (yymsg != yymsgbuf)
	      YYSTACK_FREE (yymsg);
	    yymsg = (char *) YYSTACK_ALLOC (yyalloc);
	    if (yymsg)
	      yymsg_alloc = yyalloc;
	    else
	      {
		yymsg = yymsgbuf;
		yymsg_alloc = sizeof yymsgbuf;
	      }
	  }

	if (0 < yysize && yysize <= yymsg_alloc)
	  {
	    (void) yysyntax_error (yymsg, yystate, yychar);
	    yyerror (yymsg);
	  }
	else
	  {
	    yyerror (YY_("syntax error"));
	    if (yysize != 0)
	      goto yyexhaustedlab;
	  }
      }
#endif
    }

  yyerror_range[1] = yylloc;

  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
	 error, discard it.  */

      if (yychar <= YYEOF)
	{
	  /* Return failure if at end of input.  */
	  if (yychar == YYEOF)
	    YYABORT;
	}
      else
	{
	  yydestruct ("Error: discarding",
		      yytoken, &yylval, &yylloc);
	  yychar = YYEMPTY;
	}
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:

  /* Pacify compilers like GCC when the user code never invokes
     YYERROR and the label yyerrorlab therefore never appears in user
     code.  */
  if (/*CONSTCOND*/ 0)
     goto yyerrorlab;

  yyerror_range[1] = yylsp[1-yylen];
  /* Do not reclaim the symbols of the rule which action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;	/* Each real token shifted decrements this.  */

  for (;;)
    {
      yyn = yypact[yystate];
      if (yyn != YYPACT_NINF)
	{
	  yyn += YYTERROR;
	  if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYTERROR)
	    {
	      yyn = yytable[yyn];
	      if (0 < yyn)
		break;
	    }
	}

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
	YYABORT;

      yyerror_range[1] = *yylsp;
      yydestruct ("Error: popping",
		  yystos[yystate], yyvsp, yylsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  *++yyvsp = yylval;

  yyerror_range[2] = yylloc;
  /* Using YYLLOC is tempting, but would change the location of
     the lookahead.  YYLOC is available though.  */
  YYLLOC_DEFAULT (yyloc, yyerror_range, 2);
  *++yylsp = yyloc;

  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", yystos[yyn], yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;

/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;

#if !defined(yyoverflow) || YYERROR_VERBOSE
/*-------------------------------------------------.
| yyexhaustedlab -- memory exhaustion comes here.  |
`-------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  /* Fall through.  */
#endif

yyreturn:
  if (yychar != YYEMPTY)
     yydestruct ("Cleanup: discarding lookahead",
		 yytoken, &yylval, &yylloc);
  /* Do not reclaim the symbols of the rule which action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
		  yystos[*yyssp], yyvsp, yylsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
#if YYERROR_VERBOSE
  if (yymsg != yymsgbuf)
    YYSTACK_FREE (yymsg);
#endif
  /* Make sure YYID is used.  */
  return YYID (yyresult);
}



/* Line 1684 of yacc.c  */
#line 3562 "parser.y"


// Tries to create a Sort out of an identifier and (possibly empty) subsort list.
Sort* processSort(std::string* sortIdent, std::list<Sort*>* subsorts)
{
	Sort* retVal = NULL;
	bool alreadyDeclared = true;
	// Add the sort if it isn't already in the symbol table.
	retVal = mainTrans.getSort(*sortIdent);
	if(retVal == NULL)
	{
		alreadyDeclared = false;
		retVal = new Sort(*sortIdent, Translator::sanitizeSortName(*sortIdent));
		int addSymResult = mainTrans.addSort(retVal);
		if(addSymResult != SymbolTable::ADDSYM_OK)
		{
			if(addSymResult == SymbolTable::ADDSYM_DUP)
			{	// Warn about duplicate sort declarations (not an error), then grab the already-declared sort.
				// Shouldn't encounter this bit of code, the getSort call earlier should take care of the "already exists" case.
				ltsyystartCaution(ltsyylloc);
				ltsyyossErr << "Duplicate sort declaration: \"" << *sortIdent << "\".";
				ltsyyreportCaution();
				deallocateItem(retVal);
				retVal = mainTrans.getSort(*sortIdent);
				alreadyDeclared = true;
			}
			else
			{	// Report a real sort error.
				ltsyystartParseError(ltsyylloc);
				ltsyyossErr << "Bad sort declaration: \"" << *sortIdent << "\".";
				ltsyyreportError();
				deallocateItem(retVal);
			}
		}
		else
		{
			// Try to create (or get) a default variable for the sort, connect the two if nothing goes wrong.
			std::string tempName = retVal->fullName();
			std::string tempTransName = retVal->fullTransName();
			std::string tempVarName = Translator::sortNameToVariable(tempName);
			Variable* tempVar = mainTrans.getVariable(tempVarName);
			if(tempVar == NULL)
			{
				std::string tempTransVarName = Translator::sortNameToVariable(tempTransName);
				tempVar = new Variable(tempVarName, tempTransVarName);
				if(mainTrans.addVariable(tempVar) != SymbolTable::ADDSYM_OK)
				{
					deallocateItem(tempVar);
					ltsyystartParseError(ltsyylloc);
					ltsyyossErr << "Could not create default variable \"" << tempVarName << "\" ";
					ltsyyossErr << "for sort \"" << tempName << "\".";
					ltsyyreportError();
					retVal = NULL; // Won't affect the translator's storage of the (incomplete) sort.
				}
				else
				{
					tempVar->sortRef = retVal;
				}
			}
			if(tempVar != NULL)
			{
				retVal->sortVar = tempVar;
			}
		}
	}
	// Add subsorts to the sort's list.
	if(retVal != NULL && subsorts != NULL)
	{
		for(std::list<Sort*>::iterator lIter = subsorts->begin(); lIter != subsorts->end(); ++lIter)
		{
			if((*lIter) != NULL)
			{
				retVal->subsorts.push_back((*lIter));
				// If the sort was already declared and we're just adding subsorts,
				// perform the translation now.
				if(alreadyDeclared)
				{
					mainTrans.translateSubsortDecl(retVal,*lIter);
				}
			}
		}
	}
	// If the sort is new and is a "something*" sort, make sure its child ("something")
	// is declared too, and link them together.
	if(!alreadyDeclared && sortIdent->length() > 0 && (*sortIdent)[sortIdent->length()-1] == '*')
	{
		// Now find/create the child "something" sort.
		std::string* nonStarIdent = new std::string;
		(*nonStarIdent) = sortIdent->substr(0, sortIdent->length()-1);
		
		// Check if the child already exists before proceeding with declaration etc.
		Sort *nonStarSort = mainTrans.getSort(*nonStarIdent);
		if(nonStarSort == NULL)
		{	// Declare "something" so it can be added as the child of "something*".
			std::list<Sort*>* nonStarSubsorts = new std::list<Sort*>; // Empty on purpose.
			nonStarSort = processSort(nonStarIdent, nonStarSubsorts);
			deallocateList(nonStarSubsorts);
		}
		if(nonStarSort != NULL)
		{
			// Add "something" to subsorts.
			retVal->subsorts.push_back(nonStarSort);
		}
		deallocateItem(nonStarIdent);
		
		// Create an object "none" and associate it with the "something*" sort.
		std::string noneName = "none";
		Object* noneObj = new Object(noneName, Translator::sanitizeObjectName(noneName));
		int noneAddResult = mainTrans.addObject(noneObj);
		if(noneAddResult == SymbolTable::ADDSYM_OK)
		{
			retVal->domainObjs.push_back(noneObj);
			// Output the translation of the object declaration.
			mainTrans.translateObjectDecl(noneObj, retVal);
		}
	}
	// If the sort is new, output its translated declaration.
	if(!alreadyDeclared)
	{
		mainTrans.translateSortDecl(retVal);
	}
	return retVal;
}

// Tries to find an existing normal sort or declare a starred ("something*") sort.
Sort* checkDynamicSortDecl(std::string* sortIdent)
{
	Sort* retVal = mainTrans.getSort(*sortIdent);
	// Allow dynamic instantiation of starred sorts.
	if(retVal == NULL && sortIdent->length() > 0 && (*sortIdent)[sortIdent->length()-1] == '*')
	{
		// Verify that the non-starred version exists before instantiating the starred version.
		std::string* nonStarIdent = new std::string;
		(*nonStarIdent) = sortIdent->substr(0, sortIdent->length()-1);
		Sort *nonStarSort = mainTrans.getSort(*nonStarIdent);
		if(nonStarSort == NULL)
		{	
			ltsyystartParseError(ltsyylloc);
			ltsyyossErr << "Sort \"" << *nonStarIdent << "\" not declared, can't dynamically use \"" << *sortIdent << "\" as the domain of another declaration.";
			ltsyyreportError();
		}
		else
		{
			// Instantiate the starred version, link to child.
			std::list<Sort*>* starSubsorts = new std::list<Sort*>;
			// No need to add unstarred version to subsorts, that's done automatically.
			retVal = processSort(sortIdent, starSubsorts);
			if(retVal == NULL)
			{
				ltsyystartParseError(ltsyylloc);
				ltsyyossErr << "Bad domain declaration \"" << *sortIdent << "\".";
				ltsyyreportError();
			}
			deallocateList(starSubsorts);
		}
		deallocateItem(nonStarIdent);
	}
	else if(retVal == NULL)
	{	// The domain isn't an undeclared starred case, it's just undeclared.
		ltsyystartParseError(ltsyylloc);
		ltsyyossErr << "Sort \"" << *sortIdent << "\" not declared, can't use as the domain of another declaration.";
		ltsyyreportError();
	}
	return retVal;
}

// Transforms declarative laws ("inertial p", "exogenous a(X)", "rigid q", etc.) to basic form and calls the translator for them.
bool handleDeclarativeLaw(ParseElement* head, ParseElement* ifBody, ParseElement* afterBody, ParseElement* whereBody, SimpleUnaryOperator::UnaryOperatorType opType)
{
	bool retVal = false; // Start pessimistic.
	if(head != NULL)
	{
		// head needs to be wrapped in the appropriate declarative operator.
		SimpleUnaryOperator* tempPE = new SimpleUnaryOperator();
		tempPE->opType = opType;
		tempPE->postOp = head;
		// This law becomes "delaration(F) [if G] [after H] [where J]."
		mainTrans.translateCausalLaw(tempPE, ifBody, afterBody, NULL, whereBody);
		retVal = true;
		deallocateTempUnaryOp(tempPE);
	}
	return retVal;
}

// Transforms a causal law of the form "always F [where G]." to basic form, then calls the translator for it.
bool handleAlwaysLaw(ParseElement* constraint, ParseElement* whereBody)
{
	bool retVal = false; // Start pessimistic.
	if(constraint != NULL)
	{
		// "not constraint" is the afterBody.
		SimpleUnaryOperator* tempPE = new SimpleUnaryOperator();
		tempPE->opType = SimpleUnaryOperator::UOP_NOT;
		tempPE->postOp = constraint;
		// The head is "false".
		ObjectLikeElement* tempObj = new ObjectLikeElement();
		tempObj->baseName = "false";
		tempObj->objRef = mainTrans.getObjectLike(tempObj->baseName, 0);
		// The law becomes "caused false after -F where H."
		mainTrans.translateCausalLaw(tempObj, NULL, tempPE, NULL, whereBody);
		delete tempObj;
		deallocateTempUnaryOp(tempPE);
		retVal = true;
	}
	return retVal;
}

// Transforms a causal law of the form "constraint F [after H] [where J]." to basic form, then calls the translator for it.
bool handleConstraintLaw(ParseElement* constraint, ParseElement* afterBody, ParseElement* unlessBody, ParseElement* whereBody)
{
	bool retVal = false; // Start pessimistic.
	if(constraint != NULL)
	{
		// constraint has to be a fluent formula or the law is malformed. Soft warn if we can't tell what it is (i.e., not a fluent or action formula).
		if(!constraint->hasActions())
		{
			if(!constraint->hasFluents())
			{
				ltsyystartWarning(ltsyylloc);
				ltsyyossErr << "Cannot determine if \"" << constraint->fullName() << "\" is a fluent formula or not, it might not work as F in a \"constraint F\" style law.";
				ltsyyreportWarning();
			}
			
			// "not constraint" is the ifBody.
			SimpleUnaryOperator* tempUOP = NULL;
			ParseElement* tempPE = NULL; // Points at whatever ends up becoming the head of the rule.
			// If the constraint is "not something", then we can just drop the not (we'd end up with "not not something", which is equivalent to "something" since "false" is the head).
			if(constraint->elemType == ParseElement::PELEM_UOP && ((SimpleUnaryOperator*)constraint)->opType == SimpleUnaryOperator::UOP_NOT)
			{
				tempPE = ((SimpleUnaryOperator*)constraint)->postOp;
			}
			else
			{	// It's not an optimizable case, just tack "not" onto the constraint.
				tempUOP = new SimpleUnaryOperator();
				tempUOP->opType = SimpleUnaryOperator::UOP_NOT;
				tempUOP->postOp = constraint;
				tempPE = (ParseElement*)tempUOP;
			}
			
			// The head is "false".
			ObjectLikeElement* tempObj = new ObjectLikeElement();
			tempObj->baseName = "false";
			tempObj->objRef = mainTrans.getObjectLike(tempObj->baseName, 0);
			// The law becomes "caused false if -F after G where H."
			mainTrans.translateCausalLaw(tempObj, tempPE, afterBody, unlessBody, whereBody);
			delete tempObj;
			deallocateTempUnaryOp(tempUOP);
			retVal = true;
		}
		else
		{
			ltsyystartParseError(ltsyylloc);
			ltsyyossErr << "\"" << constraint->fullName() << "\" is not a fluent formula, can't use it as F in a \"constraint F\" style law.";
			ltsyyreportError();
		}
	}
	return retVal;
}

// Transforms a causal law of the form "default F [if G] [after H] [where J]." to basic form, then calls the translator on it.
bool handleDefaultLaw(ParseElement* head, ParseElement* ifBody, ParseElement* afterBody, ParseElement* whereBody)
{
	bool retVal = false; // Start pessimistic.
	if(head != NULL)
	{
		// head and ifBody are going to end up together no matter what.
		SimpleBinaryOperator* tempPE = new SimpleBinaryOperator();
		tempPE->opType = SimpleBinaryOperator::BOP_AND;
		tempPE->preOp = head;
		tempPE->postOp = ifBody;
		// This law becomes "caused F if F [& G] [after H] [where J]."
		mainTrans.translateCausalLaw(head, tempPE, afterBody, NULL, whereBody);
		retVal = true;
		deallocateTempBinaryOp(tempPE);
	}
	return retVal;
}

// Transforms a causal law of the form "nonexecutable F [if G] [where H]." to basic form, then calls the translator for it.
bool handleNonexecutableLaw(ParseElement* nonEx, ParseElement* ifBody, ParseElement* whereBody)
{
	bool retVal = false; // Start pessimistic.
	if(nonEx != NULL)
	{
		// nonEx has to be an action formula or the law is malformed. Soft warn if its neither kind of formula.
		if(!nonEx->hasFluents())
		{
			if(!nonEx->hasActions())
			{
				ltsyystartWarning(ltsyylloc);
				ltsyyossErr << "Cannot determine if \"" << nonEx->fullName() << "\" is an action formula or not, it might not work as F in a \"nonexecutable F\" style law.";
				ltsyyreportWarning();
			}
			// nonEx and ifBody are going to end up together no matter what.
			SimpleBinaryOperator* tempPE = new SimpleBinaryOperator();
			tempPE->opType = SimpleBinaryOperator::BOP_AND;
			tempPE->preOp = nonEx;
			tempPE->postOp = ifBody;
			// Create a head of "false".
			ObjectLikeElement* tempObj = new ObjectLikeElement();
			tempObj->baseName = "false";
			tempObj->objRef = mainTrans.getObjectLike(tempObj->baseName, 0);
			mainTrans.translateCausalLaw(tempObj, NULL, tempPE, NULL, whereBody);
			delete tempObj;
			deallocateTempBinaryOp(tempPE);
			retVal = true;
		}
		else
		{
			ltsyystartParseError(ltsyylloc);
			ltsyyossErr << "\"" << nonEx->fullName() << "\" is not an action formula, can't use it as F in a \"nonexecutable F\" style law.";
			ltsyyreportError();
		}
	}
	return retVal;
}

// Transforms a causal law of the form "possibly caused F [if G] [after H] [where J]." to basic form, then calls the translator on it.
bool handlePossiblyCausedLaw(ParseElement* head, ParseElement* ifBody, ParseElement* afterBody, ParseElement* whereBody)
{
	bool retVal = false; // Start pessimistic.
	if(head != NULL)
	{
		// head and ifBody are going to end up together no matter what.
		SimpleBinaryOperator* tempPE = new SimpleBinaryOperator();
		tempPE->opType = SimpleBinaryOperator::BOP_AND;
		tempPE->preOp = head;
		tempPE->postOp = ifBody;
		// This law becomes "caused F if F [& G] [after H] [where J]."
		mainTrans.translateCausalLaw(head, tempPE, afterBody, NULL, whereBody);
		retVal = true;
		deallocateTempBinaryOp(tempPE);
	}
	return retVal;
}

// Transforms a causal law of the form "G may cause F [if H] [where J]." to basic form, then calls the translator on it.
bool handleMayCauseLaw(ParseElement* causer, ParseElement* causee, ParseElement* ifBody, ParseElement* whereBody)
{
	bool retVal = false; // Start pessimistic.
	if(causer != NULL && causee != NULL)
	{
		// Causer has to be an action formula, or the law is not properly written.
		if(causer->hasActions() && !causer->hasFluents())
		{
			// Causer and ifBody are going to end up together no matter what.
			SimpleBinaryOperator* tempPE = new SimpleBinaryOperator();
			tempPE->opType = SimpleBinaryOperator::BOP_AND;
			tempPE->preOp = causer;
			tempPE->postOp = ifBody;
			// Where causer and ifBody end up in the basic form depend on what's in causee.
			if(causee->hasActions() && !causee->hasFluents())
			{	// Causee is an action formula, this is "caused F if F & G & H".
				// Merge F into G & H.
				SimpleBinaryOperator* tempPE2 = new SimpleBinaryOperator();
				tempPE2->opType = SimpleBinaryOperator::BOP_AND;
				tempPE2->preOp = causee;
				tempPE2->postOp = tempPE;
				mainTrans.translateCausalLaw(causee, tempPE2, NULL, NULL, whereBody);
				retVal = true;
				deallocateTempBinaryOp(tempPE2);
			}
			else if(!causee->hasActions() && causee->hasFluents())
			{	// Causee is a fluent formula, this is "caused F if F after G & H".
				mainTrans.translateCausalLaw(causee, causee, tempPE, NULL, whereBody);
				retVal = true;
			}
			else
			{	// Causee is mixed, that isn't allowed.
				ltsyystartParseError(ltsyylloc);
				ltsyyossErr << "\"" << causee->fullName() << "\" must be a pure action formula or pure fluent formula in this law, it can't have both kinds of constants.";
				ltsyyreportError();
			}
			deallocateTempBinaryOp(tempPE);
		}
		else
		{
			ltsyystartParseError(ltsyylloc);
			ltsyyossErr << "\"" << causer->fullName() << "\" is not an action formula, can't use it as G in a \"G may cause F\" style law.";
			ltsyyreportError();
		}
	}
	return retVal;
}

// Transforms a causal law of the form "G causes F [if H] [where J]." to basic form, then calls the translator on it.
bool handleCausesLaw(ParseElement* causer, ParseElement* causee, ParseElement* ifBody, ParseElement* whereBody)
{
	bool retVal = false; // Start pessimistic.
	if(causer != NULL && causee != NULL)
	{
		// Causer has to be an action formula, or the law is not properly written.
		if(causer->hasActions() && !causer->hasFluents())
		{
			// Causer and ifBody are going to end up together no matter what.
			SimpleBinaryOperator* tempPE = new SimpleBinaryOperator();
			tempPE->opType = SimpleBinaryOperator::BOP_AND;
			tempPE->preOp = causer;
			tempPE->postOp = ifBody;
			// Where causer and ifBody end up in the basic form depend on what's in causee.
			if((causee->hasActions() && !causee->hasFluents()) || causee->elemType == ParseElement::PELEM_OBJLIKE)
			{	// Causee is an action formula, this is "caused F if G".
				mainTrans.translateCausalLaw(causee, tempPE, NULL, NULL, whereBody);
				retVal = true;
			}
			else if(!causee->hasActions() && causee->hasFluents())
			{	// Causee is a fluent formula, this is "caused F after G".
				mainTrans.translateCausalLaw(causee, NULL, tempPE, NULL, whereBody);
				retVal = true;
			}
			else
			{	// Causee is mixed, that isn't allowed.
				ltsyystartParseError(ltsyylloc);
				ltsyyossErr << "\"" << causee->fullName() << "\" must be a pure action formula or pure fluent formula in this law, it can't have both kinds of constants.";
				ltsyyreportError();
			}
			deallocateTempBinaryOp(tempPE);
		}
		else
		{
			ltsyystartParseError(ltsyylloc);
			ltsyyossErr << "\"" << causer->fullName() << "\" is not an action formula, can't use it as G in a \"G causes F\" style law.";
			ltsyyreportError();
		}
	}
	return retVal;
}

// Transforms an increment law of the form "A increments B by N [if H] [where J]." to basic form, then calls the translator on it.
bool handleIncrementLaw(ParseElement* causer, ParseElement* causee, ParseElement* increment, ParseElement* ifBody, ParseElement* whereBody, bool isIncrement)
{
	SimpleBinaryOperator* inc_expr = NULL;
	SimpleBinaryOperator* negative_expr = NULL;
	VariableLikeElement* x_val = NULL;
	ObjectLikeElement* tempNegOnePE = NULL;
	SimpleBinaryOperator* tempPE = NULL;
	SimpleBinaryOperator* newCausee = NULL;
	Constant* constRef;
	bool retVal = false; // Start pessimistic.
	if(causer != NULL && causee != NULL)
	{
		// Causer has to be a single action, or the law is not properly written.
		if(causer->hasActions() && causer->elemType == ParseElement::PELEM_CONSTLIKE && !causer->hasFluents())
		{
			// Causer and ifBody are going to end up together no matter what.
			
			//define the expression of the increment variable, X_VAL
			inc_expr = new SimpleBinaryOperator();
			inc_expr->opType = SimpleBinaryOperator::BOP_EQ;
			
			x_val = new VariableLikeElement();
			x_val->baseName = "X_Value";
			x_val->varRef = NULL;
			inc_expr->preOp = x_val;
			
			if(isIncrement)
			{
				increment->parenBefore = true;
				increment->parenAfter = true;
				inc_expr->postOp = increment;
			}
			else //multiply by -1
			{
				negative_expr = new SimpleBinaryOperator();
				negative_expr->opType = SimpleBinaryOperator::BOP_TIMES;
				
				tempNegOnePE = new ObjectLikeElement();
				tempNegOnePE->baseName = "-1";
				//tempNegOnePE->objRef = mainTrans.getObjectLike("-1", 0);
				tempNegOnePE->objRef = NULL;
				tempNegOnePE->parenBefore = true;
				tempNegOnePE->parenAfter = true;
				increment->parenBefore = true;
				increment->parenAfter = true;
				negative_expr->preOp = tempNegOnePE;
				negative_expr->postOp = increment;
				inc_expr->postOp = negative_expr;
			}

			//add the expression to the whereBody
			SimpleBinaryOperator* tempWherePE = NULL;
			if(whereBody != NULL)
			{
				tempWherePE = new SimpleBinaryOperator();
				tempWherePE->opType = SimpleBinaryOperator::BOP_AND;
				whereBody->parenBefore = true;
				whereBody->parenAfter = true;
				tempWherePE->preOp = whereBody;
				tempWherePE->postOp = inc_expr;
			}
			else
			{
				tempWherePE = inc_expr;
			}
			
			tempPE = new SimpleBinaryOperator();
			tempPE->opType = SimpleBinaryOperator::BOP_AND;
			tempPE->preOp = causer;
			tempPE->postOp = ifBody;
			// Causee must be a single constant-like additive fluent or additive action.
			if(causee->elemType == ParseElement::PELEM_CONSTLIKE)
			{
				if(((ConstantLikeElement*)causee)->constRef->constType == Constant::CONST_ADDITIVEACTION || ((ConstantLikeElement*)causee)->constRef->constType == Constant::CONST_ADDITIVEFLUENT)
				{
					// Create contribution element.
					newCausee = new SimpleBinaryOperator();
					newCausee->opType = SimpleBinaryOperator::BOP_EQ;
					ConstantLikeElement* contrib = new ConstantLikeElement();
					std::string contrib_str("contribution");
					contrib->baseName = contrib_str;
					// To avoid a weird translation, temporarily create object-like versions of causer and causee and use those instead.
					ObjectLikeElement *tempCauser = createObjLikeFromConstLike((ConstantLikeElement*)causer);
					ObjectLikeElement *tempCausee = createObjLikeFromConstLike((ConstantLikeElement*)causee);
					contrib->params.push_back(tempCauser);
					contrib->params.push_back(tempCausee);
					constRef = mainTrans.getConstantLike(contrib_str,2);
					contrib->constRef = constRef;
					newCausee->preOp = contrib;
					newCausee->postOp = x_val;
					
					mainTrans.translateCausalLaw(newCausee, tempPE, NULL, NULL, tempWherePE);
					retVal = true;
					deallocateTempBinaryOp(newCausee);
					contrib->params.clear();
					deallocateItem(contrib);
					tempCauser->params.clear();
					deallocateItem(tempCauser);
					tempCausee->params.clear();
					deallocateItem(tempCausee);
				}
				else
				{
					ltsyystartParseError(ltsyylloc);
					ltsyyossErr << "\"" << causee->fullName() << "\" is not an additive constant, can't use it as B in a \"A increments B by N\" style law.";
					ltsyyreportError();
				}	
			}
			else
			{
				ltsyystartParseError(ltsyylloc);
				ltsyyossErr << "\"" << causer->fullName() << "\" is not a single additive constant, can't use it as B in a \"A increments B by N\" style law.";
				ltsyyreportError();
			}
			deallocateTempBinaryOp(tempWherePE);
			deallocateTempBinaryOp(tempPE);
		}
		else
		{
			ltsyystartParseError(ltsyylloc);
			ltsyyossErr << "\"" << causer->fullName() << "\" is not a single action, can't use it as A in a \"A increments B by N\" style law.";
			ltsyyreportError();
		}
	}
	return retVal;
}

// Wraps the given element in two new negation operators to create a "not not (...)" wrap.
SimpleUnaryOperator* createNotNot(ParseElement* elem)
{
	SimpleUnaryOperator* retVal = NULL;
	if(elem != NULL)
	{
		elem->parenBefore = true;
		elem->parenAfter = true;
		SimpleUnaryOperator* tempNotNot1 = new SimpleUnaryOperator();
		SimpleUnaryOperator* tempNotNot2 = new SimpleUnaryOperator();
		tempNotNot1->opType = SimpleUnaryOperator::UOP_NOT;
		tempNotNot1->postOp = elem;
		tempNotNot2->opType = SimpleUnaryOperator::UOP_NOT;
		tempNotNot2->postOp = tempNotNot1;
		retVal = tempNotNot2;
	}
	return retVal;
}

// Creates an object-like element that mirrors the contents of elem.
ObjectLikeElement* createObjLikeFromConstLike(ConstantLikeElement* elem)
{
	ObjectLikeElement* retVal = NULL;
	
	if(elem != NULL)
	{
		retVal = new ObjectLikeElement();
		retVal->baseName = elem->baseName;
		retVal->params = elem->params;
		retVal->objRef = NULL;
	}
	
	return retVal;
}

// Deallocates a "not not" wrapper such that the original ParseElement is not touched, and returns the original ParseElement object.
ParseElement* deallocateNotNot(SimpleUnaryOperator* uop)
{
	ParseElement* retVal = NULL;
	if(uop != NULL)
	{
		if(uop->postOp != NULL)
		{
			retVal = ((SimpleUnaryOperator*)(uop->postOp))->postOp;
			((SimpleUnaryOperator*)(uop->postOp))->postOp->parenBefore = false;
			((SimpleUnaryOperator*)(uop->postOp))->postOp->parenAfter = false;
			((SimpleUnaryOperator*)(uop->postOp))->postOp = NULL;
			delete uop->postOp;
			uop->postOp = NULL;
		}
		delete uop;
		uop = NULL;
	}
	return retVal;
}

// NULLs elem's preOp and postOp before deallocating so the sub-ParseElement objects don't get caught in the deallocation.
void deallocateTempBinaryOp(SimpleBinaryOperator* &elem)
{
	if(elem != NULL)
	{
		elem->preOp = NULL;
		elem->postOp = NULL;
		delete elem;
		elem = NULL;
	}
}

// NULLs elem's postOp before deallocating so the sub-ParseElement object doesn't get caught in the deallocation.
void deallocateTempUnaryOp(SimpleUnaryOperator* &elem)
{
	if(elem != NULL)
	{
		elem->postOp = NULL;
		delete elem;
		elem = NULL;
	}
}

// Adds a standard parsing caution header to ltsyyossErr.
void ltsyystartCaution(YYLTYPE cautionLoc)
{
	ltsyyossErr << "% Caution, ";
	if(ltsyyFileName != "")
	{
		ltsyyossErr << "File \"" << ltsyyFileName << "\", ";
	}
	ltsyyossErr << "Line #" << cautionLoc.first_line << "." << cautionLoc.first_column << ": ";
}

// Adds a standard (location-unaware) parsing caution header to ltsyyossErr.
void ltsyystartCaution()
{
	ltsyyossErr << "% Caution, ";
	if(ltsyyFileName != "")
	{
		ltsyyossErr << "File \"" << ltsyyFileName << "\"";
	}
	ltsyyossErr << ": ";
}

// Caution reporting function for the parser.
void ltsyycaution()
{
	if(ltsyyossErr.str() == "")
	{
		ltsyystartCaution(ltsyylloc);
		ltsyyossErr << "Using \"" << ltsyytext << "\" here may not be a good idea.";
	}
	mainTrans.error(ltsyyossErr, true);
	LTSYYRESETOSS;
}

// Adds a standard parsing warning header to ltsyyossErr.
void ltsyystartWarning(YYLTYPE warningLoc)
{
	ltsyyossErr << "% Warning, ";
	if(ltsyyFileName != "")
	{
		ltsyyossErr << "File \"" << ltsyyFileName << "\", ";
	}
	ltsyyossErr << "Line #" << warningLoc.first_line << "." << warningLoc.first_column << ": ";
}

// Adds a standard (location-unaware) parsing warning header to ltsyyossErr.
void ltsyystartWarning()
{
	ltsyyossErr << "% Warning, ";
	if(ltsyyFileName != "")
	{
		ltsyyossErr << "File \"" << ltsyyFileName << "\"";
	}
	ltsyyossErr << ": ";
}

// Warning reporting function for the parser.
void ltsyywarning()
{
	if(ltsyyossErr.str() == "")
	{
		ltsyystartWarning(ltsyylloc);
		ltsyyossErr << "Using \"" << ltsyytext << "\" here will probably break something.";
	}
	mainTrans.error(ltsyyossErr, true);
	LTSYYRESETOSS;
}

// Adds a standard parse error header to ltsyyossErr to make it easier to report errors in actions.
void ltsyystartParseError(YYLTYPE errLoc)
{
	ltsyyossErr << "% Parse Error, ";
	if(ltsyyFileName != "")
	{
		ltsyyossErr << "File \"" << ltsyyFileName << "\", ";
	}
	ltsyyossErr << "Line #" << errLoc.first_line << "." << errLoc.first_column << ": ";
}

// Adds a standard (location-unaware) parse error header to ltsyyossErr to make it easier to report errors in actions.
void ltsyystartParseError()
{
	ltsyyossErr << "% Parse Error, ";
	if(ltsyyFileName != "")
	{
		ltsyyossErr << "File \"" << ltsyyFileName << "\"";
	}
	ltsyyossErr << ": ";
}

// Adds a standard syntax error header to ltsyyossErr to make it easier to report errors in actions.
void ltsyystartSyntaxError(YYLTYPE errLoc)
{
	ltsyyossErr << "% Syntax Error, ";
	if(ltsyyFileName != "")
	{
		ltsyyossErr << "File \"" << ltsyyFileName << "\", ";
	}
	ltsyyossErr << "Line #" << errLoc.first_line << "." << errLoc.first_column << ": ";
}

// Adds a standard (location-unaware) syntax error header to ltsyyossErr to make it easier to report errors in actions.
void ltsyystartSyntaxError()
{
	ltsyyossErr << "% Syntax Error, ";
	if(ltsyyFileName != "")
	{
		ltsyyossErr << "File \"" << ltsyyFileName << "\"";
	}
	ltsyyossErr << ": ";
}

// Error reporting function for the bison parser.
void ltsyyerror(char const* msg)
{
	if(ltsyyossErr.str() == "")
	{
		ltsyystartSyntaxError(ltsyylloc);
		ltsyyossErr << "Unexpected token \"" << ltsyytext << "\".";
	}
	mainTrans.error(ltsyyossErr, true);
	LTSYYRESETOSS;
	// If the translator's temporary query appears to have been partially populated, destroy it and create another in its place.
	if(mainTrans.tempQuery != NULL && (mainTrans.tempQuery->label != "" || mainTrans.tempQuery->maxstep != "" || !(mainTrans.tempQuery->queryConditions.empty())))
	{
		mainTrans.allocateNewTempQuery(true);
	}
	if(mainTrans.tempQuery == NULL)
	{
		mainTrans.allocateNewTempQuery();
	}
}

// Wraps caution reporting for convenience and unification with convention for error reporting.
void ltsyyreportCaution()
{
	ltsyycaution();
}
// Wraps warning reporting for convenience and unification with convention for error reporting.
void ltsyyreportWarning()
{
	ltsyywarning();
}
// Wraps error reporting for ease and to ensure the number of errors gets incremented with each (action-generated) error report.
void ltsyyreportError()
{
	ltsyynerrs++;
	ltsyyerror("");
}

