#include "ASPCode.h"

// Default constructor.
ASPCode::ASPCode() : Comment()
{
	// ASP code isn't a "real" comment, it's just raw text.
	isRealComment = false;
}

// Assignment operator overload.
ASPCode& ASPCode::operator=(const ASPCode &rhs)
{
	// Skip self-assignment.
	if(this != &rhs)
	{
		this->contents = rhs.contents;
		this->fileName = rhs.fileName;
		this->loc = rhs.loc;
		this->isRealComment = rhs.isRealComment;
	}
	return *this;
}

// Destructor.
ASPCode::~ASPCode()
{
	// Nothing to do, intentionally empty.
}
