xacml2asp
========

This file provides general instructions on how to use the system xacml2asp.

- Directory structure
  /Examples - Example policies written in XACML syntax, can be used as the input of the translator
  /Translator - The translator which convert XACML policies to ASP facts, as an executable Java program
  /pdp.txt - The PDP simulation program

- Dependencies
  * Clingo 3.x (LUA support required)
     Files, instructions and documentations can be found in
                   http://potassco.sourceforge.net/

  * F2lp 1.3
     Files, instructions and documentations can be found in
                   http://reasoning.eas.asu.edu/f2lp/

  * Java
     Latest version can be found in
                   https://www.java.com
   

- Usage
  * Translator
     Make sure Java is installed. In the translator folder, copy XACML descriptions of policies to the folder "policies". Then return to the translator folder and execute "xacml3translator.jar". There will be a file "out.txt" generated, where ASP facts that define the policies can be found. 
     Note that for F2lp to process the content of the file, "#begin_asp" and "#end_asp." have to be added to the beginning and end of the file, respectively. 

  * PDP simulation program
     Make sure Clingo and F2lp are installed. Copy the file pdp.txt and the file containing ASP facts that define the policies to the same folder. Create a text file in the same folder and define access request by enumarating each attribute contained in the request in the following form

                   request(rq, "attribute category", "attribute id", "attribute issuer", "attribute data type", "attribute value").

     Add "#begin_asp" and "#end_asp." to the beginning and end of the file, respectively.
     For example,

                   % request.txt
                   #begin_asp
                   request(rq, "subject-id", "access-subject", null, "string", "John").
                   request(rq, "resource-id", "resource", null, "string", "record").
                   request(rq, "action-id", "action", null, "string", "read").
                   #end_asp.

     defines the access request that John wants to read the record.

     Execute f2lp, taking the file containing policy description as ASP facts, the PDP simulation program, and the request as input, and then feed the output to clingo.
     For example, suppose the above files are named "policies.txt", "pdp.txt", "request.txt", respectively. The commandline should be

                   f2lp policies.txt PDP.lp request.txt | clingo -n 0

     The result will show the final decision from PDP regarding the access request in the following form

                   final_decision(DECISION)

     The system can be used for other purpose such as policy loophole detection. See

                   http://reasoning.eas.asu.edu/xacml2asp/tutorial.html

     for details.
