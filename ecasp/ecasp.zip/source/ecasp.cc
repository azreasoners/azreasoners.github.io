/* 
  *File: ecasp.cc
  *Last Updated on 3/29/09
  *By Tae-Won Kim

  *Turn an event calculus description in the input language
   of the DEC reasoner to a logic program.
*/

#include <iostream>
#include <cstdlib>
#include <string> 
#include <fstream>
#include <cctype>  
#include <sstream>
#include <time.h>

using namespace std;


#define FORM_COL 300      // Maximum number of characters in a Formula
#define NUM_SORTS 20      
#define NUM_SUB_SORTS 10
#define NUM_SUB_SORT_RULES 30
#define NUM_SUB_SORT_INTEGER 20
#define NUM_EVENT_TERMS 2
#define NUM_CONSTANTS 20
#define NUM_CONST_OBJECTS 30
#define NUM_FLUENTS 20
#define NUM_EVENTS 20
//#define NUM_PREDICATES 20
#define RANGE_COL 20      // Maximum number of characters in Range statement
#define NUM_VARS 20
#define NUM_ALL_VARS 1000 
#define NUM_TOKENS_FORM 50 //30
#define NUM_CHILDNODES 40
#define NUM_ANCESTORS 20
#define NUM_SUB_FORMS 20
#define NUM_SUB_TREES 2
#define NUM_NEWPRE_FORMS 50
#define NUM_FINAL_FORMS 100
#define NUM_RULES 200

struct Sort
{
  string sName;
  string subSorts[NUM_SUB_SORTS];
  int num;
};

Sort sorts[NUM_SORTS];
int sortRow=0;
int indexOfSort;

string subSortRules[NUM_SUB_SORT_RULES];
int subSortRow=0;

string subSortOfInteger[NUM_SUB_SORT_INTEGER];
int subSortInt=0;

struct Const
{
  string sName; // sort name
  string objects[NUM_CONST_OBJECTS];
  int num;      // number of objects
};

Const constants[NUM_CONSTANTS];
int constRow=0;
string sortNameOfConst("");

struct Fluent
{
  string pName; 
  string srts[NUM_SORTS];
  int num;      // number of sorts
};

Fluent fluents[NUM_FLUENTS];
int fluentRow=0;

string declarationOfFluents[NUM_FLUENTS];
int decFluentRow=0;

struct Event
{
  string pName; 
  string srts[NUM_SORTS];
  int num;      // number of sorts
};

Event events[NUM_EVENTS];
int eventRow=0;

string declarationOfEvents[NUM_EVENTS];
int decEventRow=0;

/*
struct Predicate
{
  string pName; 
  string srts[NUM_SORTS];
  int num;      // number of sorts
};

Predicate predicates[NUM_PREDICATES];
int predicateRow=0; */

//string declarationOfPredicates[NUM_PREDICATES];
//int decPredicateRow=0;

string rangeForm[RANGE_COL];
int rangeCol=0;

string variables[NUM_VARS];
int varsRow=0;

// #domain for each variable
string allVars[NUM_ALL_VARS];
int allVarsRow=0;

string tempVars[NUM_VARS];
int tempVarsRow=0;

string tokenOfForm[NUM_TOKENS_FORM]; 
int ntokensOfForm=0;

string subForms[NUM_SUB_FORMS];
int nOfsubForms=0;

string subForms2[NUM_SUB_FORMS];
int nOfsubForms2=0;

string subForms3[NUM_SUB_FORMS];
int nOfsubForms3=0;

string subTrees[NUM_SUB_TREES];

string newPredicatesForms[NUM_NEWPRE_FORMS];
int nOfnewPreForms=0;

string finalForms[NUM_FINAL_FORMS];
int numberOfForms=0;

string rules[NUM_RULES];
int ruleRow=0;

string Initiates = "Initiates";
string Terminates = "Terminates";
string Releases = "Releases";
string HoldsAt = "HoldsAt";
string ReleasedAt = "ReleasedAt";
string Happens = "Happens";
string Happens3= "Happens3";
string Trajectory = "Trajectory";
string AntiTrajectory = "AntiTrajectory";
string StoppedIn = "StoppedIn";
string StartedIn = "StartedIn";
string Clipped = "Clipped";
string Started = "Started";
string Stopped = "Stopped";
string Initiated = "Initiated";
string Terminated = "Terminated";
string hide = "hide.";
string show = "show holdsAt(F,T), happens(E,T), happens3(E,T,T2).";
string domain("");
bool different=false;
int newPreNum=1;
string newPre="newPre"; // New predicates
string rform("");
string rform2("");
string maxOfTimepoint("");
bool flag_completion=false;
bool first=true;
int start;
bool noRightChild=false;
bool notApplyC1andC2=false;
int rangeMaxTime=0;
int rangeMinTime=0;
int rangeMaxOffset=0;
int rangeMinOffset=0;


struct stack
{
  int top;
  char item[30];
};

struct node 
{
  struct node *left;
  struct node *right;
  struct node *parent;
  string str;
};

typedef struct node *nodePtr;
nodePtr root=NULL;

nodePtr ancestors[NUM_ANCESTORS];
int nOfancestors=0;

nodePtr childNodes[NUM_CHILDNODES];
int nOfchildNodes=0;


///////// Function prototypes
void usage();
void initializeSorts();
int loadComment(string aLine);
int loadOption(string aLine);
string split(string &str, string delimiter);
int loadLoad(string aLine);
int loadSort(string aLine);
int isSort(string token);
int loadConstant(string aLine);
int existSortName(string token);
int findIndexOfConst(string sN);
int isConstant(string token);
int isNumber(string target);
int loadFluent(string aLine);
int isPredicate(string token);
bool existVars(string target);
string integerToString(int i);
int loadEvent(string aLine);
//int loadPredicate(string aLine);  // need to be completed
int loadCompletion(string aLine);
int loadRange(string aLine);
int isSubsortOfInteger(string s);
int stringToInteger(string number);
int endFormula(string aLine);
void checkParsError(string form); // need to be completed
void giveParsError(string form);
void trimSpace(string& aLine);
void changeSym(string& form);
void checkBiImpl(string& form);
void makeTree(string form);
void markTupleEnd(string& form);
void freshTokensOfForm();
void infixToPrefix(char *input, char *output);
int isNegation(char *input, int i);
void push(struct stack *ps, char n);
void pop(struct stack *ps);
int isempty(struct stack *ps);
int prcd(char stktop, char op);
int full(struct stack *ps);
void getTokensOfForm(char *prefix);
nodePtr prefixToTree();
bool existentialQuan(string eq);
bool isVariable(string var);
bool universalQuan(string eq);
void returnInfixForm(nodePtr tree);
nodePtr searchNode(nodePtr tree, string target);
void applyC1(string form);
void eliminateDisjunction(nodePtr tree);
void getAncestorsWithNegOrExistQuan(nodePtr child);
void applyC2(string form);
void eliminateConjunction(nodePtr tree);
void displayTree(nodePtr tree);
void moveExistentialQuan(nodePtr tree);
void returnInfixForm2(nodePtr tree);
void checkFreeVars(); // need to be checked
void getChildNodes(nodePtr tree);
void getAncestorsWithQuan(nodePtr child);
string eliminatePosQuan(string form, char open, char close);
void areDifferentVars();
string removeQuan(string form, char open, char close);
string renameVar(string form, string var, int varFound);
string removeExtraParentheses(string& form);
string converToLP(string form);
void handleHead(string& form);
void convertSyms(string& form);
string eliminateNegExstQuan(string form, int existQuanStart);
int getVariables(string form,char open,char close,int QuanStart);
void freshTempVars();
int findLimit(string form, int index);
void handleNewPredicateForms();
void freshVars();
void freshSubforms();
void freshSubforms2();
void freshSubforms3();
void setUpDomainPredicates();

           
int main(int argc, char *argv[])
{
  int len=0;
  string line("");
  string formula;  
  string intermediateFileName("");

  // Check the number of arguments
  if(argc !=  2)
  {
    usage();
    exit(EXIT_FAILURE);
  }
                                         
  ifstream inFile (argv[1]);               
  if (!inFile.is_open())                     
    {
      cout << "Unable to open " << argv[1] << endl;
      exit(EXIT_FAILURE);
    }
  
  else // Check the file extension (name)
    if(strstr(argv[1], ".e")==NULL)
      {
	cout << "The file is not applicable.\n" << endl;
	exit(EXIT_FAILURE);
      }
 
  initializeSorts(); // Add sort time and offset as default

  while(!inFile.eof())
  {
    getline(inFile, line);
    len = line.length();

    // The line is a new line
    if(len==0)
      continue;
    
    // The line is for a comment
    if(loadComment(line))
      continue;
	
    // The line is for an option
    if(loadOption(line))
      continue;

    // The line is for load 
    if(loadLoad(line))
      continue;
	
    // The line is for sort
    if(loadSort(line))
      continue;

    // The line is for constant
    if(loadConstant(line))
      continue;

    // The line is for fluent
    if(loadFluent(line))
      continue;
	
    // The line is for event
    if(loadEvent(line))
      continue;

    // The line is for predicate
    //    if(loadPredicate(line))
    //  continue;   

    // The line is for completion
    if(loadCompletion(line))
    {
      flag_completion=true;
      continue;
    }
      
    // The line is for range
    if(loadRange(line))
      continue;

    // The line is for formula       
    formula="";
    formula.append(line);
	
    while(!endFormula(formula) & !inFile.eof())
    {  
      getline(inFile, line);

      if(line.length()==0) // new line
	continue;

      if(loadComment(line))
	continue;

      if(loadLoad(line)       || loadSort(line) ||
	 loadConstant(line)   || loadFluent(line) ||
	 loadEvent(line)      || //loadPredicate(line) ||
         loadCompletion(line) || loadRange(line))
	 {
	   cout << "\nERROR: unable to parse formulas '" 
		<< formula << "'" << endl;
	   exit(EXIT_FAILURE);
	 }

      formula.append(1, ' ');
      formula.append(line);
    }
	
    
    if(!endFormula(formula))
    {
      cout << "\nERROR: unable to parse formulas '" 
	   << formula << "'" << endl;
      exit(EXIT_FAILURE);
    }
    
    //checkParsError(formula);
    // Erase '.' in a formula
    trimSpace(formula);
    formula.erase(formula.length()-1,1);   
    changeSym(formula);
   
    checkBiImpl(formula);

    for(int r=0; r<nOfsubForms3; r++)
    {
      applyC1(subForms3[r]);

      for(int p=0; p<nOfsubForms; p++) 
	applyC2(subForms[p]);

      for(int q=0; q<nOfsubForms2; q++)
      {
	makeTree(subForms2[q]);
	moveExistentialQuan(root);

	// Check free variables in a formula
	//	checkFreeVars(); //later

	string formQuan("");
	if(!noRightChild)
	  {formQuan=rform; rform="";}
	else
	  {formQuan=rform2; rform2="";
	  noRightChild=false;}

	int existQuanStart=formQuan.find_first_of("{", 0);
	while(existQuanStart>=0)
	{
	  if( existQuanStart==0 || 
	      (existQuanStart!=0 && formQuan[existQuanStart-1]!='!'))
	  {
	      /* Eliminate maximal positive occurrence of
		 existential quantification in the antecedent
		 of a formula 
	      */       
	      formQuan=eliminatePosQuan(formQuan, '{', '}');
	  }
	  else
          {
	    /* Eliminate maximal negative occurrence of
	       existential quantification in the antecedent
	       of a formula
	    */
	    formQuan=eliminateNegExstQuan(formQuan, existQuanStart);

	    handleNewPredicateForms();
	    // Do applyC1, Remove existential quantification,
	    // and then, Write in LP
	  }

	  existQuanStart=formQuan.find_first_of("{", 0);
	}
     
	// Eliminate universal quantification
	formQuan=eliminatePosQuan(formQuan, '[', ']');

	/* Remove extra parentheses in a formula
	   and convert into A.S.P. */
	finalForms[numberOfForms++]
	  = converToLP(removeExtraParentheses(formQuan));
      } // end of for loop after applyC2

      //rform="";
      freshVars();
      freshSubforms();
      freshSubforms2();
    } 

    freshSubforms3();
  } // end of 'while' loop

      inFile.close();

      //         for (int f=0; f<numberOfForms; f++)
      //      cout << endl << finalForms[f] << endl;

      cout << endl;
     


      // Add domain predicates for variables
      setUpDomainPredicates();
      rules[ruleRow++]=domain;

      // Add New Lines
      rules[ruleRow++]="\n\n";

      // Add range of sorts that are subsorts of integer
      for(int i=0; i<rangeCol; i++)
      {
	rules[ruleRow++]=rangeForm[i];
	rules[ruleRow++]="\n";
      }

      // Add a New Line
      rules[ruleRow++]="\n";

      // Add Constants 
      for(int j=0; j<constRow; j++)
      {
	for(int k=0; k<constants[j].num; k++)
	{
	  string obj=constants[j].objects[k];
	  string srtName=constants[j].sName;
	  //$ srtName[0]=tolower(srtName[0]);
	  obj[0]=tolower(obj[0]);
	  rules[ruleRow++]=srtName+"("+obj+").";
	  rules[ruleRow++]="\n";
	}
      }

      // Add a New Line
      rules[ruleRow++]="\n";

      // Add Subsort relationship if applicable
      for(int r=0; r<subSortRow; r++)
	rules[ruleRow++]=subSortRules[r];


      // Add a New Line
      rules[ruleRow++]="\n";


      // Add Fluents
      for(int l=0; l<decFluentRow; l++)
      {	
	rules[ruleRow++]=declarationOfFluents[l];
	rules[ruleRow++]="\n";
      }

      // Add a New Line
      rules[ruleRow++]="\n";


      // Add Events
      for(int m=0; m<decEventRow; m++)
      {	
	rules[ruleRow++]=declarationOfEvents[m];
	rules[ruleRow++]="\n";
      }

      // Add New Lines
      rules[ruleRow++]="\n";

      /*
      // Add Predicates
      for(int m=0; m<decPredicateRow; m++)
      {	
	rules[ruleRow++]=declarationOfPredicates[m];
	rules[ruleRow++]="\n";
      }*/

      // Add New Lines
      rules[ruleRow++]="\n\n";


      // Add formulas transferred
      for(int n=0; n<numberOfForms; n++)
      {
	rules[ruleRow++]=finalForms[n];
	rules[ruleRow++]="\n";
	rules[ruleRow++]="\n";
      }


      // For fluents and events that do not include
      // any arguments
      for(int s=0; s<ruleRow; s++)
      {
	string r=rules[s];
	int len=r.length();

	for(int e=0; e<len; e++)
	{
	  if(e<len-2)
	    if(r[e]=='(' && r[e+1]==')')
            {
	      r.replace(e, 2, "");
	      len=len-2;
	    }
	  rules[s]=r;
	}
      }
      
      
      // Add a choice rule for happens predicate
      if(!flag_completion)
      {
	string cHappens="0 {happens(E, T)} 1 :- T<maxstep.";
        rules[ruleRow++]=cHappens;
        rules[ruleRow++]="\n\n";
        rules[ruleRow++]="\n\n";
      }


      // Add 'hide' declaration
      rules[ruleRow++]=hide;
      rules[ruleRow++]="\n\n";


      // Add 'show' declaration
      rules[ruleRow++]=show;
      rules[ruleRow++]="\n";


      // Write on a file
      ofstream outputFile;
      intermediateFileName=argv[1];
      intermediateFileName.replace(intermediateFileName.length()-2,3,".lp");
      outputFile.open(intermediateFileName.c_str());

       for(int p=0; p<ruleRow; p++)
	 outputFile << rules[p];

      outputFile.close();

      

      cout << "The translated file '" << intermediateFileName 
	   << "' is created." << endl;
      cout << "The Maximum Timepoint is " << maxOfTimepoint << endl << endl;

  return 0;
}
//////////////  END OF MAIN /////////////////////////////
void usage()
{
  cout << "Usage: ecasp <filename>" << endl;
  cout << endl;
}

void initializeSorts()
{
  sorts[sortRow++].sName="fluent";           
  subSortOfInteger[subSortInt++]="fluent";   
  sorts[sortRow++].sName="event";           
  subSortOfInteger[subSortInt++]="event";   
  sorts[sortRow++].sName="time";           //$ "Time"
  subSortOfInteger[subSortInt++]="time";   //$ "Time"
  sorts[sortRow++].sName="offset";         //$ "Offset"
  subSortOfInteger[subSortInt++]="offset"; //$ "Offset
}

int loadComment (string aLine)
{
  int len=aLine.length();
  for(int i=0; i<len; i++)
    if(aLine[i]==' ')
      continue;
    else
      if(aLine[i]==';')     
	return 1;
     
  return 0;
}

int loadOption (string aLine)
{
  string copyALine=aLine;
  string option="option";
  int numOfToken=0;
  string orgLine=aLine;
  string token = split(aLine, " ");
  int key=-1;
  int error=0;

  while(token.compare("")!=0)
  {
    numOfToken++;
    
    if(numOfToken==1)
      if(token.compare(option)!=0)
	return 0;
  
    // ##  option statements except for finalstatefile and weighted
    if(numOfToken==2)
    {
      if(token.compare("debug")==0 ||
	 token.compare("manualrelease")==0 ||
	 token.compare("modeldiff")==0 ||
	 token.compare("renaming")==0 ||
	 token.compare("showpred")==0 ||
	 token.compare("timediff")==0 ||
	 token.compare("tmpfilerm")==0 ||
	 token.compare("trajectory")==0)
	key=1;
      else if(token.compare("encoding")==0)
	key=2; // The value of this option will be 2 or 3
      else if(token.compare("solver")==0)
	key=3; // relsat, walksat, minisat, and maxwalksat
      else
      {
	cout << "ERROR: unknown option in '" 
             << orgLine << "'" << endl << endl;
         exit(EXIT_FAILURE);
      }
    }
  
    if(numOfToken==3)
    {
      switch(key){
      case 1: if(token.compare("on")!=0 &&
                 token.compare("off")!=0)
	error=1; break;
      case 2: if(stringToInteger(token)!=2 && 
                 stringToInteger(token)!=3)
	error=1; break;
      case 3: if(token.compare("relsat")!=0 &&
                 token.compare("walksat")!=0 &&
                 token.compare("minisat")!=0 &&
                 token.compare("maxwalksat")!=0)
	error=2; break;
      }
    }

    token = split(aLine, " ");
  } // end of while loop

  if(error==1)
  {
         cout << "ERROR: invalid value in '"
	      << orgLine << "'" << endl << endl;
         exit(EXIT_FAILURE);
  }
  else if(error==2)
  {
         cout << "ERROR: unknown solver in '"
	      << orgLine << "'" << endl << endl;
         exit(EXIT_FAILURE);
  }
  else
    return 1;
}

string split(string &str, string delimiter)
{
  string token("");

  int index=str.find_first_of(delimiter, 0);
  if(index>=0)
  {
    if(index==0)
      return split(str.erase(0,1), delimiter);

    token=str.substr(0,index);
    str.erase(0,index+1);
    return token;
  }
  else
  {token=str; str=""; return token;} // Last element
}

int loadLoad (string aLine)
{
  string copyALine=aLine;
  string load="load";
  string ec="foundations/EC.e";
  string dec="foundations/DEC.e";
  string root="foundations/Root.e";
  string eccausal="foundations/ECCausal.e";
  int numOfToken=0;
  string token = split(aLine, " ");
  string temp=aLine;
  string error("");

  while(token.compare("")!=0)
  {
    numOfToken++;
    
    if(numOfToken==1)
      if(token.compare(load)!=0)
	return 0;

    if( (numOfToken==2 && token.compare(dec)!=0 && 
         token.compare(ec)!=0 && token.compare(root)!=0 &&
	 token.compare(eccausal)!=0)
        || (numOfToken==3) )
    {
      if(numOfToken==3)
	error=temp.substr(5);
      else
	error=token;
      
      cout << "ERROR: No such file or directory: '"
	   << copyALine << "'" << endl << endl;
      exit(EXIT_FAILURE);
    }

    token = split(aLine, " ");

  } // end of while loop


  if(numOfToken==0) // Line is a space
    return 0;
  else if(numOfToken==1) // Only exists 'load' keyword in Line
    {
      cout << "ERROR: No file to load" << endl << endl;
      exit(EXIT_FAILURE);
    }
  else
    return 1;
}

int loadSort (string aLine)
{
  string sort = "sort";
  string subsort="", token="";
  int numOfToken=0;
  int number=0;

  bool flag_subsort=false;
  int i=aLine.find(":",0);
  if(i>0 && i<aLine.length())
    flag_subsort=true;

  if(flag_subsort)
    token = split(aLine, " :");
  else
    token = split(aLine, " ,");

  while(token.compare("")!=0)
  {
    numOfToken++;

    if(numOfToken==1)
      if(token.compare(sort)!=0)
	return 0;

    if( numOfToken==2 || 
       (numOfToken>=3 && !flag_subsort)) // Gets sort name
      if(!isSort(token))
      {
	cout << "ERROR: Invalid sort name '" 
             << token << "'" << endl << endl;
	exit(EXIT_FAILURE);
      }
      else // Adds a token to sorts
      {
	if(existSortName(token))
	{
	  cout << "ERROR: Sort name '" << token << 
	    "' has been already declared." << endl << endl;
	  exit(EXIT_FAILURE);
	}

	subsort=token;
	sorts[sortRow++].sName=token;
	constants[constRow++].sName=token;
      }

    if(numOfToken==3 && flag_subsort)
    {
      if(token.compare("integer")==0)
	subSortOfInteger[subSortInt++]=subsort;      
      else if(existSortName(token))
      {
	number=sorts[indexOfSort].num;
	sorts[indexOfSort].subSorts[number++]=subsort;
	sorts[indexOfSort].num=number;
	subSortRules[subSortRow++]
	=token+"("+"V"+")"+" :- "+subsort+"("+"V"+").";
      }      
      else
      {
	cout << "ERROR: Invalid sort name '" 
             << token << "'" << endl << endl;
	exit(EXIT_FAILURE);
      }
    }
    
    if(flag_subsort)
      token = split(aLine, " :");
    else
      token = split(aLine, " ,");
  }

  if(numOfToken==0) // Line is a space
    return 0;
  else if(numOfToken==1 || (flag_subsort && numOfToken!=3))
    {
      cout << "ERROR: sort declaration" 
           << endl << endl;
      exit(EXIT_FAILURE);
    }
  else
    return 1;
}

int isSort(string token)
{
  for(int i=0; i<token.length(); i++)
  { 
    if(!islower(token[0])) //$ !isupper(token[0]))
       return 0;
    if(!isalpha(token[i]))
       return 0;
  } 
  return 1;
}

int loadConstant(string aLine)
{
  int numOfToken=0;
  string token = split(aLine, " ,");
  int index=0;
  int number=0;


  while(token.compare("") != 0)
  {
    numOfToken++;

    if(numOfToken==1)
    {
      if(token.compare("fluent")==0 ||
         token.compare("event")==0)
	return 0;
      if(!existSortName(token))
	return 0;
      else
	index=findIndexOfConst(token);
    }
    if(numOfToken>1)
      if(!isConstant(token))
      {                    
	cout << "ERROR: Invalid constant name '" 
	     << token << "'" << endl << endl;
	exit(EXIT_FAILURE);
      }
      else
      { 
	number=constants[index].num;
	constants[index].objects[number++]=token;
	constants[index].num=number;
      }
   
    token = split(aLine, " ,");
  }

  if(numOfToken==0) // Line is a space
    return 0;
  else if(numOfToken==1) // Only exists sort name in Line
    {
      cout << "ERROR: no constant" << endl << endl;
      exit(EXIT_FAILURE);
    }
  else      
    return 1;
}

int existSortName(string token)
{
  indexOfSort=-1;

  for(int i=0; i<sortRow; i++)
    if(sorts[i].sName.compare(token)==0) //sorts[i].compare(token)==0)
    {
      indexOfSort=i;
      return 1;
    }

  return 0;
}

int findIndexOfConst(string sN)
{
  if(constRow==0)
    return 0;

  for(int i=0; i<constRow; i++)
    if(constants[i].sName.compare(sN)==0)
      return i; 
}

int isConstant(string token)
{
// A constant consists of one or more digits
// or an lowercase letter followed by zero or 
// more letters or digits
  if(isNumber(token))
    return 1;
  else
  {  for(int i=0; i<token.length(); i++)
      { 
	if(!isupper(token[0])) //$ islower....
	  return 0;
	if(!isalnum(token[i]))
	  return 0;
      }
  } 
  return 1;
}

int isNumber (string target)
{
  int len=target.length();
  if(len==0)
    return 0;

  int start=0;

  if(target[0]=='-')
    start=1;

  for(int i=start; i<len; i++)
    if(!isdigit(target[i]))
      return 0;
  return 1;
}

int loadFluent(string aLine)
{
  int leftParen=0;
  for(int i=0; i<aLine.length(); i++)
    if(aLine[i]=='(')
      leftParen++;
   
  string fluent = "fluent";
  int numOfToken=0;
  string token = split(aLine, " (,)");
  int number=0;
  string predicateName("");
  string fstr("");

  while(token.compare("")!=0)
  {
    numOfToken++;

    if(numOfToken==1)
      if(token.compare(fluent)!=0)
	return 0; 

    //## ERROR: trouble parsing for reification.

    if(numOfToken==2) // for predicatesymbol
      if(!isPredicate(token))
	{
	  cout << "ERROR: Invalid fluent symbol name '" 
               << token << "'" << endl << endl;
	  exit(EXIT_FAILURE);
	}
      else
      {
	fluents[fluentRow].pName=token;
	predicateName=token;
      }

    if(numOfToken>2) // for arguments
      if(!existSortName(token))
      {
	cout << "ERROR: Undefined sort name '" 
             << token << "'" << endl << endl;
	exit(EXIT_FAILURE);
      }
      else
	fluents[fluentRow].srts[number++]=token;

    token = split(aLine, " (,)");

  } // end of while

  if(numOfToken==0) // Line is a space
    return 0;
  else if(numOfToken==1) // Only exists 'fluent' keyword in Line
  {
      cout << "ERROR: No fluent" << endl << endl;
      exit(EXIT_FAILURE);
  }
  else 
  {
    fluents[fluentRow].num=number;
    string f="fluent(";
    predicateName[0]=tolower(predicateName[0]);
    //$   predicateName[0]=tolower(predicateName[0]);
    f=f+predicateName+"(";

    string temp("");
    for(int j=0; j<number; j++)
    {
      fstr=fluents[fluentRow].srts[j];
      if(fstr.compare(temp)==0)
	fstr=fstr+integerToString(j);
      
      temp=fstr;
      fstr[0]=toupper(fstr[0]);
      //$ fstr[0]=toupper(fstr[0]);
      
      if(!existVars(fstr))
	allVars[allVarsRow++]=fstr; 
      
      f=f+fstr;
      
      if(j+1<number)
	f=f+",";
    }

    f=f+")).";

    declarationOfFluents[decFluentRow++]=f;
    fluentRow++;
    return 1;
  }
}

int isPredicate(string token)
{
  // predicatesymbols consist of an uppercase letter  
  // followed by zero or more letters or digits
  for(int i=0; i<token.length(); i++)
  { 
    if(!isupper(token[0]))  
       return 0;
    if(!isalnum(token[i]))
       return 0;
  } 
  return 1;
}

bool existVars(string target)
{
  if(allVarsRow==0)
    return false;

  else
  {
    for(int i=0; i<allVarsRow; i++)
      if(target.compare(allVars[i])==0)
	return true;
  }

  return false;
}

string integerToString(int i)
{
  string s;
  stringstream out;
  out << i;
  s=out.str();
  return s;
}

int loadEvent(string aLine)
{
  int leftParen=0;
  for(int i=0; i<aLine.length(); i++)
    if(aLine[i]=='(')
      leftParen++;
   
  string event = "event";
  int numOfToken=0;
  string token = split(aLine, " (,)");
  int number=0;
  string predicateName("");
  string estr("");

  while(token.compare("")!=0)
  {
    numOfToken++;

    if(numOfToken==1)
      if(token.compare(event)!=0)
	return 0;
    
    //## ERROR: trouble parsing for reification.

    if(numOfToken==2) // for predicatesymbol
      if(!isPredicate(token))
	{
	  cout << "ERROR: Invalid event symbol name '" 
               << token << "'" << endl << endl;
	  exit(EXIT_FAILURE);
	}
      else
      {
	events[eventRow].pName=token;
	predicateName=token;
      }

    if(numOfToken>2) // for arguments
      if(!existSortName(token))
	{
	  cout << "ERROR: Undefined sort name '" 
               << token << "'" << endl << endl;
	  exit(EXIT_FAILURE);
	}
      else
	events[eventRow].srts[number++]=token;

    token = split(aLine, " (,)");

  } // end of while

  if(numOfToken==0) // Line is a space
    return 0;
  else if(numOfToken==1) // Only exists 'event' keyword in Line
  {
      cout << "ERROR: No event" << endl << endl;
      exit(EXIT_FAILURE);
  }
  else 
  {
    events[eventRow].num=number;
    string e="event(";
    predicateName[0]=tolower(predicateName[0]);
    //$ predicateName[0]=tolower(predicateName[0]);
    e=e+predicateName+"(";
  
    string temp("");
    for(int j=0; j<number; j++)
    {
      estr=events[eventRow].srts[j];
      if(estr.compare(temp)==0)
	estr=estr+integerToString(j);

      temp=estr;
      estr[0]=toupper(estr[0]);
      //$ estr[0]=toupper(estr[0]);

      if(!existVars(estr))
	allVars[allVarsRow++]=estr;
      
      e=e+estr;
   
      if(j+1<number)
	e=e+",";
    }

    e=e+")).";
   
    declarationOfEvents[decEventRow++]=e;
    eventRow++;
    return 1;
  }
}
  
/*
int loadPredicate(string aLine)
{
  int leftParen=0;
  for(int i=0; i<aLine.length(); i++)
    if(aLine[i]=='(')
      leftParen++;
   
  string predicate = "predicate";
  int numOfToken=0;
  string token = split(aLine, " (,)");
  int number=0;
  string predicateName("");
  string prestr("");

  while(token.compare("")!=0)
  {
    numOfToken++;

    if(numOfToken==1)
      if(token.compare(predicate)!=0)
	return 0;
	//if(leftParen>=2)
	//{
	//cout << "Error: trouble parsing for reification." 
	//  << endl << endl;
	//exit(EXIT_FAILURE);
	// }  // is it necessary??

    if(numOfToken==2) // for predicatesymbol
      if(!isPredicate(token))
	{
	  cout << "ERROR: Invalid predicate symbol name '" 
               << token << "'" << endl << endl;
	  exit(EXIT_FAILURE);
	}
      else
      {
	predicates[predicateRow].pName=token;
	predicateName=token;
      }

    if(numOfToken>2) // for arguments
      if(!existSortName(token))
	{
	  cout << "ERROR: Undefined sort name '" 
               << token << "'" << endl << endl;
	  exit(EXIT_FAILURE);
	}
      else
	predicates[predicateRow].srts[number++]=token;

    token = split(aLine, " (,)");

  } // end of while

  if(numOfToken==0) // Line is a space
    return 0;
  else if(numOfToken==1) // Only exists 'predicate' keyword in Line
  {
      cout << "ERROR: No predicate" << endl << endl;
      exit(EXIT_FAILURE);
  }
  else 
  {
    predicates[predicateRow].num=number;
    string p="";
    predicateName[0]=tolower(predicateName[0]);
    //$ predicateName[0]=tolower(predicateName[0]);
    p=predicateName+"(";
  
    string temp("");
    for(int j=0; j<number; j++)
    {
      prestr=predicates[predicateRow].srts[j];
      if(prestr.compare(temp)==0)
	prestr=prestr+integerToString(j);

      temp=prestr;
      prestr[0]=toupper(prestr[0]);
      //$ estr[0]=toupper(estr[0]);

      if(!existVars(prestr))
	allVars[allVarsRow++]=prestr;
      
      p=p+prestr;
   
      if(j+1<number)
	p=p+",";
    }

    p=p+").";
   
    declarationOfPredicates[decPredicateRow++]=p;
    predicateRow++;
    return 1;
  }
}
*/

int loadCompletion (string aLine)
{
  string completion="completion";
  string happens="Happens";  //$ "happens"
  int numOfToken=0;
  string token = split(aLine, " ,");

  while(token.compare("")!=0)
  {
    numOfToken++;

    if(numOfToken==1)
      if(token.compare(completion)!=0)
	return 0;
    
    // ##  Abnormal predicate // later

    if( (numOfToken==2 && token.compare(happens)!=0) ||
         numOfToken==3)
      {
	cout << "ERROR: completion is NOT applicable to '"
	     << token << "'" << endl << endl;
	exit(EXIT_FAILURE);
      }
    
    token = split(aLine, " ,");
  }

  if(numOfToken==0) // Line is a space
    return 0;
  else if(numOfToken==1) // Only exists 'completion' keyword in Line
    {
      cout << "ERROR: No predicate for completion" 
           << endl << endl;
      exit(EXIT_FAILURE);
    }
  else
    return 1;
}

int loadRange(string aLine)
{
  string range = "range";
  int numOfToken=0;
  string token = split(aLine, " ");
  string sortName("");
  int rangeMax=0;
  int rangeMin=0;
  string min("");
  string max("");
  bool flag_time=false;
  bool flag_offset=false;

  while(token.compare("")!=0)
  {
    numOfToken++;

    if(numOfToken==1)
      if(token.compare(range)!=0)
	return 0;
    
    if(numOfToken==2)
    {
      if(!isSubsortOfInteger(token))
      {
	cout << "ERROR: sort name '" << token << "'"
	     << "is not a subsort of Integer." 
             << endl << endl;
	exit(EXIT_FAILURE);
      }
      else
      {
	sortName=token;
	if(sortName.compare("time")==0)  //$ Time
	  flag_time=true;
	if(sortName.compare("offset")==0) // $ Offset
	  flag_offset=true;
      }
    }
    if(numOfToken==3)
      if(isNumber(token))
      {
	rangeMin = stringToInteger(token);
	min=token;
      }
      else
      {
	cout << "ERROR: min value is not valid." 
             << endl << endl;
	exit(EXIT_FAILURE);
      }

    if(numOfToken==4)
      if(isNumber(token))
      {	
	rangeMax = stringToInteger(token);
	max=token;
	if(sortName.compare("time")==0)
	{
	  maxOfTimepoint=max;
	  rangeMaxTime=rangeMax;
	  rangeMinTime=rangeMin;
	}
      }
      else
      {
	cout << "ERROR: max value is not valid." 
             << endl << endl;
	exit(EXIT_FAILURE);
      }
    
    token = split(aLine, " ");
  }

  if(flag_offset && (rangeMin<1 || rangeMax<1))
  {
    cout << "ERROR: Invalid offset values." 
	 << endl << endl;
    exit(EXIT_FAILURE);
  }   

  if(rangeMax<rangeMin)
  {
    cout << "ERROR: max value is less than min value." 
         << endl << endl;
    exit(EXIT_FAILURE);
  }   

  if(numOfToken==0) // Line is a space
    return 0;
  else if(numOfToken!=4) 
  {
    cout << "ERROR: range not followed by sort min max." 
         << endl << endl;
    exit(EXIT_FAILURE);
  }
  else 
  {
    rangeForm[rangeCol++]=sortName+"("+min+".."+max+").";
    
    if(sortName.compare("offset")==0) //$ Offset
    {
      rangeMaxOffset=rangeMax;
      rangeMinOffset=rangeMin;
    }
 
    return 1;
  }
}

int isSubsortOfInteger(string s)
{
  for(int i=0; i<subSortInt; i++)
    if(s.compare(subSortOfInteger[i])==0)
      return 1;
       
  return 0;
}

int stringToInteger(string number)
{
  int i;
  stringstream out;
  out.str(number);
  out >> i;
  return i;
}

int endFormula(string aLine)
{
  //## consider ';' comments

  int len=aLine.length();
  for(int i=0; i<len; i++)
  {
    if(i!=len-1)
    {  if(aLine[i]=='.')
       {
	 for(int j=i+1; j<len; j++)
	   if(aLine[j]!=' ')// && aLine[j]!=10)
	   {
	     cout << "ERROR: Not allowed to write" 
                  << " any character after the period"
                  << " on the same line." << endl << endl;
	     exit(EXIT_FAILURE);
	   }

	 return 1;
       }
    }
    else
    {
      if(aLine[i]=='.')
	return 1;
      else 
	return 0;
    }
  }
}

// Check parse errors (syntax)
void checkParsError(string form)
{
  //##
  // if the formula has more than one implication 
  // or bi-impl ERROR

  char prev = (char)NULL;
  int len=form.length();
  int tuple_start=0;
  int count=0; // for matching '(' and ')' 
  int count2=0;// for matching '{' and '}'
  int count3=0;// for matching '[' and ']'
  struct stack s;
  s.top=-1; 

  for(int i=0; i<len; i++)
  {
    if(form[i]==' ')
      continue;

    if(form[i]==34  ||  // " 
       form[i]==35  ||  // # 
       form[i]==36  ||  // $   
       form[i]==39  ||  // '
       form[i]==58  ||  // :
       form[i]==63  ||  // ?
       form[i]==64  ||  // @
       form[i]==92  ||  // \
       form[i]==95  ||  // _
       form[i]==96  ||  // `
       form[i]==126 )   // ~
      giveParsError(form);

    if(i==0)
    {
      if(form[i]=='(')
	count++;
      if(form[i]=='{')
	count2++;
      if(form[i]=='[')
	count3++;
    }
    else
    {  
      if(isalnum(form[i]))
	if(form[i-1]==')')
 	  giveParsError(form);

      if(tuple_start)
	if(!isalnum(form[i]) && form[i]!='(' &&
	   form[i]!=')' && form[i]!=',' && form[i]!=' ')          
 	  giveParsError(form);

      if(form[i]=='(')
      { 
	count++;
	if(form[i-1]==')' || form[i-1]=='{' ||
           form[i-1]=='[' || form[i-1]==',')
 	  giveParsError(form);
      
	if(isalnum(form[i-1]))
	{
	  tuple_start=1; push(&s, '(');
	}
      }

      if(form[i]==')')
      {
	count--;
	if(count<0)
	   giveParsError(form);
	
	if(!isalnum(form[i-1]) && form[i-1]!=')' 
	   && form[i-1]!='(' && form[i-1]!=' ')
	  giveParsError(form);

        if(tuple_start)
	{
	  pop(&s);
	  if(isempty(&s))
	    tuple_start=0;
	}
      }

      if(form[i]=='{')
      {
	count2++;
	if(form[i-1]!='!' && form[i-1]!='(' &&
	   form[i-1]!='|' && form[i-1]!='&' &&
	   form[i-1]!='>' && form[i-1]!=']' &&
	   form[i-1]!='}' && form[i-1]!=' ')
	  giveParsError(form);
      }

      if(form[i]=='}')
      {
	count2--;
	if(count2<0)
	  giveParsError(form);
	if(!isalnum(form[i-1]) && form[i-1]!=' ')
	  giveParsError(form);
      }

      if(form[i]=='[')
      {
	count3++;
	if(form[i-1]!='!' && form[i-1]!='(' &&
	   form[i-1]!='|' && form[i-1]!='&' &&
	   form[i-1]!='>' && form[i-1]!=']' &&
	   form[i-1]!='}' && form[i-1]!=' ')
	  giveParsError(form);
      }

      if(form[i]==']')
      {
	count3--;
	if(count3<0)
	  giveParsError(form);
	if(!isalnum(form[i-1]) && form[i-1]!=' ')
	  giveParsError(form);
      }

      switch(form[i])
      {
      case '+':
      case '*':
      case '/':
      case '%':
      case '^':
	if(!isalnum(form[i-1]) && form[i-1]!=')'
          && form[i-1]!=' ')
	  giveParsError(form); break;

      case ',':
      case '|':
      case '&':
	if(!isalnum(form[i-1]) && form[i-1]!=')'
	   && form[i-1]!=' ')
	  giveParsError(form); break;
      }
      
      // ## <   >   -  !
      
      /*      if(form[i]=='=')
	if(!isalnum(form[i-1]) && form[i-1]!=')'
	     && form[i-1]!='!' && form[i-1]!=' ')
	  giveParsError(form);
      */
      if(form[i]=='!')
      {
	//if(i<=len-2 && form[i+1]=='=')
	if(form[i+1]=='=')
	// not equal to
	{ 
	  if(!isalnum(form[i-1]) && form[i-1]!=')'
            && form[i-1]!=' ')
	    giveParsError(form);
	}
	// logical negation;
      }

      // case '.':
      if(form[i]=='.')
	if(form[i-1]!=' ' && !isalnum(form[i-1]) &&
	   form[i-1]!=')')
	  giveParsError(form);
    }
  } // end of 'for' loop

  if(count!=0 || count2!=0 || count3!=0)
    giveParsError(form);

}

void giveParsError(string form)
{
  cout << "\nSYNTAX ERROR in the following formula: " 
       << endl << form << endl << endl;
  exit(EXIT_FAILURE);
}

void trimSpace(string& aLine)
{
  int indexOfspace=aLine.find_first_of(' ', 0);

  while(indexOfspace>=0)
  {
    aLine.erase(indexOfspace, 1);
    indexOfspace=aLine.find_first_of(' ', 0);
  }
}

void changeSym(string& form)
{
  /*
    change <= to @
    change >= to # 
    change != to ~
    change -> to :
    change <->to $
  */

  int len=form.length();
  for (int i=0; i<len; i++)
  {
      //  if(i+1>=len)
      //  continue;
    
    if(i+1<len)
      {
	if(form[i]=='<' && form[i+1]=='=')
	  {form[i]='@'; form[i+1]=' ';}
	
	if(form[i]=='>' && form[i+1]=='=')
	  {form[i]='#'; form[i+1]=' ';}
	
	if(form[i]=='!' && form[i+1]=='=')
	  {form[i]='~'; form[i+1]=' ';}
	
	if(i>0 && form[i]=='-' && form[i+1]=='>' &&
	   form[i-1]!='<')
	  {form[i]=':'; form[i+1]=' ';}
      }

    if(i+2<len)
      if(form[i]=='<' && form[i+1]=='-' &&
	 form[i+2]=='>')
	{form[i]='$'; form[i+1]=' '; form[i+2]=' ';}
  }

  //  trimSpace(form);
}

void checkBiImpl(string& form)
{
  int len=form.length();
  bool found=false;
  for(int i=0; i<len; i++)
  {
    if(form[i]=='$')
    {
      form.replace(i,1,":");
      makeTree(form);

      // Left to Right
      returnInfixForm(root);
      subForms3[nOfsubForms3++]=rform;
      rform="";

      // Right to Left
      nodePtr target=searchNode(root, ":");
      nodePtr temp=target->left;
      target->left=target->right;
      target->right=temp;
      returnInfixForm(root);
      subForms3[nOfsubForms3++]=rform;
      rform="";

      found=true;
      break;
    }

  }
 
  if(!found)
    subForms3[nOfsubForms3++]=form;
}

void makeTree(string form)
{
  markTupleEnd(form);
  freshTokensOfForm();

  char formIN[FORM_COL]={(char)NULL};
  char formPRE[FORM_COL]={(char)NULL};
  char *inFormula = (char *)&formIN;
  char *preFormula= (char *)&formPRE;

  inFormula=(char *)form.c_str();

  //##  Error checking 
  infixToPrefix(inFormula, preFormula);

  getTokensOfForm(preFormula); 

  root=prefixToTree();
}

/*
  Add "?" right after each (maximal) tuple_end  
*/
void markTupleEnd(string& form)
{
  int tuple_start=0;
  int len=form.length();
  struct stack s;
  s.top=-1; 

  for(int i=0; i<len; i++)
  { 
    if(i>0)
    {  
      if(form[i]=='(' && isalnum(form[i-1]))
	{tuple_start=1; push(&s,'(');}
    }

    if(form[i]==')' && tuple_start)
    {  
      pop(&s);
      if(isempty(&s))
      {
	form.insert(i+1, "?"); len++;
        tuple_start=0; 
      }
    }
   
  }
  //  return form;
}

void freshTokensOfForm()
{
  for(int i=0; i<NUM_TOKENS_FORM; i++)
    tokenOfForm[i]="";
  ntokensOfForm=0;
}

void infixToPrefix(char *input, char *output)
{
  struct stack s0,s;
  char optop;
  int len=strlen(input);
  int i=0,j=0,k=0;
  int m=0;
  int tuple_start=0;
  s0.top=-1;
  s.top=-1;
                     /* now size of infix expression is known and
                       counter 'i' indicates to end of expression*/
  i=len-1;
  int space=0;
 
  for(int u=0; u<=i; u++)
  {
    if(u>0)
      if(input[u]=='(' && isalnum(input[u-1]))
	tuple_start=1;

    if( (input[u]=='(' && !tuple_start) || 
        (input[u]==')' && !tuple_start) || 
	(input[u]=='?')
      )
      continue;
    
    else if(input[u]==')' && input[u+1]=='?' && tuple_start)
    { 
      tuple_start=0; 
      j++;
    }

    else
      j++;


    // Make space so as to easily tokenize an input string
    if(!isalnum(input[u])  && input[u]!=',' &&
        input[u]!='(' && input[u]!=')' &&
        input[u]!='{' && input[u]!='}' &&
        input[u]!='[' && input[u]!=']' && 
        input[u]!='_' &&
        !isNegation(input,u)
      )
      space=space+2;

    if(isNegation(input,u) && tuple_start==0)
      space=space+3;

    if(input[u]=='}' || input[u]==']' ||
       input[u]=='{' || input[u]=='[' ) 
      space=space+1;

  }
  
  j=j+space;
  m=j;
  j--;              /* now j indicates end of prefix expression */
  
  while(i>=0)
  {
    if(input[i]==')' && input[i+1]=='?')
        tuple_start=1;
    
    if(input[i]=='?')
      {i--; continue;}

    if(isalnum(input[i]) || tuple_start   ||
           input[i]=='{' || input[i]=='[' ||
           input[i]=='!' ||
           input[i]==',' || input[i]=='_'  ||
           isNegation(input, i))
    {
      if(input[i]==')')
	push(&s0,'T');

      if(input[i]=='(')
      {
	pop(&s0);
	if(isempty(&s0))
	  tuple_start=0;
      }
      
      if(input[i]=='!')
      {output[j--]=' '; output[j--]=input[i]; 
       output[j--]=' ';}

      else if(isNegation(input, i) && tuple_start==0)
	{output[j--]=' '; output[j--]=input[i]; 
         output[j--]=input[i]; output[j--]=' ';}

      else if(input[i]=='{' || input[i]=='[')
	{output[j--]=input[i]; output[j--]=' ';}
      
      else
	{output[j--]=input[i];}
     
    }
    else
    {
      while(!isempty(&s)&&(prcd(s.item[s.top],input[i])))
      {
	optop=s.item[s.top];
	pop(&s);
	output[j--]=' ';
	output[j--]=optop;
      }

      if(input[i]=='}' || input[i]==']')
      {
	output[j--]=' ';
	output[j--]=input[i];
      }

      else if(isempty(&s)||input[i]!='(')
      {
	push(&s,input[i]); 
	if(input[i]!=')')
	  output[j--]=' ';
      }
      else
      {
	pop(&s);
      }
    }

    i--;
  }
  
  while(!isempty(&s))
  {
    output[j--]=' ';
    optop=s.item[s.top];
    pop(&s);
    output[j--]=optop;
  }
}

// Except timepoints
int isNegation(char *input, int i)
{
  /*  if(i==0)  
    if(input[i]=='-')
      return 1;
  */
  // i+1<=strlen(input)-1

  /*  if(input[i]=='-')
    if(input[i-1]==',') // inside Tuple, it is a timepoint
    return 0; */

  if(input[i]=='-' && input[i-1]!=')' &&
     !isalnum(input[i-1]) && 
     (isalnum(input[i+1]) || input[i+1]=='(') )
    return 1;
  else 
    return 0;
}

void push(struct stack *ps, char n)
{
  if(!full(ps))
    {
      ps->top++;              // Incrementing the top
      ps->item[ps->top]=n; // Storing an element
    }
  else
    {
      cout << "ERROR: Can't push in a FULL Stack!!" 
           << endl << endl;
      exit(EXIT_FAILURE);
    }
}

void pop(struct stack *ps)
{
  if(!isempty(ps))
  {  
    //    elem=s1->data[s1->top];
    ps->top--;
  }
  else
    {
      cout << "ERROR: Can't pop in an EMPTY Stack!!" 
           << endl << endl;
      exit(EXIT_FAILURE);
    }
}

int isempty(struct stack *ps)
{
  if(ps->top==-1)
    return 1;

  return 0;
}

int prcd(char stktop,char op)
{
  if(stktop==op)
    return 0;

  if(stktop==')')
    return 0;
 
  if((stktop!='(')&&(op==')'))
    return 0;
  
  if((stktop!=')')&&(op=='('))
    return 1;


///////// '}', ']' //////////////////////////////////////////////
  if( ((stktop==':')||(stktop=='$')||
       (stktop=='|')||(stktop=='&')) &&            
      ((op=='}')||(op==']'))
    )
    return 0;
  
  if( (stktop!=':')&&(stktop!='$')&&
      (stktop!='|')&&(stktop!='&')&&
      ((op=='}')||(op==']'))
    )
    return 1;


/////////  '*', '/', '%' ////////////////////////////////////////
  if((op=='*')||(op=='/')||(op=='%'))
    return 0;
  if( ((stktop=='*')||(stktop=='/')||(stktop=='%'))&&
      op!=')')
    return 1;


/////////  '+', '-' /////////////////////////////////////////////
  if( ((stktop=='+')||(stktop=='-'))&&
      ((op=='*')||(op=='/')||(op=='%')||(op=='!')))
    return 0;
  if( ((stktop=='*')||(stktop=='/')||(stktop=='%')||(stktop=='!'))
      &&((op=='+')||(op=='-')))
    return 1;

  if( (stktop!='*')&&(stktop!='/')&&(stktop!='%')&&(stktop!='!')
      &&((op=='+')||(op=='-')))
     return 0;
  if( ((stktop=='+')||(stktop=='-'))&&
      (op!='*')&&(op!='/')&&(op!='%')&&(op!='!')&&(op!=')'))
    return 1;


/////////  '<','<=','=','>=','>','!=' ///////////////////////////
///////// Change <= to @, >= to #, and != to ~
  if( ((stktop=='<')||(stktop=='@')||(stktop=='=')||(stktop=='#')||
       (stktop=='>')||(stktop=='~')) &&
       (op!='&')&&(op!='|')&&(op!='$')&&(op!=':')&&
       (op!='(')&&(op!=')'))
    return 0;
  if( (stktop!='&')&&(stktop!='|')&&(stktop!='$')&&(stktop!=':')&&
      (stktop!='(')&&(stktop!=')')&&
      ((op=='<')||(op=='@')||(op=='=')||(op=='#')|| 
       (op=='>')||(op=='~')))
    return 1;

  if( ((stktop=='&')||(stktop=='|')||(stktop=='$')||(stktop==':'))&&
      ((op=='<')||(op=='@')||(op=='=')||(op=='#')|| 
       (op=='>')||(op=='~')))
    return 0;
  if( ((stktop=='<')||(stktop=='@')||(stktop=='=')||(stktop=='#')||
       (stktop=='>')||(stktop=='~')) &&
      ((op=='&')||(op=='|')||(op=='$')||(op==':')))
    return 1;


/////////  '|', '& '//////////////////////////////////////////
  if(((stktop=='&')||(stktop=='|'))&&
     (op!='(')&&(op!=')')&&(op!=':')&&(op!='$'))
    return 0;
  if((stktop!='(')&&(stktop!=')')&&(stktop!='$')&&(stktop!=':')&&
     ((op=='|')||(op=='&')))
    return 1;

  if(((stktop==':')||(stktop=='$'))&&((op=='|')||(op=='&')))
    return 0;
  if(((stktop=='|')||(stktop=='&'))&&((op==':')||(op=='$')))
    return 1;


/////////  '->', '<->'($) //////////////////////////////////////
  if(((stktop==':')||(stktop=='$'))&&(op!='(')&&(op!=')'))
    return 0;
  if((stktop!='(')&&(stktop!=')')&&((op==':')||(op=='$')))
    return 1;
  
  /// '->','<->'  VS. '(',')' ///
  // Nothing to add

}

int full(struct stack *ps)
{
  if(ps->top==30)
    return 1;

  return 0;
}

void getTokensOfForm(char *prefix)
{ 
  char *token=strtok(prefix, " ");
  int index=0;

  while(token != NULL)
  {
    tokenOfForm[index]=token;
    index++;
    token = strtok(NULL, " ");
  }
}

nodePtr prefixToTree()
{

  // Creates a new node
  nodePtr newNode = (nodePtr) new(struct node);

  newNode->left=NULL;
  newNode->right=NULL;
  newNode->parent=NULL;
  newNode->str=tokenOfForm[ntokensOfForm++];
  string key=newNode->str;


  if(isalnum(key[0]))
    return newNode;

  if(universalQuan(key)  || existentialQuan(key) ||
     key.compare("!")==0 || key.compare("--")==0)
    newNode->left=NULL;
  else
    newNode->left=prefixToTree();
  
  newNode->right=prefixToTree(); 
  

  if(newNode->left!=NULL)
    newNode->left->parent=newNode;
  newNode->right->parent=newNode;

  return newNode;
}

bool existentialQuan(string eq)
{
  int flag=0;

  if(eq[0]!='{')
    return false;
  
  string token=split(eq, "{,}");
  while(token.compare("")!=0)
  {
    if(!isVariable(token))
    {
      cout << "ERROR: '" << token
	   << "' in existential quantification"
           << " is not a variable.\n\n";
      exit(EXIT_FAILURE);
    }

    for(int i=0; i<varsRow; i++)
      if(variables[i].compare(token)==0)
	{flag=1; break;}

    if(!flag)
      variables[varsRow++]=token;

    token=split(eq, "{,}");
  }

  return true;
}

bool isVariable(string var)
{
  /*
    A variable consists of one or more lowercase letters
    followed by zero or more digits.
    The sort associated with a variable is determined by
    removing digits from the variable.
  */
  int len=var.length();
  string temp("");  

  if(!islower(var[0])) //$ isupper
    return false;

  for(int i=0; i<sortRow; i++)
  {     
    if(var.find(sorts[i].sName,0)==0)//var.find(sorts[i],0)==0)
    { 
      if(var.compare(sorts[i].sName)==0) //var.compare(sorts[i])==0)
	return true;
      else
      {
	temp=var.substr(sorts[i].sName.length());
             //var.substr(sorts[i].length());
	if(isNumber(temp))
	  return true;
	else 
	  break;
      }
    }
  }

  cout << "ERROR: sort name for variable '"<< var 
       << "' was not defined." << endl << endl;
  exit(EXIT_FAILURE);
}

bool universalQuan(string eq)
{
  int flag=0;

  if(eq[0]!='[')
    return false;

  string token=split(eq, "[,]");

  while(token.compare("")!=0)
  {
    if(!isVariable(token))
    {
      cout << "ERROR: '" << token
	   << "' in universal quantification"
           << " is not a variable.\n\n";
      exit(EXIT_FAILURE);
    }

    for(int i=0; i<varsRow; i++)
      if(variables[i].compare(token)==0)
	{flag=1; break;}

    if(!flag)
      variables[varsRow++]=token;

    token=split(eq, "[,]");
  }

  return true;
}

void returnInfixForm(nodePtr tree)
{
  int flag=0;

  if(tree)
  {
    if( tree->left!=NULL && tree->right!=NULL)
        // || tree->str.compare(":")==0)
      flag=1;

    if(flag)
      rform.append("(");

    returnInfixForm(tree->left);
    
    rform.append(tree->str);

    returnInfixForm(tree->right);
    
    if(flag)
      rform.append(")");
  }
  else
    return;
}

nodePtr searchNode(nodePtr tree, string target)
{
  nodePtr result = NULL;
  
  if(tree->str.find(target, 0)==0)
    result=tree;
  else
  {
    if(tree->left!=NULL)
      result=searchNode(tree->left, target);
    if(result==NULL && tree->right!=NULL)
      result=searchNode(tree->right, target);
  }

  return result;
}

/*
For each formula that contains a condition
in the antecedent, eliminate disjunctions
in the antecedent by applying C1 repeatedly
*/
void applyC1(string form)
{
  int i=form.find(":", 0);
  int j=form.find("|", 0);

  if(i>0 && j>0 && j<i)
  { 
    makeTree(form);
    eliminateDisjunction(root);
  }
  else
    subForms[nOfsubForms++]=form;   
}

void eliminateDisjunction(nodePtr tree)
{
  nodePtr temp=searchNode(tree,":");
  nodePtr leftChild=temp->left;
  nodePtr target=searchNode(leftChild,"|");
  nodePtr rc,lc,pt; // right-child, left-child, and parent
  
  getAncestorsWithNegOrExistQuan(target);

  if(target==NULL || notApplyC1andC2)
  {
    returnInfixForm(tree);
    subForms[nOfsubForms++]=rform;
    rform="";
    notApplyC1andC2=false;
  }
  else
  {
    lc=target->left;
    rc=target->right;
    pt=target->parent;

    if(pt->left==target)
    {
      pt->left=lc;
      lc->parent=pt;
  
      target->parent=NULL;
      target->left=NULL;
      target->right=NULL;
      rc->parent=NULL;

      eliminateDisjunction(tree);

      lc->parent=NULL;
      // lc->left=NULL;
      // lc->right=NULL;
  
      pt->left=rc;
      rc->parent=pt;

      eliminateDisjunction(tree);

      // Back to original
      target->parent=pt;
      pt->left=target;

      target->left=lc;
      target->right=rc;

      target=lc->parent;
      target=rc->parent;    
    }
    else
    {
      pt->right=rc;
      rc->parent=pt;
  
      target->parent=NULL;
      target->left=NULL;
      target->right=NULL;
      lc->parent=NULL;

      eliminateDisjunction(tree);

      rc->parent=NULL;
      //rc->left=NULL;
      //rc->right=NULL;
  
      pt->right=lc;
      lc->parent=pt;
      
      eliminateDisjunction(tree);

      // Back to original
      target->parent=pt;
      pt->right=target;

      target->left=lc;
      target->right=rc;

      target=lc->parent;
      target=rc->parent;
    }    
  }
}

void getAncestorsWithNegOrExistQuan(nodePtr child)
{
  if(child==NULL)
    return ;
  else
  {
    if(child->parent!=NULL)
    {  
      string s=child->parent->str;
      if(s[0]=='{' || s[0]=='!')
	notApplyC1andC2=true;
      else
	getAncestorsWithQuan(child->parent);
    }
    else
      return ;
  }
}

/*
For each formula that contains a condition
in the consequent, eliminate conjunctions
in the consequent by applying C2 repeatedly
*/
void applyC2(string form)
{
  int i=form.find(":", 0);
  if(i>0)
  {
    int j=form.find("&", i);    
    if(j>i)
    {
      makeTree(form);
      eliminateConjunction(root);
    }
    else
      subForms2[nOfsubForms2++]=form;
  }
  else
    subForms2[nOfsubForms2++]=form;

}

void eliminateConjunction(nodePtr tree)
{
  nodePtr temp=searchNode(tree,":");
  nodePtr rightChild=temp->right;
  nodePtr target=searchNode(rightChild,"&");
  nodePtr rc,lc,pt; // right-child, left-child, and parent

  getAncestorsWithNegOrExistQuan(target);

  if(target==NULL || notApplyC1andC2)
  {
    returnInfixForm(tree);
    subForms2[nOfsubForms2++]=rform;
    rform="";
    notApplyC1andC2=false;
  }
  else
  {   
    lc=target->left;
    rc=target->right;
    pt=target->parent;

    if(pt->left==target)
    {
      pt->left=lc;
      lc->parent=pt;
  
      target->parent=NULL;
      target->left=NULL;
      target->right=NULL;
      rc->parent=NULL;

      eliminateConjunction(tree);

      lc->parent=NULL;
      //lc->left=NULL;
      //lc->right=NULL;
  
      pt->left=rc;
      rc->parent=pt;

      eliminateConjunction(tree);
      
      // Back to original
      target->parent=pt;
      pt->left=target;
      
      target->left=lc;
      target->right=rc;
      
      target=lc->parent;
      target=rc->parent;
    }
    else
    {     
      pt->right=rc;
      rc->parent=pt;
  
      target->parent=NULL;
      target->left=NULL;
      target->right=NULL;
      lc->parent=NULL;

      eliminateConjunction(tree);
      
      rc->parent=NULL;
      //rc->left=NULL;
      //rc->right=NULL;
  
      pt->right=lc;
      lc->parent=pt;

      eliminateConjunction(tree);

      // Back to original
      target->parent=pt;
      pt->right=target;
      
      target->left=lc;
      target->right=rc;
      
      target=lc->parent;
      target=rc->parent;
    }    
  }
}

void displayTree(nodePtr tree)
{
  if(tree)
  {
    displayTree(tree->left);
    cout << tree->str << endl;
    displayTree(tree->right);
  }
  else
    return;
}

/*
  Rewrite a formula so that existential quantification
  occurs only in the antecedent of the formula
*/
void moveExistentialQuan(nodePtr tree)
{
  nodePtr temp=searchNode(tree,":");
  nodePtr pt;

  if(temp==NULL)
  {  
    returnInfixForm(tree);
    return;
  }
  
  nodePtr lChild=temp->left;
  nodePtr rChild=temp->right;
  
  if(rChild==NULL)
  {
    noRightChild=true;
    returnInfixForm2(tree); 
  }
  else
  {
    nodePtr target=searchNode(rChild,"{");
    bool flag_left=false;

    if(target==NULL)  
      returnInfixForm(tree); 
    else
    {
      nodePtr newNode=(nodePtr) new(struct node);
      bool neg=false;

      // Right-hand side of implication
      if(target->parent->str.compare("!")==0)
	//{newNode=target; neg=true;}
      {
	newNode->str=target->str;
	newNode->left=NULL;
	newNode->right=target->right;
        neg=true;
      }
      else
      {
	newNode->str="!";
	newNode->left=NULL;
	newNode->right=target;
	//	target->parent=newNode;
      }
   
      if(neg)
	pt=target->parent->parent;
      else
	pt=target->parent;


      // Connects target's sibling to target's grandparent
      if(pt->str.compare(":")==0)
	pt->right=NULL;
      else
      {
	nodePtr grand_pt=pt->parent;

	if(neg)
	{
	  if(pt->left==target->parent)
	    flag_left=true;
	}
	else
	  if(pt->left==target)
	    flag_left=true;

	if(grand_pt->left==pt)
        {
	  if(flag_left)
	  {
	    nodePtr rc=pt->right;
	    rc->parent=grand_pt;
	    grand_pt->left=rc;  
	  }
	  else
	  {
	    nodePtr lc=pt->left;
	    lc->parent=grand_pt;
	    grand_pt->left=lc; 
	  }
	}	
	else
        {
	  if(flag_left)
	  {
	    nodePtr rc=pt->right;
	    rc->parent=grand_pt;
	    grand_pt->right=rc; 
	  }  
	  else
	  {
	    nodePtr lc=pt->left;
	    lc->parent=grand_pt;
	    grand_pt->right=lc;
	  }
	}

	pt->left=NULL;
	pt->right=NULL;
	pt->parent=NULL;
      }

      // Left-hand side of implication
      nodePtr newNode2=(nodePtr) new(struct node);
      newNode2->str="&";

      temp->left=newNode2;
      lChild->parent=newNode2;

      newNode2->parent=temp;
      newNode2->left=lChild;
      newNode2->right=newNode;
      newNode->parent=newNode2;

      moveExistentialQuan(tree);
    }
  }
}

void returnInfixForm2(nodePtr tree)
{
  int flag=0;

  if(tree)
  {
    if( (tree->left!=NULL && tree->right!=NULL)
        || tree->str.compare(":")==0)
      flag=1;

    if(flag)
      rform2.append("(");

    returnInfixForm2(tree->left);
    
    rform2.append(tree->str);

    returnInfixForm2(tree->right);
    
    if(flag)
      rform2.append(")");
  }
  else
    return;
}

void checkFreeVars()
{ 
  int flag=0;
  nodePtr cNode;
  string child(""),ancestor(""), token(""), token2("");


  // 1. Find out all child nodes
  getChildNodes(root);

  for(int i=0; i<nOfchildNodes; i++)
  {
    cNode = childNodes[i];
    
    // 2. For each child node, find out ancestors 
    //    with universal or existential quantification

    getAncestorsWithQuan(cNode);

    child = cNode->str;

    token=split(child, "(,)");
    while(token.compare("")!=0)
    {
      if(isVariable(token))
      {// 3. Check free variables
	for(int j=0; j<nOfancestors; j++)
	{
	  ancestor=ancestors[j]->str;
	  token2=split(ancestor, "[]{},");
	  while(token2.compare("")!=0)
	  {
	    if(token.compare(token2)==0)
	      {flag=1; break;}
	    token2=split(ancestor, "[]{},");
	  }
	  if(flag)
	    break;
	}

	if(!flag)
	{
	  cout << "ERROR: free variable '" << token
               << "' in " << cNode->str << endl << endl;
	  exit(EXIT_FAILURE);
	}
      }

      flag=0;
      token=split(child, "(,)");  
    }
    
    nOfancestors=0;
    for(int k=0; k<NUM_ANCESTORS; k++)
      ancestors[k]=NULL;
  }

  nOfchildNodes=0;
  for(int l=0; l<NUM_CHILDNODES; l++)
    childNodes[l]=NULL;
}

// leaves
void getChildNodes(nodePtr tree)
{
  if(tree)
  {
    if(tree->left==NULL && tree->right==NULL)
      childNodes[nOfchildNodes++]=tree;

    getChildNodes(tree->left);
    getChildNodes(tree->right);

  }
  else
    return;
}

void getAncestorsWithQuan(nodePtr child)
{
  if(child==NULL)
    return ;
  else
  {
    if(child->parent!=NULL)
    {  
      string s=child->parent->str;
      if(s[0]=='{' || s[0]=='[')
	ancestors[nOfancestors++]=child->parent;
      getAncestorsWithQuan(child->parent);
    }
    else
      return ;
  }
}

/* 
  Eliminate maximal positive occurrence of
  an existential quantification in the antecedent 
  of a formula
=> Change existential quantifications to
   universal quantifications by converting to PNF
   - Remove existential quantifications
   - Simultaneously, rename variables
*/
string eliminatePosQuan(string form, char open, char close)
{ 
  different=false;  
  areDifferentVars();

  // for existential quantification
 return  removeQuan(form, open, close);
}

void areDifferentVars()
{
  int flag=0;

  for(int i=0; i<varsRow; i++)
  { 
    if(i==varsRow-1)
      break;
    for(int j=i+1; j<varsRow; j++)
    {  
      if(variables[i].compare(variables[j])==0)
	{flag=1;break;}
    }
  }

  if(!flag)
    different=true;
}

/*
  Remove quantifications and rename variables
*/
string removeQuan(string form, char open, char close)
{
  int QuanStart=0,QuanEnd=0;
  int lenOfvar=0;
  string var("");
  string varRename("");
  int end=form.length()-1; 
  int index=0;
  int varFound=0;
  int limit=0;

  QuanStart=form.find_first_of(open,0);

  if(QuanStart<0)
    return form;
  
  QuanEnd=form.find_first_of(close, 0);
  index=getVariables(form, open, close, QuanStart);
  limit=findLimit(form, index);

  for(int k=0; k<tempVarsRow; k++) 
  { 
    var=tempVars[k]; 
    lenOfvar=var.length();
    varFound=form.find(var, index);
      
    while(1)
    { /*
      if(varFound>limit||varFound<0)
      {
	cout << "ERROR: variable '" << var
	     << "' not used in "    << form 
	     << endl << endl;
	exit(EXIT_FAILURE);
      }
      */
      if(isalnum(form[varFound+lenOfvar]) || 
	 form[varFound+lenOfvar]=='_')
	varFound=form.find(var,varFound+lenOfvar);
      else
	break;
    }
      
    varRename=renameVar(form, var, varFound);
      
    do
    {	
      if(isalnum(form[varFound+lenOfvar]) ||
	 form[varFound+lenOfvar]=='_');
      else
      {  
	form.replace(varFound,lenOfvar,varRename);
	form.insert(varFound,"_v"); // To make a variable marker
	limit=limit+(varRename.length()-lenOfvar)+2;
      }
      varFound=form.find(var, varFound+lenOfvar);

    }while(varFound<limit && varFound>0);
  } // end of 'for' loop

  form.erase(QuanStart, QuanEnd-QuanStart+1);

  return form;
}

string renameVar(string form, string var, int varFound)
{
  string varRename("");
  string var2("");
  int index=0;
  string s;

  if(different) // If all variable names are different
  { 
    var[0]=toupper(var[0]);
    varRename=var;
  }
  else
  {
    for(int i=1; i<var.length(); i++)
    {
      if(var[i]>='0' && var[i]<='9') 
	{index=i; break;}
    }
  
    if(index==0)
      var2=var;                 // Ex) location -> Location30
    else
      var2=var.substr(0,index); // Ex) location1 -> Location30

    s=integerToString(varFound);
    //$var2[0]=toupper(var2[0]);
    var2[0]=toupper(var2[0]);
    varRename=var2+s;

    //##
    // CASE: when names of variables are the same in quan 
    //    cout << "1" << endl;
    // cout << form << endl;
    //cout << form.length() << endl;
    //exit(EXIT_FAILURE);
    //while(form.find(varRename)>0 && form.find(varRename)<form.length())
    //{
    // cout << form.find(varRename) << endl;
    // cout << "l: " << form.length() << endl;
    //  varFound=varFound++;
    //  s=integerToString(varFound);
    //  varRename=var2+s;
    // }

    // cout << "2" << endl;
  }
 
  if(!existVars(varRename))
    allVars[allVarsRow++]=varRename;
 
  return varRename;
}      

string removeExtraParentheses(string& form)
{
  int tuple_start=0;
  int len=form.length();
  struct stack s;
  s.top=-1; 

  for(int i=0; i<len; i++)
  { 
    if(i==0)
    {  
      if(form[i]=='(')
	form.replace(i,1," ");
    }
    else
    {  
      if(form[i]=='(')
	if(isalnum(form[i-1]))
	{tuple_start=1; push(&s,'(');}
	else
	  form.replace(i,1," ");
   
      if(form[i]==')')
	if(tuple_start)
        {  
	  pop(&s);
	  if(isempty(&s))
	    tuple_start=0; 
	}
	else
	  form.replace(i,1," ");
    }
  }

  trimSpace(form);

  return form;
}

string converToLP(string form)
{
  string result("");
  string head("");
  string body("");
  string token("");
  int end=0;
  int index=0;
  int len=form.length();
  int indexOfimpl=-1;

  for(int i=0; i<len; i++)
  {
    if(form[i]==':')
      {indexOfimpl=i; break;}
  }


  if(indexOfimpl==-1)
  {  
    if(form[0]=='!')
      result=":- "+form.erase(0,1)+".";
    else
      result=form+".";
  }
  else
  {
    head=form.substr(indexOfimpl+1);
    body=form.substr(0,indexOfimpl);

    if(head.length()==0)
      result=":- "+body+".";
    else
    {
      if(head[0]=='!')
      {
	head=head.substr(1);
	result=":- "+body+", "+head+".";
      }
      else
	result=head+" "+":-"+" "+body+".";
    }

    int l=result.length();
    for(int j=0; j<l; j++)
      if(result[j]=='!')
	{result.replace(j,1,"not "); l=l+4;}
  }

  handleHead(result);

  // Small -> Big for variables
  // Big -> Small for events, fluents, constants, predicates of EC  
  int found=0;
  int len2=result.length();
  int exit=0, k2=0;


  for(int k=0; k<len2; k++)
  {
    ///////########### Syntactically checking later ########
    found=result.find(Initiates, k);
    if(found>=0 && found<len2)
    { 
      if(!isalnum(result[found+Initiates.length()]) &&
	 !isalnum(result[found-1]))
	    result[found]=tolower(result[found]);
    }

    found=result.find(Terminates, k);
    if(found>=0 && found<len2)
    { 
      if(!isalnum(result[found+Terminates.length()]) &&
	 !isalnum(result[found-1]))
	    result[found]=tolower(result[found]);
    }

    found=result.find(Releases, k);
    if(found>=0 && found<len2)
    { 
      if(!isalnum(result[found+Releases.length()]) &&
	 !isalnum(result[found-1]))
	    result[found]=tolower(result[found]);
    }    

    found=result.find(HoldsAt, k);
    if(found>=0 && found<len2)
    { 
      if(!isalnum(result[found+HoldsAt.length()]) &&
	 !isalnum(result[found-1]))
	    result[found]=tolower(result[found]);
    }

    found=result.find(ReleasedAt, k);
    if(found>=0 && found<len2)
    { 
      if(!isalnum(result[found+ReleasedAt.length()]) &&
	 !isalnum(result[found-1]))
	    result[found]=tolower(result[found]);
    }

    found=result.find(Happens, k);
    if(found>=0 && found<len2)
    { 
      if(!isalnum(result[found+Happens.length()]) &&
	 !isalnum(result[found-1]))
	    result[found]=tolower(result[found]);
    }

    found=result.find(Happens3, k);
    if(found>=0 && found<len2)
    { 
      if(!isalnum(result[found+Happens3.length()]) &&
	 !isalnum(result[found-1]))
	    result[found]=tolower(result[found]);
    }

    found=result.find(Trajectory, k);
    if(found>=0 && found<len2)
    { 
      if(!isalnum(result[found+Trajectory.length()]) &&
	 !isalnum(result[found-1]))
	    result[found]=tolower(result[found]);
    }

    found=result.find(AntiTrajectory, k);
    if(found>=0 && found<len2)
    { 
      if(!isalnum(result[found+AntiTrajectory.length()]) &&
	 !isalnum(result[found-1]))
	    result[found]=tolower(result[found]);
    }

    found=result.find(StoppedIn, k);
    if(found>=0 && found<len2)
    { 
      if(!isalnum(result[found+StoppedIn.length()]) &&
	 !isalnum(result[found-1]))
	    result[found]=tolower(result[found]);
    }

    found=result.find(StartedIn, k);
    if(found>=0 && found<len2)
    { 
      if(!isalnum(result[found+StartedIn.length()]) &&
	 !isalnum(result[found-1]))
	    result[found]=tolower(result[found]);
    } 

    found=result.find(Clipped, k);
    if(found>=0 && found<len2)
    { 
      if(!isalnum(result[found+Clipped.length()]) &&
	 !isalnum(result[found-1]))
	    result[found]=tolower(result[found]);
    }

    found=result.find(Started, k);
    if(found>=0 && found<len2)
    { 
      if(!isalnum(result[found+Started.length()]) &&
	 !isalnum(result[found-1]))
	    result[found]=tolower(result[found]);
    }

    found=result.find(Stopped, k);
    if(found>=0 && found<len2)
    { 
      if(!isalnum(result[found+Stopped.length()]) &&
	 !isalnum(result[found-1]))
	    result[found]=tolower(result[found]);
    }

    found=result.find(Initiated, k);
    if(found>=0 && found<len2)
    { 
      if(!isalnum(result[found+Initiated.length()]) &&
	 !isalnum(result[found-1]))
	    result[found]=tolower(result[found]);
    }

    found=result.find(Terminated, k);
    if(found>=0 && found<len2)
    { 
      if(!isalnum(result[found+Terminated.length()]) &&
	 !isalnum(result[found-1]))
	    result[found]=tolower(result[found]);
    }
   
    for(int n=0; n<constRow; n++)
    {
      int number=constants[n].num;
      for(int o=0; o<number; o++)
      {
	k2=k; exit=0;
	do
	{
	  found=result.find(constants[n].objects[o], k2);
	  if(found>=0 && found<len2)
	  {  
	    if(!isalnum(result[found+constants[n].objects[o].length()]) &&
	       !isalnum(result[found-1]))
	      {
		result[found]=tolower(result[found]);
		result.insert(found, "_c"); // To make a constant marker
	      }
	    
	    k2=found+constants[n].objects[o].length()+2;
	  }
	  else
	    exit=1; // break;
	}while(k2<len2 && exit!=1);
      }
    }

    for(int l=0; l<fluentRow; l++)
    {
      k2=k; exit=0;
      do
      {
	found=result.find(fluents[l].pName, k2);
	if(found>=0 && found<len2)
	{ 
	  if(!isalnum(result[found+fluents[l].pName.length()]) &&
	     !isalnum(result[found-1]))
	    result[found]=tolower(result[found]);

	  k2=found+fluents[l].pName.length();
	}
	else
	  exit=1; // break;
      }while(k2<len2 && exit!=1);
    }

    for(int m=0; m<eventRow; m++)
    {
      k2=k; exit=0;
      do
      {
	found=result.find(events[m].pName, k2);
	if(found>=0 && found<len2)
	{
	  if(!isalnum(result[found+events[m].pName.length()]) &&
	     !isalnum(result[found-1]))
	    result[found]=tolower(result[found]);

	  k2=found+events[m].pName.length(); 
	}
	else 
	  exit=1; // break;
      }while(k2<len2 && exit!=1);
    }
    /*
    for(int n=0; n<predicateRow; n++)
    {
      k2=k; exit=0;
      do
      {
	found=result.find(predicates[n].pName, k2);
	if(found>=0 && found<len2)
	{
	  if(!isalnum(result[found+predicates[n].pName.length()]) &&
	     !isalnum(result[found-1]))
	    result[found]=tolower(result[found]);

	  k2=found+predicates[n].pName.length(); 
	}
	else 
	  exit=1; // break;
      }while(k2<len2 && exit!=1);
    } */
  }

  convertSyms(result);

  return result;	     
}

void handleHead(string& form)
{
  int len=form.length();
  int key=form.find(":-", 0);
  int key2, gte, lt, eq, neq, lte, gt, change=0;
  string head(""), body(""), token(""), newHead("");

  if(key>0 && key<len)
  { 
    form.erase(len-1, 1); // Remove '.'
    head=form.substr(0, key-1);
    body=form.substr(key+3);
    string token = split(head, "|");
    
    while(token.compare("")!=0)
    {
      gte=token.find("#"); // >=
      lt=token.find("<");
      eq=token.find("=");
      neq=token.find("~"); // !=
      lte=token.find("@"); // <=
      gt=token.find(">"); 
     
      if(gte>0)
	{token.replace(gte,1,"<"); change=1;}
      else if(lt>0)	
	{token.replace(lt,1,"#"); change=1;}
      else if(eq>0)
	{token.replace(eq,1,"~"); change=1;}
      else if(neq>0)
	{token.replace(neq,1,"="); change=1;}
      else if(gt>0)
	{token.replace(gt,1,"@"); change=1;}
      else if(lte>0)
	{token.replace(lte,1,">"); change=1;}
      else
	newHead=newHead+token+" | ";

      if(change)
	{body=body+", "+token; change=0;}

      token = split(head, "|");
    }
    
    if(newHead.compare("")!=0)
    {
      newHead.erase(newHead.length()-3,3);
      form = newHead + " :- " + body + ".";
    }
    else
      form = ":- " + body + ".";
  }
  else;
}

void convertSyms(string& form)
{
  // ######### '=' ==> '=='

  int len=form.length();

  for(int i=0; i<len; i++)
  {
    if(form[i]=='&')
    { 
      form.replace(i,1,", ");
      len++;
    }

    else if(form[i]=='%')
    { 
      form.replace(i,1," mod ");
      len=len+4;
    }
 
    else if(form[i]=='@')
    {
      form.replace(i,1,"<=");
      len++;
    }
    else if(form[i]=='#')
    {
      form.replace(i,1,">=");
      len++;
    }
    else if(form[i]=='~')
    {
      form.replace(i,1,"!=");
      len++;
    }
    else if(i+1<len && form[i]!='!' && form[i+1]=='=')
    {
      form.replace(i+1,1,"==");
      len++; i++;
    }
    else if(i+1<len && form[i]=='-' && form[i+1]=='-')
    {
      form.replace(i,2,"-");
      len--;
    }
    else if
     (i+1<len && form[i]=='_' && 
      (form[i+1]=='v' || // Removing a variable marker
       form[i+1]=='c')   // Removing a constant marker            
     )
    {      
      form.replace(i,2,"");
      len--;
    }
  }
}

string eliminateNegExstQuan(string form, int existQuanStart)
{
  int len=form.length();
  string result(""), temp("");
  int existQuanEnd=0, uniQuanStart=0, uniQuanEnd=0;
  int index=0, index2=0;
  int limit=0;
  int numOfvar2=0;
  int len2=0;
  int varFound=0;
  string newHead("");
  bool noVar=true;  
 

  uniQuanStart=form.find_first_of('[', 0);
  uniQuanEnd=form.find_first_of(']', 0);

  /* 0. Get variables */
  // Get variables in universal quantification
  index=getVariables(form, '[', ']', uniQuanStart);
  len2=tempVarsRow;
  string vars1[len2];

  for(int i=0; i<len2; i++)
  {
    vars1[i]=tempVars[i];
    varFound=form.find(vars1[i],index);

    /*
    if(varFound<0)
    {
      cout << "ERROR: variable '" << vars1[i]
	   << "' not used in "    << form
	   << endl << endl;
      exit(EXIT_FAILURE);
    }
    */
  }

  // Get variables in existential quantification
  existQuanEnd=form.find_first_of('}', existQuanStart+1);

  index2=getVariables(form, '{', '}', existQuanStart);
  string vars2[NUM_VARS];
  
  for(int j=0; j<tempVarsRow; j++)
    vars2[numOfvar2++]=tempVars[j];

  /* Introduce new Predicates  */ 
  newHead.append(newPre+integerToString(newPreNum));
  newPreNum++;

  // Find out maximal negative occurrence of 
  // existential quantification
  limit=findLimit(form, index2);
  temp=form.substr(existQuanEnd+1,limit-existQuanEnd);

  for(int l=0; l<len2; l++)
  {
    int lenOfvar=vars1[l].length();
    varFound=form.find(vars1[l],index2);

    while(1)
    {
      if(isalnum(form[varFound+lenOfvar]) || 
	 form[varFound+lenOfvar]=='_') //## should remove?
	varFound=form.find(vars1[l],varFound+lenOfvar);
      else
	break;
    }
      
    if(varFound>existQuanEnd && varFound<limit)
    {
      if(noVar)
      {
	noVar=false;
	newHead=newHead+"(";
      }
      vars2[numOfvar2++]=vars1[l];
      newHead.append(vars1[l]);
      newHead.append(",");
    }
  }

  if(!noVar)
  {
    newHead.erase(newHead.length()-1, 1);
    newHead.append(")");
  }


  form.replace(existQuanStart, limit-existQuanStart+1, newHead);

  result.append("[");
  for(int m=0; m<numOfvar2; m++)
  {
    result.append(vars2[m]);
    if(m+1<numOfvar2)
      result.append(",");
  }
  result.append("](");
  result=result+temp+":"+newHead+")";
  newPredicatesForms[nOfnewPreForms++]=result;

  return form;
}

int getVariables(string form,char open, char close, int QuanStart)
{
  int lenOfvar=0;
  int index=0;
  string var(""), token("");
  freshTempVars();
  int QuanEnd=0;
  
  do
  {
    QuanEnd=form.find_first_of(close, QuanStart+1);
    lenOfvar = QuanEnd-QuanStart-1;
    var = form.substr(QuanStart+1, lenOfvar);
  
    //##Need to check vars (syntax)

    token=split(var, ",");
    while(token.compare("")!=0)
    {
      tempVars[tempVarsRow++]=token;
      token=split(var, ",");
    }

    index=QuanEnd+1;
    QuanStart=form.find_first_of(open,index);
    
  }while(QuanStart==index);
  // Case 1: {v1}{v2,v3}{v4}....
  // Case 2: {v1} or {v1,v2...}
 
  return index;
}

void freshTempVars() // For tempVars array
{
  tempVarsRow=0;
  for(int i=0; i<NUM_VARS; i++)
    tempVars[i]="";
}

int findLimit(string form, int index)
{
  int len=form.length();
  struct stack s;
  s.top=-1;

  for(int i=index; i<len; i++)
  { 
    if(form[i]=='(')
      push(&s, '(');
    if(form[i]==')')
    {
      pop(&s);
      if(isempty(&s))
	return i;
    }
  }     
  //  return len-1;
}

/*
  1) Apply C1 to newPredicateForms
  2) Remove Existential and Universal Quantifications
  3) Write a Formula in LP and put into finalForms array
*/
void handleNewPredicateForms()
{
  freshSubforms();
  string f("");

  if(first)
  {start=0; first=false;}

  for(int i=start; i<nOfnewPreForms; i++)
  {
    // 1) Apply C1 to newPredicateForms
    applyC1(newPredicatesForms[i]);

    for(int j=0; j<nOfsubForms; j++)
    {
    // 2) Remove Existential and Universal Quantifications
      f=eliminatePosQuan(subForms[j], '{', '}');
      f=eliminatePosQuan(f, '[', ']');

    /* 3) Remove extra parentheses in a formula and
       convert it into A.S.P. */
      finalForms[numberOfForms++]=
	converToLP(removeExtraParentheses(f));
    }
  }
  
  start=nOfnewPreForms;
}

void freshVars() // for variables array
{ 
  varsRow=0;
  for(int i=0; i<NUM_VARS; i++)
    variables[i]="";
}

void freshSubforms()
{
  nOfsubForms=0;
  for(int i=0; i<NUM_SUB_FORMS; i++)
    subForms[i]="";
}

void freshSubforms2()
{
  nOfsubForms2=0;
  for(int i=0; i<NUM_SUB_FORMS; i++)
    subForms2[i]="";
}

void freshSubforms3()
{
  nOfsubForms3=0;
  for(int i=0; i<NUM_SUB_FORMS; i++)
    subForms3[i]="";
}

void setUpDomainPredicates()
{
  string s(""); // a sort name
  int count;
  domain="#domain ";

  for(int i=0; i<sortRow; i++)
  {
    count=0;
    s=sorts[i].sName;
    // $$$$ s[0]=tolower(s[0]);
    //    s=sorts[i];
    domain=domain+s+"(";

    s[0]=toupper(s[0]);

    for(int j=0; j<allVarsRow; j++)
    {
      if(allVars[j].find(s,0)==0)
      {
	domain=domain+allVars[j]+";";
	count++;
      }
    }
   
    if(count>0)
    {
      domain.erase(domain.length()-1, 1);
      domain=domain+"), ";
    }
    else
      domain.erase(domain.length()-s.length()-1, s.length()+1);
  }  
  
  domain.replace(domain.length()-2, 2, ".");
}

// End of File
