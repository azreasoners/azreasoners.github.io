/* 
  *File: format-output.cc
  *Last Updated on 3/29/09
  *By Tae-Won Kim

  *Turn output from the answer set solvers 
   to a more readable format.
*/

#include <iostream>
#include <string>
#include <sstream>

using namespace std;

#define NUM_PREDICATES 100
#define NUM_COL 100

string split(string &str, string delimiter);
int isNumber(string target);
int stringToInteger(string number);
void insertNode(string atom);
void displayList();

struct ListNode
{
  string atm;
  string sign;
  int timepoint;
  ListNode *next;
  ListNode *previous;
};

ListNode *head=NULL;

string predicates[NUM_PREDICATES];
int numOfPre=0;
int maxTimepoint=0;


int main(int argc, char *argv[])
{
  string line(""),token("");
  int as=0; // Number of Answer Sets

  while(cin)
  {
    head=NULL;
    getline(cin,line);

    if(line.find("Answer:",0)==0)
    {
      getline(cin,line);
      token=split(line," ");

      while(token.compare("")!=0) 
      {
	if(token.compare("Answer")==0 || // For cmodels
           token.compare("set:")==0 ||
           token.compare("Stable")==0 || // For smodels
           token.compare("Model:")==0);
	else                            
	  // Make a linked list that contains the answer set.
	  insertNode(token); 
	token=split(line," ");
      }
      
      cout << endl << "==========\n" << "Answer: " << ++as << endl;
      displayList();
    }
  } 

  if(!as)
  cout << "\nNo model" << endl;

  cout << endl << endl;
  return 0;
}


// Show the answer set whose format of the output is more readable to users.
void displayList()
{
  string target("");
  string current[NUM_COL];
  string next[NUM_COL];
  string minus[NUM_COL];
  string plus[NUM_COL];
  string happens[NUM_COL];
  int currentIndex=0, nextIndex=0, 
      minusIndex=0, plusIndex=0, happensIndex=0;
  bool found=false;
  ListNode *nodePtr = head;
  ListNode *nodePtr2;
  int t=nodePtr->timepoint; // The minimum timepoint in the answer set.
  int start=1;
  cout << endl;

  for(int tp=0; tp<=maxTimepoint; tp++)
  {
    while(tp<t)                   // Print out timepoints (from 0)
      {cout << tp << endl; tp++;} // until there exists an atom whose truth            
                                  // value is true at the next timepoint.

    while(nodePtr && nodePtr->timepoint==t)
    {
      current[currentIndex++]=nodePtr->atm;
      nodePtr=nodePtr->next; 
    }

    if(start) // Print out all the atoms whose truth value is true
              // at the minimum timepoint.
    {
      cout << t << endl;
      for(int c=0; c<currentIndex; c++)
	cout << current[c] << endl;
      for(int f=0; f<numOfPre; f++)
      cout << predicates[f] << endl;
      start=0;
    }

    if(tp<maxTimepoint)
    {
      nodePtr2=nodePtr;
      t=nodePtr->timepoint;

      while(nodePtr && nodePtr->timepoint==t)
      {
	next[nextIndex++]=nodePtr->atm;
	nodePtr=nodePtr->next; 
      }

      // Add minus to atoms to be false at the next timepoint.
      for(int i=0; i<currentIndex; i++)
      {
	target=current[i];
	if(target.find("happens",0)==0)
	  continue;

	for(int j=0; j<nextIndex; j++)
	{
	  if(target.compare(next[j])==0)
	    {found=true; break;}
	}

	if(!found)
        {
	  target="-"+target;
	  minus[minusIndex++]=target;
	}

	found=false;
      }

      // Add plus to atoms to be true at the next timepoint.
      for(int m=0; m<nextIndex; m++)
      {
	target=next[m];
	if(target.find("happens",0)==0)
	  continue;

	for(int n=0; n<currentIndex; n++)
        {
	  if(target.compare(current[n])==0)
	    {found=true; break;}
	}

	if(!found)
        {
	  target="+"+target;
	  plus[plusIndex++]=target;
	}

	found=false;
      }

      cout << endl << t << endl;   // #1. Print out Timepoint.
      for(int a=0; a<minusIndex; a++)
      {
	cout << minus[a] << endl;  // #2. Print out fluents that are made false. 
	minus[a]="";               
      }

      for(int b=0; b<plusIndex; b++)   
	cout << plus[b] << endl;   // #3. Print out fluents that are made true.
   
      for(int d=0; d<nextIndex; d++)
      {
	for(int e=0; e<plusIndex; e++)
	  if(next[d].compare(plus[e].substr(1))==0)
	    {found=true; break;}

	if(!found)
	  if(next[d].find("happens",0)==0)
	    happens[happensIndex++]=next[d];
	  else
	    cout << next[d] << endl; // #4.Print out fluents whose truth value has not
	                             // changed with respect to the previous timepoint.
	next[d]="";
	found=false;
      }

      for(int z=0; z<happensIndex; z++)
      {
	cout << happens[z] << endl;  // #5. Print out events that occur at the current
	happens[z]="";               //     timepoint.
      }

      for(int v=0; v<numOfPre; v++)
	cout << predicates[v] << endl;  // #6. Print out predicates explicitly defined
                                        //     on the domain description.
    }

    for(int s=0; s<currentIndex; s++)
      current[s]="";
    for(int w=0; w<plusIndex; w++)
      plus[w]="";

    minusIndex=0; plusIndex=0;
    currentIndex=0; nextIndex=0; happensIndex=0;
    nodePtr=nodePtr2;
  }
}


// Add an atom to the linked list that will contain an answer set.
void insertNode(string atom)
{
  ListNode *newNode, *nodePtr, *previousNode;
  int tp; // timepoint
  newNode = new ListNode;
  newNode->sign="";
  newNode->next=NULL;
  newNode->previous=NULL;

  int key1=atom.find_last_of(",", atom.length()-1);
  int key2=atom.length()-key1-2;
  string temp=atom.substr(key1+1, key2);
	
  int happens=atom.find("happens",0);
  int holdsAt=atom.find("holdsAt",0);

  if(holdsAt==0)
    atom=atom.substr(8,key1-8);

  if(!isNumber(temp))  // For the case of the predicates explicitly defined on 
  {                    // the domain description, Add atom at the end of the list.
    predicates[numOfPre++]=atom;
  }
  else
  {
    newNode->atm=atom;
    tp=stringToInteger(temp);
    
    if(tp>maxTimepoint)
      maxTimepoint=tp;

    newNode->timepoint=tp;
    if(!head || tp <= head->timepoint)
    {
      if(head)
	head->previous=newNode;
      newNode->next = head;
      head = newNode;
    }
    else
    {
      nodePtr = head;
      
      while(nodePtr != NULL && nodePtr->timepoint < tp)
      {
	previousNode = nodePtr;
	nodePtr = nodePtr->next;
      }

      previousNode->next = newNode;
      newNode->previous = previousNode;
      newNode->next = nodePtr;
      if(nodePtr)
	nodePtr->previous = newNode;
    }
  }
}


// Return a string address that contains the address of the substrings 
// that are delimited by a specified string (delimiter).
string split(string &str, string delimiter)
{
  string token("");

  int index=str.find_first_of(delimiter, 0);
  if(index>=0)
  {
    if(index==0)
      return split(str.erase(0,1), delimiter);

    token=str.substr(0,index);
    str.erase(0,index+1);
    return token;
  }
  else
  {token=str; str=""; return token;} // The last element
}


// Check out whether the target is a number.
int isNumber (string target)
{
  int len=target.length();
  if(len==0)
    return 0;

  int start=0;

  if(target[0]=='-')  // For negative numbers
    start=1;

  for(int i=start; i<len; i++)
    if(!isdigit(target[i]))
      return 0;
  return 1;
}


// Convert string to integer.
int stringToInteger(string number)
{
  int i;
  stringstream out;
  out.str(number);
  out >> i;
  return i;
}
